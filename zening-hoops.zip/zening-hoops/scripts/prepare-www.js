// Copies the static web game into www/ for Capacitor to bundle into the APK
const fs = require('fs');
const path = require('path');

const root = path.join(__dirname, '..');
const www = path.join(root, 'www');
const items = ['index.html', 'css', 'js', 'manifest.json', 'icons'];

fs.rmSync(www, { recursive: true, force: true });
fs.mkdirSync(www, { recursive: true });

for (const item of items) {
  const src = path.join(root, item);
  if (!fs.existsSync(src)) {
    console.warn('skip (missing):', item);
    continue;
  }
  const dest = path.join(www, item);
  fs.cpSync(src, dest, { recursive: true });
}
console.log('www/ ready:', fs.readdirSync(www).join(', '));
