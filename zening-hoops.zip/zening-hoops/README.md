# Zening Hoops — Thanksgiving Classic

A 3D stickman basketball game for mobile. Fully offline, built with Three.js, packaged into an Android APK with Capacitor and GitHub Actions.

**Landscape only** — the Android app is locked to sensor landscape, and the game asks for fullscreen + landscape on touch devices.

## What's in this build

- Full 3D court with real rim / backboard / cloth-simulated net physics
- **New 2K-style broadcast camera**: high sideline telephoto that tracks the ball, punches in as the play attacks the rim, and drifts onto the hoop while a shot is in the air
- **Fuller stickman animation**: sprinting arm swing + forward lean, upright dribble with live pump arm, two-hand jump-shot gather with guide-hand follow-through and wrist flick, dunk with knee tuck + slam, defenders in a low guard stance who track the ball with their eyes
- Dual-stick touch controls: move with the left stick, shoot / steal / pass buttons, and a flick zone (down = step back, left / right = hesi crossover, up = pump fake)
- Timing-based shot meter with GREEN releases (green burst, ball trail, green giant sound)
- Dunks, layups, ankle breakers, steals, blocks, pump fakes
- AI opponents (Rookie / Pro / All-Star) plus a 2v2 mode with an AI teammate
- Ball skins, trails, and auras in the shop — earn coins by hooping
- Jersey, headband and number customization
- Thanksgiving-themed park: autumn trees, pumpkins, bunting, string lights, live crowd and scoreboard

## Game modes

| Mode | Format | Target |
| --- | --- | --- |
| Blacktop Run | 1v1 | First to 11 |
| Thanksgiving Classic | 2v2 | First to 21 |
| Sudden Death | 1v1 | First basket wins |
| Free Play | Solo | Practice, no clock |

## How to get the APK (GitHub builds it for you — no Android Studio needed)

The workflow unzips the game archive itself and builds with the **latest toolchain** (Node 24, JDK 21, Capacitor 8.x, Android SDK 35/36/37, cached Gradle) — no more SDK errors.

1. In your GitHub repo, create the workflow file first: **`.github/workflows/build-apk.yml`** — copy the `build-apk.yml` from this package there.
   - Important: GitHub can only read workflow files that are **real files in the repo**, so this one file goes in *outside* the zip (the zip also contains a copy for reference).
   - On github.com: **Add file → Create new file**, type the path `.github/workflows/build-apk.yml`, paste the contents, commit.
2. Upload **`zening-hoops.zip`** into the repo root — exactly as it is, no need to unzip.
   - On github.com: **Add file → Upload files**, or GitHub Desktop, or `git push`.
3. Push to `main` (or `master`) and the build starts automatically — or open the **Actions** tab → **Build Zening Hoops APK** → **Run workflow** at any time.
   - First run: click **I understand my workflows, go ahead and enable them** if asked. Takes about 5-10 minutes.
4. Open the finished run → **Artifacts** → download **ZeningHoops-APK** → inside you'll find `ZeningHoops-debug.apk`.
5. Move the APK to your phone and install it. Allow **install unknown apps** for your browser / file manager when Android asks. That's it — the game runs fully offline, in landscape.

Every future push to `main` automatically rebuilds a fresh APK.

### Optional: signed release APK + GitHub Releases

- The workflow also builds an unsigned release APK (`ZeningHoops-release-unsigned.apk`).
- Add these repo **Secrets** (Settings → Secrets and variables → Actions) and it gets signed automatically: `ANDROID_KEYSTORE_BASE64` (your `.jks` file encoded in base64), `ANDROID_KEYSTORE_PASSWORD`, `ANDROID_KEY_ALIAS`, `ANDROID_KEY_ALIAS_PASSWORD`.
- Push a tag like `v1.0` and the APKs are attached to a GitHub **Release** for easy sharing.

## Run it locally in a browser first (optional)

```bash
npm install        # only needed for the dev server / capacitor
npm run serve      # opens http://localhost:8137
```

Or just double-click `index.html` in most browsers (Chrome / Edge recommended).

## Controls

| Input | Action |
| --- | --- |
| Left stick | Move (push to the edge to sprint) |
| SHOOT (hold + release) | Jump shot — release inside the green window for a guaranteed GREEN |
| Flick down (swipe zone) | Step back |
| Flick left / right | Hesi crossover — can break ankles |
| Flick up | Pump fake (in 1v1 this is also the PASS button) |
| PASS | Throw to your teammate (2v2 modes) |
| STEAL | Rip the ball on defense; press it while the opponent shoots to jump for a block |

Keyboard (desktop testing): WASD move, Shift sprint, Space / J shoot, K pass / fake, L steal, Z step back, X crossover, C pump fake.

## Project layout

```
index.html            app shell + all UI screens
css/style.css         Thanksgiving theme
js/main.js            bootstrap + game loop
js/world.js           court, hoops, nets, park, crowd
js/stickman.js        3D stickman + procedural animation
js/actor.js           movement, shot meter, moves, defense
js/ai.js              AI brains
js/game.js            match rules, scoring, camera, HUD
js/ball.js            ball physics + rim / board / net collision
js/controls.js        touch + keyboard input
js/vfx.js             particles, trails, popups
js/audio.js           procedural sound effects + music
js/config.js          save system, shop catalog, constants
js/three/             vendored Three.js (offline)
scripts/              www packaging + dev server
.github/workflows/    APK build workflow
```

## Notes

- The APK is a **debug** build: installable and signed, perfect for playing and sharing. If you later want a Play Store release build you'll need to create a signed keystore — easy to add when you're ready.
- Saves (coins, unlocks, stats) are stored locally on the device.
- Recommended: Android 8+ with an updated Android System WebView.
