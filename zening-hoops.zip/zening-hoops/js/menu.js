// ============ ZENING HOOPS — menu UI: leaves, shop, customize, settings, results ============
import { SAVE, CATALOG, JERSEY_COLORS, BAND_COLORS, MODES } from './config.js';
import { SFX } from './audio.js';

const $ = id => document.getElementById(id);

export class MenuUI {
  constructor(app) {
    this.app = app;
    this.leaves = [];
    this.leafRunning = false;
  }

  init() {
    // main buttons
    $('btn-play').onclick = () => { SFX.click(); this.app.startGame('blacktop'); };
    $('btn-modes').onclick = () => { SFX.click(); this.showPanel('panel-modes'); };
    $('btn-shop').onclick = () => { SFX.click(); this.renderShop(); this.showPanel('panel-shop'); };
    $('btn-custom').onclick = () => { SFX.click(); this.renderCustom(); this.showPanel('panel-custom'); };
    $('btn-settings').onclick = () => { SFX.click(); this.renderSettings(); this.showPanel('panel-settings'); };

    // close buttons
    document.querySelectorAll('[data-close]').forEach(b => {
      b.onclick = () => { SFX.click(); $(b.dataset.close).classList.add('hidden'); };
    });

    // modes
    document.querySelectorAll('.mode-card').forEach(c => {
      c.onclick = () => { SFX.click(); this.app.startGame(c.dataset.mode); };
    });

    // customize
    $('num-minus').onclick = () => this.changeNumber(-1);
    $('num-plus').onclick = () => this.changeNumber(1);

    // settings
    $('set-vol').oninput = e => {
      SAVE.data.settings.vol = e.target.value / 100;
      SAVE.save();
      SFX.setVolume(SAVE.data.settings.vol);
    };
    $('set-music').onclick = () => {
      const on = SAVE.data.settings.music ? false : true;
      SAVE.data.settings.music = on;
      SAVE.save();
      SFX.setMusic(on);
      this._setToggle($('set-music'), on);
    };
    document.querySelectorAll('#set-quality button').forEach(b => {
      b.onclick = () => {
        SAVE.data.settings.quality = b.dataset.q;
        SAVE.save();
        this.app.world.applyQuality(b.dataset.q);
        this._setSeg('set-quality', 'q', b.dataset.q);
        SFX.click();
      };
    });
    document.querySelectorAll('#set-diff button').forEach(b => {
      b.onclick = () => {
        SAVE.data.settings.difficulty = +b.dataset.d;
        SAVE.save();
        this._setSeg('set-diff', 'd', b.dataset.d);
        SFX.click();
      };
    });
    $('set-reset').onclick = () => {
      SAVE.reset();
      this.updateCoins();
      this.renderSettings();
      this.app.refreshPreview();
      SFX.click();
    };

    // pause / result
    $('btn-pause').onclick = () => { SFX.click(); this.pause(); };
    $('btn-resume').onclick = () => { SFX.click(); this.resume(); };
    $('btn-quit').onclick = () => { SFX.click(); $('panel-pause').classList.add('hidden'); this.app.game.quitToMenu(); };
    $('btn-rematch').onclick = () => { SFX.click(); $('result').classList.add('hidden'); this.app.startGame(this.app.game.mode); };
    $('btn-menu').onclick = () => { SFX.click(); $('result').classList.add('hidden'); this.app.toMenu(); };
    $('btn-tut-ok').onclick = () => {
      SFX.click();
      $('tutorial').classList.add('hidden');
      SAVE.data.seenTut = true;
      SAVE.save();
    };

    // leaves canvas
    this.lc = $('leaves');
    this.lctx = this.lc.getContext('2d');
    this.resizeLeaves();
  }

  // ---------- panels ----------
  showPanel(id) {
    $(id).classList.remove('hidden');
  }
  _setToggle(el, on) { el.dataset.on = on ? '1' : '0'; el.textContent = on ? 'ON' : 'OFF'; }
  _setSeg(id, attr, val) {
    document.querySelectorAll(`#${id} button`).forEach(b => b.classList.toggle('active', b.dataset[attr] === String(val)));
  }

  updateCoins() {
    const c = SAVE.data.coins;
    $('coins-val').textContent = c;
    $('shop-coins-val').textContent = c;
    $('hud-coins-val').textContent = c;
    const s = SAVE.data.stats;
    $('menu-stats').textContent = `Career: ${s.games}G ${s.wins}W  |  ${s.points} PTS  |  ${s.greens} GREENS  |  ${s.ankles} ANKLES`;
  }

  showMenu() {
    this.updateCoins();
    $('menu').classList.remove('hidden');
    $('hud').classList.add('hidden');
    $('controls').classList.add('hidden');
    $('result').classList.add('hidden');
    $('panel-pause').classList.add('hidden');
    if (!SAVE.data.seenTut) $('tutorial').classList.remove('hidden');
    this.startLeaves();
  }
  hideMenu() {
    $('menu').classList.add('hidden');
    this.stopLeaves();
  }

  pause() {
    if (this.app.state !== 'game') return;
    this.app.game.paused = true;
    $('panel-pause').classList.remove('hidden');
  }
  resume() {
    this.app.game.paused = false;
    $('panel-pause').classList.add('hidden');
  }

  showResult(d) {
    const t = $('result-title');
    t.textContent = d.win ? 'VICTORY' : 'DEFEAT';
    t.classList.toggle('loss', !d.win);
    $('result-score').textContent = `${d.score[0]} - ${d.score[1]}`;
    const e = d.earned;
    $('result-stats').innerHTML = [
      `Points: <b>${e.points}</b>`, `Greens: <b>${e.greens}</b>`, `Ankle breakers: <b>${e.ankles}</b>`,
      `Steals: <b>${e.steals}</b>`, `Blocks: <b>${e.blocks}</b>`, `Dunks: <b>${e.dunks}</b>`
    ].join('<br>');
    $('result-coins').textContent = `+${d.total} COINS EARNED`;
    $('result').classList.remove('hidden');
    this.updateCoins();
  }

  // ---------- shop ----------
  renderShop() {
    const render = (list, elId, cat) => {
      const el = $(elId);
      el.innerHTML = '';
      for (const item of list) {
        const id = `${cat}:${item.id}`;
        const owned = SAVE.data.unlocked.includes(id);
        const equipped = SAVE.data.equip[cat] === item.id;
        const card = document.createElement('div');
        card.className = 'shop-item' + (equipped ? ' equipped' : '');
        const glow = item.glow && item.glow !== '#00000000' ? item.glow : 'transparent';
        card.innerHTML = `
          <div class="shop-swatch" style="background:${item.color};--sw-glow:${glow}"></div>
          <div class="shop-name">${item.name}</div>
          ${equipped ? '<div class="shop-price" style="color:#35e06a">EQUIPPED</div>'
            : owned ? '<button class="shop-btn equip">EQUIP</button>'
            : `<div class="shop-price"><span class="coin-dot"></span>${item.price}</div><button class="shop-btn buy">BUY</button>`}`;
        const btn = card.querySelector('.shop-btn');
        if (btn && btn.classList.contains('buy')) {
          btn.onclick = () => {
            SFX.click();
            if (SAVE.buy(id)) { SFX.cheer(); this.renderShop(); this.updateCoins(); this.app.refreshPreview(); }
            else { SFX.buzzer(); btn.textContent = 'TOO BROKE'; setTimeout(() => this.renderShop(), 700); }
          };
        } else if (btn) {
          btn.onclick = () => { SFX.click(); SAVE.equip(id); this.renderShop(); this.updateCoins(); this.app.refreshPreview(); };
        }
        el.appendChild(card);
      }
    };
    render(CATALOG.balls, 'shop-balls', 'ball');
    render(CATALOG.trails, 'shop-trails', 'trail');
    render(CATALOG.auras, 'shop-auras', 'aura');
  }

  // ---------- customize ----------
  renderCustom() {
    const eq = SAVE.data.equip;
    const sw = (list, elId, key, previewer) => {
      const el = $(elId);
      el.innerHTML = '';
      for (const col of list) {
        const b = document.createElement('button');
        b.className = 'swatch' + (eq[key] === col ? ' active' : '');
        b.style.background = col;
        b.onclick = () => {
          SFX.click();
          eq[key] = col;
          SAVE.save();
          this.renderCustom();
          this.app.refreshPreview();
        };
        el.appendChild(b);
      }
    };
    sw(JERSEY_COLORS, 'sw-jersey', 'jersey');
    sw(BAND_COLORS, 'sw-band', 'band');
    $('num-val').textContent = eq.number;
  }
  changeNumber(d) {
    const eq = SAVE.data.equip;
    eq.number = ((eq.number + d) % 100 + 100) % 100;
    SAVE.save();
    $('num-val').textContent = eq.number;
    this.app.refreshPreview();
    SFX.click();
  }

  // ---------- settings ----------
  renderSettings() {
    const s = SAVE.data.settings;
    $('set-vol').value = Math.round(s.vol * 100);
    this._setToggle($('set-music'), s.music);
    this._setSeg('set-quality', 'q', s.quality);
    this._setSeg('set-diff', 'd', s.difficulty);
  }

  // ---------- falling leaves ----------
  resizeLeaves() {
    this.lc.width = innerWidth; this.lc.height = innerHeight;
  }
  startLeaves() {
    if (this.leafRunning) return;
    this.leafRunning = true;
    const colors = ['#d2691e', '#b03030', '#e9a13b', '#8a5a2a', '#c2452a'];
    for (let i = 0; i < 26; i++) {
      this.leaves.push(this._newLeaf(true));
    }
    const step = () => {
      if (!this.leafRunning) return;
      const g = this.lctx;
      g.clearRect(0, 0, this.lc.width, this.lc.height);
      if (this.leaves.length < 26 && Math.random() < 0.3) this.leaves.push(this._newLeaf(false));
      for (let i = this.leaves.length - 1; i >= 0; i--) {
        const l = this.leaves[i];
        l.y += l.vy; l.x += Math.sin(l.ph += l.sw) * 0.8; l.rot += l.vr;
        if (l.y > this.lc.height + 30) { this.leaves.splice(i, 1); continue; }
        g.save();
        g.translate(l.x, l.y);
        g.rotate(l.rot);
        g.fillStyle = l.color;
        g.globalAlpha = l.alpha;
        g.beginPath();
        g.ellipse(0, 0, l.s * 0.45, l.s, 0, 0, Math.PI * 2);
        g.fill();
        g.strokeStyle = 'rgba(60,30,10,.4)';
        g.beginPath(); g.moveTo(0, -l.s); g.lineTo(0, l.s); g.stroke();
        g.restore();
      }
      this._raf = requestAnimationFrame(step);
    };
    step();
  }
  _newLeaf(anywhere) {
    return {
      x: Math.random() * innerWidth,
      y: anywhere ? Math.random() * innerHeight : -30,
      s: 7 + Math.random() * 9,
      vy: 0.6 + Math.random() * 1.4,
      rot: Math.random() * Math.PI * 2,
      vr: (Math.random() - 0.5) * 0.05,
      ph: Math.random() * Math.PI * 2,
      sw: 0.01 + Math.random() * 0.03,
      color: ['#d2691e', '#b03030', '#e9a13b', '#8a5a2a', '#c2452a'][(Math.random() * 5) | 0],
      alpha: 0.55 + Math.random() * 0.4
    };
  }
  stopLeaves() {
    this.leafRunning = false;
    cancelAnimationFrame(this._raf);
    this.lctx.clearRect(0, 0, this.lc.width, this.lc.height);
  }
}
