// ============ ZENING HOOPS — procedural audio engine (WebAudio, zero assets) ============
import { SAVE } from './config.js';

class AudioEngine {
  constructor() {
    this.ctx = null;
    this.master = null;
    this.musicGain = null;
    this.sfxGain = null;
    this.crowdGain = null;
    this.musicNodes = [];
    this.crowdLevel = 0.12;
    this.lastSqueak = 0;
  }
  ensure() {
    if (this.ctx) { if (this.ctx.state === 'suspended') this.ctx.resume(); return; }
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    this.ctx = new AC();
    this.master = this.ctx.createGain();
    this.master.gain.value = SAVE.data.settings.vol;
    this.master.connect(this.ctx.destination);
    this.sfxGain = this.ctx.createGain(); this.sfxGain.connect(this.master);
    this.musicGain = this.ctx.createGain(); this.musicGain.gain.value = SAVE.data.settings.music ? 0.5 : 0;
    this.musicGain.connect(this.master);
    this.crowdGain = this.ctx.createGain(); this.crowdGain.gain.value = 0.1;
    this.crowdGain.connect(this.master);
    this._startCrowd();
    if (SAVE.data.settings.music) this.startMusic();
  }
  setVolume(v) { if (this.master) this.master.gain.value = v; }
  setMusic(on) {
    if (!this.ctx) return;
    this.musicGain.gain.linearRampToValueAtTime(on ? 0.5 : 0, this.ctx.currentTime + 0.3);
    if (on && this.musicNodes.length === 0) this.startMusic();
  }
  // ---------- helpers ----------
  _noiseBuffer(dur = 1) {
    const len = this.ctx.sampleRate * dur;
    const buf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    return buf;
  }
  _burst({ dur = 0.12, freq = 800, q = 1, gain = 0.5, type = 'bandpass', pitchEnd = null }) {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    const src = this.ctx.createBufferSource(); src.buffer = this._noiseBuffer(dur + 0.05);
    const f = this.ctx.createBiquadFilter(); f.type = type; f.frequency.setValueAtTime(freq, t); f.Q.value = q;
    if (pitchEnd) f.frequency.exponentialRampToValueAtTime(Math.max(40, pitchEnd), t + dur);
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(gain, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    src.connect(f); f.connect(g); g.connect(this.sfxGain);
    src.start(t); src.stop(t + dur + 0.05);
  }
  _tone({ freq = 440, dur = 0.2, type = 'sine', gain = 0.3, attack = 0.004, freqEnd = null, dest = null }) {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    const o = this.ctx.createOscillator(); o.type = type;
    o.frequency.setValueAtTime(freq, t);
    if (freqEnd) o.frequency.exponentialRampToValueAtTime(Math.max(30, freqEnd), t + dur);
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(gain, t + attack);
    g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    o.connect(g); g.connect(dest || this.sfxGain);
    o.start(t); o.stop(t + dur + 0.05);
  }
  // ---------- ambient ----------
  _startCrowd() {
    const src = this.ctx.createBufferSource();
    src.buffer = this._noiseBuffer(3); src.loop = true;
    const f = this.ctx.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = 420; f.Q.value = 0.4;
    src.connect(f); f.connect(this.crowdGain);
    src.start();
    // slow LFO wobble so crowd feels alive
    const lfo = this.ctx.createOscillator(); lfo.frequency.value = 0.13;
    const lg = this.ctx.createGain(); lg.gain.value = 0.03;
    lfo.connect(lg); lg.connect(this.crowdGain.gain);
    lfo.start();
  }
  crowd(level) { if (this.ctx) this.crowdGain.gain.linearRampToValueAtTime(0.06 + level * 0.3, this.ctx.currentTime + 0.4); }
  // ---------- lo-fi menu music ----------
  startMusic() {
    if (!this.ctx || this.musicNodes.length) return;
    const t0 = this.ctx.currentTime + 0.1;
    // warm pad: two chords cycling
    const chords = [[220, 277.18, 329.63], [196, 246.94, 293.66]]; // A min, G maj
    chords.forEach((chord, ci) => {
      chord.forEach(freq => {
        const o = this.ctx.createOscillator(); o.type = 'sawtooth'; o.frequency.value = freq;
        const f = this.ctx.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = 640; f.Q.value = 0.6;
        const g = this.ctx.createGain();
        const barDur = 4;
        for (let bar = 0; bar < 40; bar++) {
          const tt = t0 + (bar * 2 + ci) * barDur;
          g.gain.setValueAtTime(0.0001, tt);
          g.gain.linearRampToValueAtTime(0.028, tt + 1.6);
          g.gain.linearRampToValueAtTime(0.0001, tt + barDur);
        }
        o.connect(f); f.connect(g); g.connect(this.musicGain);
        o.start(t0); o.stop(t0 + 80 * 4 + 2);
        this.musicNodes.push(o);
      });
    });
    // soft heartbeat kick
    const kickT = setInterval(() => {
      if (!this.ctx || !SAVE.data.settings.music) return;
      this._tone({ freq: 90, freqEnd: 42, dur: 0.22, type: 'sine', gain: 0.16, dest: this.musicGain });
    }, 2000);
    this._kickTimer = kickT;
  }
  // ---------- game sfx ----------
  bounce(power = 1) {
    this._tone({ freq: 120 + power * 30, freqEnd: 55, dur: 0.09, type: 'sine', gain: 0.4 * power });
    this._burst({ dur: 0.05, freq: 900, gain: 0.18 * power, type: 'lowpass' });
  }
  rim() {
    this._tone({ freq: 1180, dur: 0.28, type: 'triangle', gain: 0.22 });
    this._tone({ freq: 1780, dur: 0.2, type: 'sine', gain: 0.12 });
    this._burst({ dur: 0.06, freq: 2400, q: 8, gain: 0.2 });
  }
  board() {
    this._tone({ freq: 210, freqEnd: 120, dur: 0.14, type: 'square', gain: 0.16 });
    this._burst({ dur: 0.08, freq: 500, gain: 0.3, type: 'lowpass' });
  }
  swish() { this._burst({ dur: 0.22, freq: 3200, q: 0.6, gain: 0.4, type: 'bandpass', pitchEnd: 1400 }); }
  squeak() {
    const now = performance.now();
    if (now - this.lastSqueak < 220) return;
    this.lastSqueak = now;
    const f = 1400 + Math.random() * 1800;
    this._tone({ freq: f, freqEnd: f * (0.7 + Math.random() * 0.5), dur: 0.08, type: 'sawtooth', gain: 0.045 });
  }
  whistle() { this._tone({ freq: 2400, dur: 0.35, type: 'sine', gain: 0.18 }); this._tone({ freq: 2420, dur: 0.35, type: 'sine', gain: 0.14 }); }
  buzzer() { this._tone({ freq: 340, dur: 0.9, type: 'square', gain: 0.2 }); this._tone({ freq: 344, dur: 0.9, type: 'square', gain: 0.14 }); }
  click() { this._tone({ freq: 640, freqEnd: 480, dur: 0.06, type: 'triangle', gain: 0.12 }); }
  swoosh() { this._burst({ dur: 0.18, freq: 900, q: 0.8, gain: 0.22, pitchEnd: 2600 }); }
  // GREEN GIANT — deep boom + bright arp + crowd roar
  green() {
    this._tone({ freq: 65, freqEnd: 38, dur: 0.5, type: 'sine', gain: 0.55 });
    const notes = [523.25, 659.25, 783.99, 1046.5];
    notes.forEach((f, i) => setTimeout(() => this._tone({ freq: f, dur: 0.3, type: 'triangle', gain: 0.16 }), i * 70));
    this._burst({ dur: 0.9, freq: 700, gain: 0.3, type: 'bandpass', pitchEnd: 1600 });
    this.crowd(1);
  }
  ankles() {
    this._tone({ freq: 480, freqEnd: 160, dur: 0.3, type: 'sawtooth', gain: 0.2 });
    setTimeout(() => this._burst({ dur: 0.12, freq: 1800, q: 2, gain: 0.3 }), 60);
    setTimeout(() => this._burst({ dur: 0.12, freq: 1200, q: 2, gain: 0.25 }), 140);
  }
  dunk() {
    this._tone({ freq: 95, freqEnd: 40, dur: 0.3, type: 'square', gain: 0.4 });
    this._burst({ dur: 0.2, freq: 300, gain: 0.5, type: 'lowpass' });
    this.rim();
    this.crowd(0.8);
  }
  cheer() {
    this._burst({ dur: 1.1, freq: 850, q: 0.5, gain: 0.34, type: 'bandpass', pitchEnd: 1300 });
    this.crowd(0.9);
  }
  netMove() { this._burst({ dur: 0.14, freq: 2200, q: 0.8, gain: 0.12, pitchEnd: 900 }); }
}
export const SFX = new AudioEngine();
