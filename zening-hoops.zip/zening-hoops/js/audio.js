// ============ ZENING HOOPS — procedural audio engine (WebAudio, zero assets) ============
import { SAVE } from './config.js';

class AudioEngine {
  constructor() {
    this.ctx = null;
    this.master = null;
    this.musicGain = null;
    this.sfxGain = null;
    this.crowdGain = null;
    this.musicNodes = [];
    this.crowdLevel = 0.12;
    this.lastSqueak = 0;
  }
  ensure() {
    if (this.ctx) { if (this.ctx.state === 'suspended') this.ctx.resume(); return; }
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    this.ctx = new AC();
    this.master = this.ctx.createGain();
    this.master.gain.value = SAVE.data.settings.vol;
    this.master.connect(this.ctx.destination);
    this.sfxGain = this.ctx.createGain(); this.sfxGain.connect(this.master);
    this.musicGain = this.ctx.createGain(); this.musicGain.gain.value = SAVE.data.settings.music ? 0.34 : 0;
    this.musicGain.connect(this.master);
    this.crowdGain = this.ctx.createGain(); this.crowdGain.gain.value = 0.1;
    this.crowdGain.connect(this.master);
    this._startCrowd();
    if (SAVE.data.settings.music) this.startMusic();
  }
  setVolume(v) { if (this.master) this.master.gain.value = v; }
  setMusic(on) {
    if (!this.ctx) return;
    this.musicGain.gain.linearRampToValueAtTime(on ? 0.34 : 0, this.ctx.currentTime + 0.3);
    if (on && this.musicNodes.length === 0) this.startMusic();
  }
  _noiseBuffer(dur = 1) {
    const len = this.ctx.sampleRate * dur;
    const buf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    return buf;
  }
  _burst({ dur = 0.12, freq = 800, q = 1, gain = 0.5, type = 'bandpass', pitchEnd = null }) {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    const src = this.ctx.createBufferSource(); src.buffer = this._noiseBuffer(dur + 0.05);
    const f = this.ctx.createBiquadFilter(); f.type = type; f.frequency.setValueAtTime(freq, t); f.Q.value = q;
    if (pitchEnd) f.frequency.exponentialRampToValueAtTime(Math.max(40, pitchEnd), t + dur);
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(gain, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    src.connect(f); f.connect(g); g.connect(this.sfxGain);
    src.start(t); src.stop(t + dur + 0.05);
  }
  _tone({ freq = 440, dur = 0.2, type = 'sine', gain = 0.3, attack = 0.004, freqEnd = null, dest = null }) {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    const o = this.ctx.createOscillator(); o.type = type;
    o.frequency.setValueAtTime(freq, t);
    if (freqEnd) o.frequency.exponentialRampToValueAtTime(Math.max(30, freqEnd), t + dur);
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(gain, t + attack);
    g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    o.connect(g); g.connect(dest || this.sfxGain);
    o.start(t); o.stop(t + dur + 0.05);
  }
  // ---------- ambient ----------
  _startCrowd() {
    const src = this.ctx.createBufferSource();
    src.buffer = this._noiseBuffer(3); src.loop = true;
    const f = this.ctx.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = 420; f.Q.value = 0.4;
    src.connect(f); f.connect(this.crowdGain);
    src.start();
    // slow LFO wobble so crowd feels alive
    const lfo = this.ctx.createOscillator(); lfo.frequency.value = 0.13;
    const lg = this.ctx.createGain(); lg.gain.value = 0.03;
    lfo.connect(lg); lg.connect(this.crowdGain.gain);
    lfo.start();
  }
  crowd(level) { if (this.ctx) this.crowdGain.gain.linearRampToValueAtTime(0.06 + level * 0.3, this.ctx.currentTime + 0.4); }
  // ---------- chill lo-fi music: endless scheduled loop, low volume ----------
  // Warm rhodes-ish chords, soft sub bass, brushed hats, vinyl crackle and
  // sparse melody plucks — a mellow park-at-dusk vibe that never fights the game.
  startMusic() {
    if (!this.ctx || this.musicNodes.length) return;
    const AC = this.ctx;
    this._musicGain0 = this.musicGain.gain.value;
    // music bus: gentle lowpass so everything sits warm and behind the court
    this._musicLP = AC.createBiquadFilter();
    this._musicLP.type = 'lowpass';
    this._musicLP.frequency.value = 2200;
    this._musicLP.connect(this.musicGain);
    this.musicNodes.push(this._musicLP);
    // vinyl crackle bed
    const crackle = AC.createBufferSource();
    crackle.buffer = this._noiseBuffer(4); crackle.loop = true;
    const cf = AC.createBiquadFilter(); cf.type = 'bandpass'; cf.frequency.value = 3400; cf.Q.value = 0.4;
    const cg = AC.createGain(); cg.gain.value = 0.012;
    crackle.connect(cf); cf.connect(cg); cg.connect(this.musicGain);
    crackle.start();
    this.musicNodes.push(crackle);

    // ---- the loop ----
    const BPM = 74;
    const BEAT = 60 / BPM;              // 0.81s
    const BAR = BEAT * 4;
    // i - VI - III - VII in A minor, warm voicings
    const PROG = [
      { chord: [220.0, 261.63, 329.63, 392.0], bass: 55.0 },   // Am7
      { chord: [174.61, 220.0, 261.63, 329.63], bass: 43.65 }, // Fmaj7
      { chord: [196.0, 246.94, 293.66, 329.63], bass: 49.0 },  // G6-ish... actually Em7/G? keep mellow
      { chord: [261.63, 329.63, 392.0, 493.88], bass: 65.41 }  // Cmaj7 up top? no — calm resolve
    ];
    const SCALE = [220.0, 246.94, 261.63, 293.66, 329.63, 392.0, 440.0, 523.25]; // A minor pentatonic-ish
    this._bar = 0;
    this._nextBarT = AC.currentTime + 0.15;
    this._melodyGap = 0;

    const scheduleBar = (barIdx, t0) => {
      const step = PROG[barIdx % PROG.length];
      // --- rhodes chord: 2 gentle stabs (1 and the "and" of 2) ---
      const stabs = [[0, 0.85], [1.5 * BEAT, 0.5]];
      for (const [off, vel] of stabs) {
        step.chord.forEach((f, ci) => {
          const o = AC.createOscillator(); o.type = ci % 2 ? 'triangle' : 'sine';
          o.frequency.value = f * (ci % 2 ? 1.0015 : 0.999);   // gentle detune warmth
          const o2 = AC.createOscillator(); o2.type = 'sine'; o2.frequency.value = f * 2.001; // shimmer octave
          const g = AC.createGain();
          const g2 = AC.createGain(); g2.gain.value = 0.22;
          const st = t0 + off;
          g.gain.setValueAtTime(0.0001, st);
          g.gain.linearRampToValueAtTime(0.030 * vel, st + 0.12);
          g.gain.exponentialRampToValueAtTime(0.0001, st + BEAT * 3.2);
          o.connect(g); o2.connect(g2); g2.connect(g);
          g.connect(this._musicLP);
          o.start(st); o.stop(st + BEAT * 3.4);
          o2.start(st); o2.stop(st + BEAT * 3.4);
        });
      }
      // --- sub bass: root on 1, fifth pickup on 3 ---
      const bassNotes = [[0, step.bass], [2 * BEAT, step.bass * 1.5]];
      for (const [off, f] of bassNotes) {
        const o = AC.createOscillator(); o.type = 'sine'; o.frequency.value = f;
        const g = AC.createGain();
        const st = t0 + off;
        g.gain.setValueAtTime(0.0001, st);
        g.gain.linearRampToValueAtTime(0.075, st + 0.06);
        g.gain.exponentialRampToValueAtTime(0.0001, st + BEAT * 1.8);
        o.connect(g); g.connect(this._musicLP);
        o.start(st); o.stop(st + BEAT * 2);
      }
      // --- soft kick: 1 and 3, way behind the beat ---
      for (const off of [0, 2 * BEAT + BEAT * 0.94]) {
        const st = t0 + off;
        const o = AC.createOscillator(); o.type = 'sine';
        o.frequency.setValueAtTime(82, st);
        o.frequency.exponentialRampToValueAtTime(40, st + 0.16);
        const g = AC.createGain();
        g.gain.setValueAtTime(0.0001, st);
        g.gain.linearRampToValueAtTime(0.11, st + 0.008);
        g.gain.exponentialRampToValueAtTime(0.0001, st + 0.24);
        o.connect(g); g.connect(this._musicLP);
        o.start(st); o.stop(st + 0.3);
      }
      // --- brushed hats: swung 8ths, ghosted ---
      for (let e = 0; e < 8; e++) {
        if (Math.random() < 0.3) continue;
        const swing = e % 2 ? 0.12 * BEAT : 0;
        const st = t0 + e * BEAT * 0.5 + swing;
        const src = AC.createBufferSource(); src.buffer = this._hatBuf || (this._hatBuf = (() => {
          const b = AC.createBuffer(1, AC.sampleRate * 0.09, AC.sampleRate);
          const d = b.getChannelData(0);
          for (let i = 0; i < d.length; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / d.length, 2.2);
          return b;
        })());
        const f = AC.createBiquadFilter(); f.type = 'highpass'; f.frequency.value = 8200;
        const g = AC.createGain();
        g.gain.value = e % 2 ? 0.014 : 0.026;
        src.connect(f); f.connect(g); g.connect(this._musicLP);
        src.start(st);
      }
      // --- sparse melody plucks (1-2 per 2 bars, pentatonic) ---
      if (barIdx % 2 === 1 || Math.random() < 0.4) {
        const n = Math.random() < 0.55 ? 1 : 2;
        for (let i = 0; i < n; i++) {
          const off = BEAT * (Math.random() < 0.5 ? 1.5 : 2.5);
          const f = SCALE[(Math.random() * SCALE.length) | 0] * (Math.random() < 0.3 ? 2 : 1);
          const st = t0 + off;
          const o = AC.createOscillator(); o.type = 'triangle'; o.frequency.value = f;
          const g = AC.createGain();
          g.gain.setValueAtTime(0.0001, st);
          g.gain.linearRampToValueAtTime(0.026, st + 0.02);
          g.gain.exponentialRampToValueAtTime(0.0001, st + 0.9);
          o.connect(g); g.connect(this._musicLP);
          o.start(st); o.stop(st + 1);
        }
      }
    };

    this._musicTimer = setInterval(() => {
      if (!this.ctx || !SAVE.data.settings.music) return;
      // schedule up to 2 bars ahead; if the context was suspended (mobile
      // autoplay policy) skip the backlog so the groove restarts cleanly
      while (this._nextBarT < this.ctx.currentTime + BAR * 2.2) {
        const t0 = Math.max(this._nextBarT, this.ctx.currentTime + 0.06);
        scheduleBar(this._bar, t0);
        this._bar++;
        this._nextBarT += BAR;
      }
    }, 400);
    this.musicNodes.push({ stop: () => clearInterval(this._musicTimer) });
  }
  // ---------- game sfx ----------
  bounce(power = 1) {
    this._tone({ freq: 120 + power * 30, freqEnd: 55, dur: 0.09, type: 'sine', gain: 0.4 * power });
    this._burst({ dur: 0.05, freq: 900, gain: 0.18 * power, type: 'lowpass' });
  }
  rim() {
    this._tone({ freq: 1180, dur: 0.28, type: 'triangle', gain: 0.22 });
    this._tone({ freq: 1780, dur: 0.2, type: 'sine', gain: 0.12 });
    this._burst({ dur: 0.06, freq: 2400, q: 8, gain: 0.2 });
  }
  board() {
    this._tone({ freq: 210, freqEnd: 120, dur: 0.14, type: 'square', gain: 0.16 });
    this._burst({ dur: 0.08, freq: 500, gain: 0.3, type: 'lowpass' });
  }
  swish() { this._burst({ dur: 0.22, freq: 3200, q: 0.6, gain: 0.4, type: 'bandpass', pitchEnd: 1400 }); }
  squeak() {
    const now = performance.now();
    if (now - this.lastSqueak < 220) return;
    this.lastSqueak = now;
    const f = 1400 + Math.random() * 1800;
    this._tone({ freq: f, freqEnd: f * (0.7 + Math.random() * 0.5), dur: 0.08, type: 'sawtooth', gain: 0.045 });
  }
  whistle() { this._tone({ freq: 2400, dur: 0.35, type: 'sine', gain: 0.18 }); this._tone({ freq: 2420, dur: 0.35, type: 'sine', gain: 0.14 }); }
  buzzer() { this._tone({ freq: 340, dur: 0.9, type: 'square', gain: 0.2 }); this._tone({ freq: 344, dur: 0.9, type: 'square', gain: 0.14 }); }
  click() { this._tone({ freq: 640, freqEnd: 480, dur: 0.06, type: 'triangle', gain: 0.12 }); }
  swoosh() { this._burst({ dur: 0.18, freq: 900, q: 0.8, gain: 0.22, pitchEnd: 2600 }); }
  // GREEN GIANT — deep boom + bright arp + crowd roar
  green() {
    this._tone({ freq: 65, freqEnd: 38, dur: 0.5, type: 'sine', gain: 0.55 });
    const notes = [523.25, 659.25, 783.99, 1046.5];
    notes.forEach((f, i) => setTimeout(() => this._tone({ freq: f, dur: 0.3, type: 'triangle', gain: 0.16 }), i * 70));
    this._burst({ dur: 0.9, freq: 700, gain: 0.3, type: 'bandpass', pitchEnd: 1600 });
    this.crowd(1);
  }
  ankles() {
    this._tone({ freq: 480, freqEnd: 160, dur: 0.3, type: 'sawtooth', gain: 0.2 });
    setTimeout(() => this._burst({ dur: 0.12, freq: 1800, q: 2, gain: 0.3 }), 60);
    setTimeout(() => this._burst({ dur: 0.12, freq: 1200, q: 2, gain: 0.25 }), 140);
  }
  dunk() {
    this._tone({ freq: 95, freqEnd: 40, dur: 0.3, type: 'square', gain: 0.4 });
    this._burst({ dur: 0.2, freq: 300, gain: 0.5, type: 'lowpass' });
    this.rim();
    this.crowd(0.8);
  }
  cheer() {
    this._burst({ dur: 1.1, freq: 850, q: 0.5, gain: 0.34, type: 'bandpass', pitchEnd: 1300 });
    this.crowd(0.9);
  }
  netMove() { this._burst({ dur: 0.14, freq: 2200, q: 0.8, gain: 0.12, pitchEnd: 900 }); }
}
export const SFX = new AudioEngine();
