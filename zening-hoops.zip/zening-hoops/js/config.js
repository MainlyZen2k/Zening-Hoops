// ============ ZENING HOOPS — config, save system, catalog ============
export const COURT = {
  HALF_L: 14.3, HALF_W: 7.62,
  RIM_H: 3.045, RIM_R: 0.2286, RIM_X: 12.725, BOARD_X: 13.1,
  BOARD_W: 1.83, BOARD_H: 1.05, BOARD_BOT: 2.9,
  THREE_D: 7.24, G: 9.81, BALL_R: 0.1215,
  PLAYER_H: 1.98
};

export const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
export const lerp = (a, b, t) => a + (b - a) * t;
export const rand = (a, b) => a + Math.random() * (b - a);
export const dist2d = (ax, az, bx, bz) => Math.hypot(ax - bx, az - bz);

export const DIFFICULTY = [
  { name: 'ROOKIE',  react: 0.42, shotQ: 0.52, moveFreq: 0.35, contest: 0.5, steal: 0.18, speed: 0.92 },
  { name: 'PRO',     react: 0.26, shotQ: 0.68, moveFreq: 0.55, contest: 0.75, steal: 0.26, speed: 1.0 },
  { name: 'ALL-STAR',react: 0.14, shotQ: 0.80, moveFreq: 0.72, contest: 0.95, steal: 0.34, speed: 1.06 }
];

// ---------------- Shop catalog ----------------
export const CATALOG = {
  balls: [
    { id: 'classic', name: 'CLASSIC', price: 0,   color: '#d2691e', glow: '#00000000' },
    { id: 'neon',    name: 'NEON',    price: 400, color: '#1f3a1a', glow: '#35e06a' },
    { id: 'gold',    name: 'GOLD',    price: 900, color: '#e9b44c', glow: '#ffcf7d' },
    { id: 'galaxy',  name: 'GALAXY',  price: 1500,color: '#3a1f5a', glow: '#b06aff' }
  ],
  trails: [
    { id: 'none',    name: 'NONE',    price: 0,   color: '#00000000', glow: '#00000000' },
    { id: 'green',   name: 'GREEN',   price: 350, color: '#35e06a', glow: '#35e06a' },
    { id: 'fire',    name: 'FIRE',    price: 700, color: '#ff7b2e', glow: '#ff5e1a' },
    { id: 'ice',     name: 'ICE',     price: 700, color: '#8ad8ff', glow: '#5ec2ff' },
    { id: 'rainbow', name: 'RAINBOW', price: 1200,color: '#ff5ad2', glow: '#ff5ad2' }
  ],
  auras: [
    { id: 'none',  name: 'NONE',  price: 0,   color: '#00000000', glow: '#00000000' },
    { id: 'gold',  name: 'GOLD',  price: 600, color: '#e9b44c', glow: '#e9b44c' },
    { id: 'green', name: 'GREEN', price: 800, color: '#35e06a', glow: '#35e06a' }
  ]
};

export const JERSEY_COLORS = ['#e05038','#e9b44c','#35e06a','#3ba7e0','#b06aff','#f3e2c3','#2b1c0e','#ff5ad2'];
export const BAND_COLORS   = ['#f3e2c3','#e05038','#e9b44c','#35e06a','#3ba7e0','#b06aff','#ff5ad2','#d2691e'];

export const MODES = {
  blacktop: { name: 'BLACKTOP RUN',      target: 11, players: 2, clock: 180 },
  classic:  { name: 'THANKSGIVING CLASSIC', target: 21, players: 4, clock: 240 },
  sudden:   { name: 'SUDDEN DEATH',      target: 1,  players: 2, clock: 120 },
  free:     { name: 'FREE PLAY',         target: 0,  players: 1, clock: 0 }
};

// ---------------- Save system ----------------
const KEY = 'zening_hoops_save_v1';
const DEFAULT_SAVE = {
  coins: 250,
  unlocked: ['ball:classic', 'trail:none', 'aura:none'],
  equip: { ball: 'classic', trail: 'none', aura: 'none', jersey: '#e05038', band: '#f3e2c3', number: 7 },
  stats: { games: 0, wins: 0, points: 0, greens: 0, ankles: 0, steals: 0, blocks: 0, dunks: 0 },
  settings: { vol: 0.8, music: true, quality: 'high', difficulty: 1 },
  seenTut: false
};

function deepMerge(base, over) {
  const out = { ...base };
  for (const k in over) {
    if (over[k] && typeof over[k] === 'object' && !Array.isArray(over[k]) && typeof base[k] === 'object') {
      out[k] = deepMerge(base[k], over[k]);
    } else out[k] = over[k];
  }
  return out;
}

export const SAVE = {
  data: null,
  load() {
    try {
      const raw = localStorage.getItem(KEY);
      this.data = raw ? deepMerge(DEFAULT_SAVE, JSON.parse(raw)) : { ...DEFAULT_SAVE };
    } catch (e) { this.data = { ...DEFAULT_SAVE }; }
    return this.data;
  },
  save() {
    try { localStorage.setItem(KEY, JSON.stringify(this.data)); } catch (e) { /* private mode */ }
  },
  reset() {
    try { localStorage.removeItem(KEY); } catch (e) { /* noop */ }
    this.data = { ...DEFAULT_SAVE };
    this.save();
  },
  addCoins(n) { this.data.coins = Math.max(0, this.data.coins + n); this.save(); },
  buy(item) {
    if (this.data.unlocked.includes(item)) return true;
    const cat = this.findItem(item);
    if (!cat || this.data.coins < cat.price) return false;
    this.data.coins -= cat.price;
    this.data.unlocked.push(item);
    this.save();
    return true;
  },
  equip(item) {
    this.data.equip[item.split(':')[0]] = item.split(':')[1];
    this.save();
  },
  findItem(id) {
    const [cat] = id.split(':');
    const list = cat === 'ball' ? CATALOG.balls : cat === 'trail' ? CATALOG.trails : CATALOG.auras;
    return list.find(i => i.id === id.split(':')[1]);
  },
  stat(key, n = 1) {
    if (this.data.stats[key] !== undefined) this.data.stats[key] += n;
    this.save();
  }
};
