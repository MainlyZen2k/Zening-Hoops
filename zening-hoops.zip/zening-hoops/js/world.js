// ============ ZENING HOOPS — 3D world: court, hoops, nets, park, crowd, decor ============
import * as THREE from 'three';
import { COURT, clamp } from './config.js';

const H = COURT;
const px = 71.6, pz = 71.4; // texture pixels per meter (2048 x 1088 canvas)

function courtTexture() {
  const W = 2048, Ht = 1088;
  const c = document.createElement('canvas'); c.width = W; c.height = Ht;
  const g = c.getContext('2d');
  const mx = x => (x + H.HALF_L) * px;
  const mz = z => (z + H.HALF_W) * pz;
  // asphalt apron
  g.fillStyle = '#2a231b'; g.fillRect(0, 0, W, Ht);
  // hardwood planks
  const cy0 = mz(-H.HALF_W), cw = H.HALF_W * 2 * pz, cx0 = mx(-H.HALF_L), ch = H.HALF_L * 2 * px;
  g.save(); g.beginPath(); g.rect(cx0, cy0, ch, cw); g.clip();
  for (let y = cy0; y < cy0 + cw; y += 15) {
    const tone = 176 + Math.floor(Math.random() * 26) - 13;
    g.fillStyle = `rgb(${tone + 22},${tone - 28},${tone - 74})`;
    g.fillRect(cx0, y, ch, 15);
    g.fillStyle = 'rgba(60,34,14,0.5)'; g.fillRect(cx0, y, ch, 1.5);
    for (let i = 0; i < 26; i++) {
      const sx = cx0 + Math.random() * ch;
      g.fillStyle = `rgba(80,48,20,${0.06 + Math.random() * 0.1})`;
      g.fillRect(sx, y, 30 + Math.random() * 90, 1.2);
    }
  }
  // painted zones
  const paint = '#b5561f', line = '#f3e2c3', lw = 5;
  for (const s of [1, -1]) {
    const bx = mx(s * H.HALF_L); // baseline
    // key / paint
    g.fillStyle = paint;
    g.fillRect(Math.min(bx, mx(s * (H.HALF_L - 5.79))), mz(-2.44), 5.79 * px, 4.88 * pz);
    // key border
    g.strokeStyle = line; g.lineWidth = lw;
    g.strokeRect(Math.min(bx, mx(s * (H.HALF_L - 5.79))), mz(-2.44), 5.79 * px, 4.88 * pz);
    // FT circle
    const ftx = mx(s * (H.HALF_L - 5.79));
    g.beginPath(); g.arc(ftx, mz(0), 1.8 * px, 0, Math.PI * 2); g.stroke();
    // rim + restricted arc
    const rx = mx(s * H.RIM_X);
    g.beginPath(); g.arc(rx, mz(0), 1.25 * px, s === 1 ? Math.PI * 0.5 : -Math.PI * 0.5, s === 1 ? Math.PI * 1.5 : Math.PI * 0.5); g.stroke();
    // three point line
    const R3 = H.THREE_D * px, corZ = 6.71, dx = Math.sqrt(R3 * R3 - (corZ * pz) * (corZ * pz));
    const cornerX = rx - s * dx, baseX = mx(s * H.HALF_L);
    g.beginPath();
    g.moveTo(baseX, mz(-corZ)); g.lineTo(cornerX, mz(-corZ));
    let a1 = Math.atan2(mz(-corZ) - mz(0), cornerX - rx);
    let a2 = Math.atan2(mz(corZ) - mz(0), cornerX - rx);
    if (a2 < a1) a2 += Math.PI * 2;
    g.arc(rx, mz(0), R3, a1, a2);
    g.lineTo(baseX, mz(corZ));
    g.stroke();
    // hash marks
    for (let zz = -2.44; zz <= 2.44; zz += 0.9) {
      const hx = mx(s * (H.HALF_L - 5.79));
      g.beginPath(); g.moveTo(hx - s * 14, mz(zz)); g.lineTo(hx, mz(zz)); g.stroke();
    }
  }
  // center circle + wordmark
  g.fillStyle = 'rgba(181,86,31,0.85)';
  g.beginPath(); g.arc(mx(0), mz(0), 1.8 * px, 0, Math.PI * 2); g.fill();
  g.strokeStyle = '#e9b44c'; g.lineWidth = 7;
  g.beginPath(); g.arc(mx(0), mz(0), 1.8 * px, 0, Math.PI * 2); g.stroke();
  g.fillStyle = 'rgba(243,226,195,0.92)';
  g.font = '900 118px Arial Black, Arial'; g.textAlign = 'center'; g.textBaseline = 'middle';
  g.fillText('ZH', mx(0), mz(0) - 10);
  g.font = '800 30px Arial'; g.fillStyle = 'rgba(243,226,195,0.75)';
  g.fillText('ZENING  HOOPS', mx(0), mz(0) + 72);
  // outer border
  g.strokeStyle = line; g.lineWidth = lw + 2;
  g.strokeRect(cx0, cy0, ch, cw);
  g.restore();
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace; tex.anisotropy = 8;
  return tex;
}

function chainLinkTexture() {
  const c = document.createElement('canvas'); c.width = c.height = 128;
  const g = c.getContext('2d'); g.clearRect(0, 0, 128, 128);
  g.strokeStyle = 'rgba(150,150,150,0.85)'; g.lineWidth = 2.5;
  for (let i = -128; i < 256; i += 22) {
    g.beginPath(); g.moveTo(i, 0); g.lineTo(i + 128, 128); g.stroke();
    g.beginPath(); g.moveTo(i + 128, 0); g.lineTo(i, 128); g.stroke();
  }
  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(14, 2.6);
  return t;
}

function bannerTexture(text) {
  const c = document.createElement('canvas'); c.width = 1024; c.height = 256;
  const g = c.getContext('2d');
  const grad = g.createLinearGradient(0, 0, 0, 256);
  grad.addColorStop(0, '#7a3a10'); grad.addColorStop(1, '#5a2a0c');
  g.fillStyle = grad; g.fillRect(0, 0, 1024, 256);
  g.strokeStyle = '#e9b44c'; g.lineWidth = 10; g.strokeRect(14, 14, 996, 228);
  g.fillStyle = '#f3e2c3'; g.textAlign = 'center'; g.textBaseline = 'middle';
  g.font = '900 78px Arial Black, Arial';
  g.fillText(text, 512, 118);
  g.font = '800 40px Arial'; g.fillStyle = '#e9b44c';
  g.fillText('NOVEMBER 2026', 512, 196);
  // painted leaves
  g.fillStyle = 'rgba(233,180,76,.8)';
  for (const lx of [90, 934]) {
    g.beginPath(); g.ellipse(lx, 128, 34, 54, 0.6, 0, Math.PI * 2); g.fill();
    g.beginPath(); g.ellipse(lx + 46, 90, 26, 42, -0.5, 0, Math.PI * 2); g.fill();
  }
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

function scoreboardTexture() {
  const c = document.createElement('canvas'); c.width = 512; c.height = 256;
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace;
  return { tex: t, canvas: c };
}

function buildingTexture() {
  const c = document.createElement('canvas'); c.width = 256; c.height = 512;
  const g = c.getContext('2d');
  g.fillStyle = '#241a14'; g.fillRect(0, 0, 256, 512);
  for (let y = 20; y < 490; y += 44) for (let x = 18; x < 240; x += 40) {
    const lit = Math.random() < 0.42;
    g.fillStyle = lit ? (Math.random() < 0.5 ? '#e9b44c' : '#d2691e') : '#171009';
    g.fillRect(x, y, 26, 30);
  }
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace;
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  return t;
}

function skyTexture() {
  const c = document.createElement('canvas'); c.width = 16; c.height = 512;
  const g = c.getContext('2d');
  const grad = g.createLinearGradient(0, 0, 0, 512);
  grad.addColorStop(0, '#1d1026'); grad.addColorStop(0.42, '#4a2334');
  grad.addColorStop(0.72, '#8a4530'); grad.addColorStop(1, '#d2763c');
  g.fillStyle = grad; g.fillRect(0, 0, 16, 512);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

// ---------------- Verlet net ----------------
class Net {
  constructor(rimCenter, facing, scene) {
    this.S = 10; this.R = 5; this.len = 0.45; this.facing = facing;
    this.nodes = []; this.constraints = [];
    for (let i = 0; i < this.S; i++) {
      const row = [];
      for (let j = 0; j < this.R; j++) {
        const k = j / (this.R - 1);
        const rad = H.RIM_R * (1 - k * 0.42);
        const a = (i / this.S) * Math.PI * 2;
        row.push({
          p: new THREE.Vector3(rimCenter.x - facing * 0.02 + Math.cos(a) * rad, rimCenter.y - k * this.len, rimCenter.z + Math.sin(a) * rad),
          o: new THREE.Vector3().copy(row[j] ? row[j].p : new THREE.Vector3()),
          fixed: j === 0
        });
      }
      this.nodes.push(row);
    }
    // vertical constraints
    for (let i = 0; i < this.S; i++) for (let j = 0; j < this.R - 1; j++)
      this.constraints.push([this.nodes[i][j], this.nodes[i][j + 1], this.len / (this.R - 1)]);
    // ring constraints
    for (let j = 1; j < this.R; j++) {
      const k = j / (this.R - 1), rad = H.RIM_R * (1 - k * 0.42);
      const rest = (2 * Math.PI * rad / this.S) * 0.92;
      for (let i = 0; i < this.S; i++) this.constraints.push([this.nodes[i][j], this.nodes[(i + 1) % this.S][j], rest]);
    }
    const segs = this.S * (this.R - 1) + this.R * this.S;
    this.geo = new THREE.BufferGeometry();
    this.verts = new Float32Array(segs * 6);
    this.geo.setAttribute('position', new THREE.BufferAttribute(this.verts, 3));
    this.mesh = new THREE.LineSegments(this.geo, new THREE.LineBasicMaterial({ color: 0xf3ede0, transparent: true, opacity: 0.92 }));
    this.mesh.frustumCulled = false;
    scene.add(this.mesh);
    this.swishTimer = 0;
  }
  collideBall(ball) {
    const bp = ball.mesh.position;
    for (const row of this.nodes) for (const n of row) {
      if (n.fixed) continue;
      const d = n.p.distanceTo(bp);
      if (d < H.BALL_R + 0.03) {
        const push = n.p.clone().sub(bp).normalize().multiplyScalar((H.BALL_R + 0.04 - d));
        n.p.add(push);
        n.p.addScaledVector(ball.vel, 0.014);
      }
    }
  }
  update(dt) {
    dt = Math.min(dt, 0.033);
    for (const row of this.nodes) for (const n of row) {
      if (n.fixed) continue;
      const v = n.p.clone().sub(n.o).multiplyScalar(0.94);
      n.o.copy(n.p);
      n.p.add(v); n.p.y -= 5.2 * dt * dt;
    }
    for (let it = 0; it < 3; it++) for (const [a, b, rest] of this.constraints) {
      const d = b.p.clone().sub(a.p), L = d.length() || 0.0001, diff = (L - rest) / L * 0.5;
      if (!a.fixed) a.p.addScaledVector(d, diff);
      if (!b.fixed) b.p.addScaledVector(d, -diff);
    }
    let k = 0;
    for (let i = 0; i < this.S; i++) for (let j = 0; j < this.R - 1; j++) {
      const a = this.nodes[i][j].p, b = this.nodes[i][j + 1].p;
      this.verts.set([a.x, a.y, a.z, b.x, b.y, b.z], k); k += 6;
    }
    for (let j = 0; j < this.R; j++) for (let i = 0; i < this.S; i++) {
      const a = this.nodes[i][j].p, b = this.nodes[(i + 1) % this.S][j].p;
      this.verts.set([a.x, a.y, a.z, b.x, b.y, b.z], k); k += 6;
    }
    this.geo.attributes.position.needsUpdate = true;
  }
}

// ---------------- World ----------------
export class World {
  constructor() {
    this.hoops = []; this.crowdData = []; this.birds = []; this.clouds = [];
    this.lights = {}; this.time = 0;
  }
  init(canvas, quality) {
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: quality === 'high', powerPreference: 'high-performance' });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.12;
    this.renderer.shadowMap.enabled = quality === 'high';
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.applyQuality(quality);

    this.scene = new THREE.Scene();
    this.scene.fog = new THREE.Fog(0x3a2317, 55, 165);
    this.camera = new THREE.PerspectiveCamera(50, innerWidth / innerHeight, 0.1, 260);
    this.camera.position.set(0, 7.8, 14.5);

    this._buildSky();
    this._buildLights();
    this._buildCourt();
    this._buildHoops();
    this._buildPark();
    this._buildCrowd();
  }
  applyQuality(q) {
    this.quality = q;
    this.renderer.setPixelRatio(Math.min(devicePixelRatio || 1, q === 'high' ? 2 : 1.3));
    if (this.lights.sun) this.lights.sun.castShadow = q === 'high';
    if (this.lights.spots) this.lights.spots.forEach(s => s.visible = q === 'high');
  }
  resize() {
    this.camera.aspect = innerWidth / innerHeight;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(innerWidth, innerHeight, false);
  }
  _buildSky() {
    const sky = new THREE.Mesh(new THREE.SphereGeometry(120, 24, 16),
      new THREE.MeshBasicMaterial({ map: skyTexture(), side: THREE.BackSide, fog: false }));
    this.scene.add(sky);
    // sun glow sprite
    const c = document.createElement('canvas'); c.width = c.height = 128;
    const g = c.getContext('2d');
    const grad = g.createRadialGradient(64, 64, 4, 64, 64, 62);
    grad.addColorStop(0, 'rgba(255,190,110,1)'); grad.addColorStop(0.35, 'rgba(255,150,70,.5)'); grad.addColorStop(1, 'rgba(255,120,50,0)');
    g.fillStyle = grad; g.fillRect(0, 0, 128, 128);
    const sun = new THREE.Sprite(new THREE.SpriteMaterial({ map: new THREE.CanvasTexture(c), transparent: true, depthWrite: false, fog: false }));
    sun.scale.setScalar(34); sun.position.set(-55, 12, -58);
    this.scene.add(sun);
    // clouds
    const cc = document.createElement('canvas'); cc.width = 256; cc.height = 128;
    const cg = cc.getContext('2d');
    for (const [cx, cy, r] of [[80, 70, 34], [120, 60, 42], [160, 72, 30], [105, 80, 28]]) {
      const grd = cg.createRadialGradient(cx, cy, 4, cx, cy, r);
      grd.addColorStop(0, 'rgba(255,190,160,.55)'); grd.addColorStop(1, 'rgba(255,170,130,0)');
      cg.fillStyle = grd; cg.beginPath(); cg.arc(cx, cy, r, 0, Math.PI * 2); cg.fill();
    }
    const ctex = new THREE.CanvasTexture(cc);
    for (let i = 0; i < 7; i++) {
      const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: ctex, transparent: true, depthWrite: false, fog: false, opacity: 0.7 }));
      s.scale.set(26 + Math.random() * 18, 9 + Math.random() * 5, 1);
      s.position.set(-60 + Math.random() * 120, 26 + Math.random() * 18, -70 + Math.random() * 60);
      this.scene.add(s);
      this.clouds.push({ s, spd: 0.2 + Math.random() * 0.35 });
    }
    // birds
    const bc = document.createElement('canvas'); bc.width = bc.height = 64;
    const bg = bc.getContext('2d');
    bg.strokeStyle = '#1a1008'; bg.lineWidth = 4; bg.lineCap = 'round';
    bg.beginPath(); bg.moveTo(14, 34); bg.quadraticCurveTo(26, 20, 32, 32); bg.quadraticCurveTo(38, 20, 50, 34); bg.stroke();
    const btex = new THREE.CanvasTexture(bc);
    for (let i = 0; i < 6; i++) {
      const b = new THREE.Sprite(new THREE.SpriteMaterial({ map: btex, transparent: true, fog: false }));
      b.scale.setScalar(0.9 + Math.random() * 0.7);
      this.scene.add(b);
      this.birds.push({ s: b, r: 20 + Math.random() * 22, a: Math.random() * Math.PI * 2, h: 16 + Math.random() * 10, spd: 0.1 + Math.random() * 0.15 });
    }
  }
  _buildLights() {
    const hemi = new THREE.HemisphereLight(0xffc9a0, 0x3a2415, 0.85);
    this.scene.add(hemi);
    const sun = new THREE.DirectionalLight(0xffa56a, 1.6);
    sun.position.set(-26, 20, 12);
    sun.castShadow = true;
    sun.shadow.mapSize.set(2048, 2048);
    sun.shadow.camera.left = -20; sun.shadow.camera.right = 20;
    sun.shadow.camera.top = 20; sun.shadow.camera.bottom = -20;
    sun.shadow.camera.far = 70; sun.shadow.bias = -0.0004;
    this.scene.add(sun);
    this.lights.sun = sun;
    // fill
    const fill = new THREE.DirectionalLight(0x8a6a4a, 0.35);
    fill.position.set(20, 10, -18);
    this.scene.add(fill);
    // park spotlights on poles
    this.lights.spots = [];
    for (const [sx, sz] of [[-17.5, -10.5], [17.5, 10.5]]) {
      const sp = new THREE.SpotLight(0xffd9a0, 260, 42, 0.62, 0.5, 1.6);
      sp.position.set(sx, 9.4, sz); sp.target.position.set(sx * 0.2, 0, sz * 0.2);
      this.scene.add(sp); this.scene.add(sp.target);
      this.lights.spots.push(sp);
    }
  }
  _buildCourt() {
    // ground
    const gc = document.createElement('canvas'); gc.width = gc.height = 512;
    const gg = gc.getContext('2d');
    gg.fillStyle = '#221a12'; gg.fillRect(0, 0, 512, 512);
    for (let i = 0; i < 2400; i++) {
      gg.fillStyle = `rgba(${40 + Math.random() * 40},${30 + Math.random() * 30},${18 + Math.random() * 16},.5)`;
      gg.fillRect(Math.random() * 512, Math.random() * 512, 3, 3);
    }
    const gtex = new THREE.CanvasTexture(gc); gtex.colorSpace = THREE.SRGBColorSpace;
    gtex.wrapS = gtex.wrapT = THREE.RepeatWrapping; gtex.repeat.set(24, 24);
    const ground = new THREE.Mesh(new THREE.PlaneGeometry(240, 240), new THREE.MeshStandardMaterial({ map: gtex, roughness: 1 }));
    ground.rotation.x = -Math.PI / 2; ground.position.y = -0.012; ground.receiveShadow = false;
    this.scene.add(ground);
    // court
    const court = new THREE.Mesh(new THREE.PlaneGeometry(H.HALF_L * 2, H.HALF_W * 2),
      new THREE.MeshStandardMaterial({ map: courtTexture(), roughness: 0.42, metalness: 0.05 }));
    court.rotation.x = -Math.PI / 2; court.receiveShadow = true;
    this.scene.add(court);
  }
  _buildHoops() {
    for (const facing of [1, -1]) {
      const g = new THREE.Group();
      const bx = facing * H.BOARD_X, rx = facing * H.RIM_X;
      // stanchion
      const dark = new THREE.MeshStandardMaterial({ color: 0x2a2a2e, roughness: 0.6, metalness: 0.5 });
      const pad = new THREE.MeshStandardMaterial({ color: 0xb5561f, roughness: 0.85 });
      const base = new THREE.Mesh(new THREE.BoxGeometry(1.15, 0.9, 1.5), pad);
      base.position.set(facing * (H.BOARD_X + 1.9), 0.45, 0); base.castShadow = true;
      const pole = new THREE.Mesh(new THREE.BoxGeometry(0.24, 3.6, 0.24), dark);
      pole.position.set(facing * (H.BOARD_X + 1.45), 1.8, 0); pole.castShadow = true;
      const arm = new THREE.Mesh(new THREE.BoxGeometry(1.6, 0.14, 0.14), dark);
      arm.position.set(facing * (H.BOARD_X + 0.62), 3.6, 0); arm.rotation.z = facing * -0.18; arm.castShadow = true;
      const padPole = new THREE.Mesh(new THREE.BoxGeometry(0.5, 2.2, 0.5), pad);
      padPole.position.set(facing * (H.BOARD_X + 1.45), 1.1, 0);
      g.add(base, pole, arm, padPole);
      // backboard
      const bc = document.createElement('canvas'); bc.width = 512; bc.height = 300;
      const bg = bc.getContext('2d');
      bg.fillStyle = 'rgba(235,240,245,0.32)'; bg.fillRect(0, 0, 512, 300);
      bg.strokeStyle = '#f0f0f0'; bg.lineWidth = 14; bg.strokeRect(7, 7, 498, 286);
      bg.strokeStyle = '#e05038'; bg.lineWidth = 10; bg.strokeRect(180, 150, 152, 118);
      const btex = new THREE.CanvasTexture(bc); btex.colorSpace = THREE.SRGBColorSpace;
      const board = new THREE.Mesh(new THREE.BoxGeometry(0.06, H.BOARD_H, H.BOARD_W),
        new THREE.MeshStandardMaterial({ map: btex, transparent: true, opacity: 0.55, roughness: 0.15, metalness: 0.1 }));
      board.position.set(bx, H.BOARD_BOT + H.BOARD_H / 2, 0); board.castShadow = true;
      g.add(board);
      // rim + plate
      const rimMat = new THREE.MeshStandardMaterial({ color: 0xff5f1f, roughness: 0.35, metalness: 0.7 });
      const rim = new THREE.Mesh(new THREE.TorusGeometry(H.RIM_R, 0.021, 10, 36), rimMat);
      rim.rotation.x = Math.PI / 2;
      rim.position.set(rx, H.RIM_H, 0); rim.castShadow = true;
      const plate = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.1, 0.12), rimMat);
      plate.position.set(bx - facing * 0.14, H.RIM_H + 0.02, 0);
      g.add(rim, plate);
      // net
      const net = new Net(new THREE.Vector3(rx, H.RIM_H, 0), facing, this.scene);
      this.scene.add(g);
      this.hoops.push({ facing, rimCenter: new THREE.Vector3(rx, H.RIM_H, 0), boardX: bx, net, group: g, rimMesh: rim });
    }
  }
  _buildPark() {
    const FH = 3.6, FX = 17.6, FZ = 10.8;
    const chainMat = new THREE.MeshStandardMaterial({ map: chainLinkTexture(), transparent: true, alphaTest: 0.4, side: THREE.DoubleSide, roughness: 0.8, metalness: 0.4 });
    const fence = (w, x, z, ry) => {
      const m = new THREE.Mesh(new THREE.PlaneGeometry(w, FH), chainMat);
      m.position.set(x, FH / 2, z); m.rotation.y = ry;
      this.scene.add(m);
    };
    fence(FX * 2, 0, -FZ, 0); fence(FX * 2, 0, FZ, 0);
    fence(FZ * 2, -FX, 0, Math.PI / 2); fence(FZ * 2, FX, 0, Math.PI / 2);
    // fence posts
    const postGeo = new THREE.CylinderGeometry(0.06, 0.06, FH, 8);
    const postMat = new THREE.MeshStandardMaterial({ color: 0x35402a, roughness: 0.7, metalness: 0.4 });
    const posts = [];
    for (let x = -FX; x <= FX; x += FX / 2) { posts.push([x, -FZ, 0]); posts.push([x, FZ, 0]); }
    for (let z = -FZ; z <= FZ; z += FZ / 2) { posts.push([-FX, z, 1]); posts.push([FX, z, 1]); }
    const postIM = new THREE.InstancedMesh(postGeo, postMat, posts.length);
    const M = new THREE.Matrix4();
    posts.forEach((p, i) => { M.makeRotationY(p[2] ? Math.PI / 2 : 0); M.setPosition(p[0], FH / 2, p[1]); postIM.setMatrixAt(i, M); });
    this.scene.add(postIM);
    // bunting (thanksgiving pennants)
    const bc = document.createElement('canvas'); bc.width = 512; bc.height = 64;
    const bg = bc.getContext('2d'); bg.clearRect(0, 0, 512, 64);
    const cols = ['#e9b44c', '#d2691e', '#b03030', '#e9b44c', '#8a5a2a'];
    for (let i = 0; i < 16; i++) {
      bg.fillStyle = cols[i % cols.length];
      bg.beginPath(); bg.moveTo(i * 32, 4); bg.lineTo(i * 32 + 32, 4); bg.lineTo(i * 32 + 16, 52); bg.closePath(); bg.fill();
    }
    const btex = new THREE.CanvasTexture(bc); btex.colorSpace = THREE.SRGBColorSpace;
    btex.wrapS = THREE.RepeatWrapping; btex.repeat.set(8, 1);
    for (const z of [-FZ, FZ]) {
      const b = new THREE.Mesh(new THREE.PlaneGeometry(FX * 2, 0.55), new THREE.MeshBasicMaterial({ map: btex, side: THREE.DoubleSide, transparent: true }));
      b.position.set(0, FH + 0.28, z);
      this.scene.add(b);
    }
    // banner behind east hoop (faces the court: default plane normal is +z)
    const banner = new THREE.Mesh(new THREE.PlaneGeometry(10, 2.5), new THREE.MeshBasicMaterial({ map: bannerTexture('HAPPY THANKSGIVING CLASSIC'), side: THREE.DoubleSide }));
    banner.position.set(0, 5.6, -FZ - 0.4);
    this.scene.add(banner);
    // string lights
    const bulbGeo = new THREE.SphereGeometry(0.055, 6, 6);
    const bulbMat = new THREE.MeshBasicMaterial({ color: 0xffd9a0 });
    const bulbs = [];
    for (let x = -FX; x <= FX; x += 1.4) { bulbs.push([x, FH + 0.5, -FZ + 0.15]); bulbs.push([x, FH + 0.5, FZ - 0.15]); }
    this.bulbs = new THREE.InstancedMesh(bulbGeo, bulbMat, bulbs.length);
    bulbs.forEach((p, i) => { M.identity(); M.setPosition(p[0], p[1], p[2]); this.bulbs.setMatrixAt(i, M); });
    this.scene.add(this.bulbs);
    // pumpkins
    const pumpMat = new THREE.MeshStandardMaterial({ color: 0xd2691e, roughness: 0.55 });
    const stemMat = new THREE.MeshStandardMaterial({ color: 0x4a5a2a, roughness: 0.9 });
    for (const [pxp, pzp, s] of [[-15.5, -9.6, 0.42], [-14.6, -9.9, 0.3], [15.6, 9.7, 0.38], [14.8, 10.1, 0.26], [-16.4, 9.8, 0.34], [0.5, -10.3, 0.3]]) {
      const p = new THREE.Mesh(new THREE.SphereGeometry(s, 12, 10), pumpMat);
      p.scale.y = 0.78; p.position.set(pxp, s * 0.7, pzp); p.castShadow = false;
      const st = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.05, s * 0.5, 6), stemMat);
      st.position.set(pxp, s * 0.7 + s * 0.75, pzp);
      this.scene.add(p, st);
    }
    // trees (autumn)
    const trunkGeo = new THREE.CylinderGeometry(0.16, 0.24, 2.6, 7);
    const trunkMat = new THREE.MeshStandardMaterial({ color: 0x4a3018, roughness: 1 });
    const foliGeo = new THREE.SphereGeometry(1.5, 10, 8);
    const foliMat = new THREE.MeshStandardMaterial({ color: 0xd2691e, roughness: 1 });
    const treePos = [];
    for (let i = 0; i < 26; i++) {
      const a = (i / 26) * Math.PI * 2 + 0.2;
      const r = 24 + Math.random() * 16;
      treePos.push([Math.cos(a) * r, Math.sin(a) * r * 0.62]);
    }
    const trunks = new THREE.InstancedMesh(trunkGeo, trunkMat, treePos.length);
    const folis = new THREE.InstancedMesh(foliGeo, foliMat.clone(), treePos.length);
    const autumn = [0xd2691e, 0xb03030, 0xe9a13b, 0x8a5a2a, 0xc2452a];
    treePos.forEach((p, i) => {
      M.identity(); M.setPosition(p[0], 1.3, p[1]); trunks.setMatrixAt(i, M);
      M.identity();
      const s = 0.8 + Math.random() * 0.7;
      M.makeScale(s, s * 0.9, s); M.setPosition(p[0], 2.9, p[1]); folis.setMatrixAt(i, M);
      folis.setColorAt(i, new THREE.Color(autumn[i % autumn.length]));
    });
    folis.instanceColor.needsUpdate = true;
    this.scene.add(trunks, folis);
    // light poles
    for (const [sx, sz] of [[-17.5, -10.5], [17.5, 10.5]]) {
      const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.12, 9.4, 8), new THREE.MeshStandardMaterial({ color: 0x2a2a2e, roughness: 0.6, metalness: 0.5 }));
      pole.position.set(sx, 4.7, sz);
      const head = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.22, 0.5), new THREE.MeshStandardMaterial({ color: 0x2a2a2e }));
      head.position.set(sx, 9.4, sz);
      const lamp = new THREE.Mesh(new THREE.PlaneGeometry(0.7, 0.35), new THREE.MeshBasicMaterial({ color: 0xffd9a0 }));
      lamp.rotation.x = Math.PI / 2; lamp.position.set(sx, 9.27, sz);
      this.scene.add(pole, head, lamp);
    }
    // buildings backdrop
    const bwin = buildingTexture();
    const bdefs = [
      [-38, 14, -52, 16, 22, 0.3], [-10, 20, -58, 18, 26, 0.2], [22, 15, -55, 14, 24, -0.3],
      [48, 18, -44, 16, 28, 0.6], [-52, 12, -20, 20, 30, Math.PI / 2], [55, 14, -18, 22, 26, -Math.PI / 2]
    ];
    for (const [bx, w, bz, d, hgt, ry] of bdefs) {
      const mat = new THREE.MeshStandardMaterial({ map: bwin.clone(), roughness: 1 });
      mat.map.repeat.set(Math.round(w / 4), Math.round(hgt / 6));
      const b = new THREE.Mesh(new THREE.BoxGeometry(w, hgt, d), mat);
      b.position.set(bx, hgt / 2, bz); b.rotation.y = ry;
      this.scene.add(b);
    }
    // bleachers + scoreboard
    const benchMat = new THREE.MeshStandardMaterial({ color: 0x3a2c1c, roughness: 0.9 });
    for (let row = 0; row < 3; row++) {
      const b = new THREE.Mesh(new THREE.BoxGeometry(26, 0.5, 1.6), benchMat);
      b.position.set(0, 0.35 + row * 0.55, FZ + 2.2 + row * 1.7);
      this.scene.add(b);
    }
    const { tex: sbTex, canvas: sbCanvas } = scoreboardTexture();
    this.sb = { tex: sbTex, canvas: sbCanvas };
    const sb = new THREE.Mesh(new THREE.PlaneGeometry(7.5, 3.75), new THREE.MeshBasicMaterial({ map: sbTex }));
    sb.position.set(0, 6.4, FZ + 8.5); sb.rotation.y = Math.PI;
    const sbBack = new THREE.Mesh(new THREE.BoxGeometry(7.7, 4, 0.25), new THREE.MeshStandardMaterial({ color: 0x1a120b }));
    sbBack.position.set(0, 6.4, FZ + 8.7);
    this.scene.add(sb, sbBack);
    this.setScore(0, 0, 'ZENING HOOPS');
    // light poles render shadowless; court-side hoop shadows handled by sun
  }
  setScore(you, cpu, label) {
    const g = this.sb.canvas.getContext('2d');
    g.fillStyle = '#120a05'; g.fillRect(0, 0, 512, 256);
    g.strokeStyle = '#4a3018'; g.lineWidth = 8; g.strokeRect(8, 8, 496, 240);
    g.fillStyle = '#e9b44c'; g.font = '800 30px Arial'; g.textAlign = 'center';
    g.fillText((label || 'ZENING HOOPS').toUpperCase(), 256, 52);
    g.font = '900 92px Arial Black, Arial';
    g.fillStyle = '#ff8c3b'; g.fillText(String(you), 150, 170);
    g.fillStyle = '#f3e2c3'; g.fillText('-', 256, 162);
    g.fillStyle = '#f3e2c3'; g.fillText(String(cpu), 362, 170);
    this.sb.tex.needsUpdate = true;
  }
  _buildCrowd() {
    const FZ = 10.8;
    const bodyGeo = new THREE.CapsuleGeometry(0.17, 0.3, 4, 8);
    const headGeo = new THREE.SphereGeometry(0.14, 8, 6);
    const clothes = [0x8a4a2a, 0x5a6a4a, 0x4a4a6a, 0x9a6a3a, 0x6a3a3a, 0x3a5a5a, 0xb08040, 0x5a4a6a];
    const skins = [0xc9a07a, 0x8a5a3a, 0xe0b090, 0x5a3a28];
    const spots = [];
    for (let row = 0; row < 3; row++) {
      const n = 34;
      for (let i = 0; i < n; i++) {
        if (Math.random() < 0.18) continue; // some empty seats
        spots.push({
          x: -12 + (24 / (n - 1)) * i + (Math.random() * 0.3 - 0.15),
          y: 0.62 + row * 0.55, z: FZ + 2.2 + row * 1.7 - 0.35,
          ph: Math.random() * Math.PI * 2, spd: 1.6 + Math.random() * 1.6,
          cloth: clothes[(Math.random() * clothes.length) | 0], skin: skins[(Math.random() * skins.length) | 0],
          head: Math.random() < 0.5
        });
      }
    }
    this.crowdBodies = new THREE.InstancedMesh(bodyGeo, new THREE.MeshStandardMaterial({ roughness: 0.95 }), spots.length);
    this.crowdHeads = new THREE.InstancedMesh(headGeo, new THREE.MeshStandardMaterial({ roughness: 0.9 }), spots.length);
    const M = new THREE.Matrix4(), Q = new THREE.Quaternion(), S = new THREE.Vector3(1, 1, 1), P = new THREE.Vector3();
    spots.forEach((sp, i) => {
      this.crowdBodies.setColorAt(i, new THREE.Color(sp.cloth));
      this.crowdHeads.setColorAt(i, new THREE.Color(sp.head ? sp.cloth : sp.skin));
    });
    this.crowdBodies.instanceColor.needsUpdate = true;
    this.crowdHeads.instanceColor.needsUpdate = true;
    this.scene.add(this.crowdBodies, this.crowdHeads);
    this.crowdData = { spots, M, Q, S, P };
  }
  update(dt, t) {
    this.time = t;
    for (const h of this.hoops) h.net.update(dt);
    // crowd bob
    const { spots, M, Q, S, P } = this.crowdData;
    const eu = new THREE.Euler();
    spots.forEach((sp, i) => {
      const bob = Math.sin(t * sp.spd + sp.ph) * 0.055;
      const hype = this.crowdHype || 0;
      eu.set(0, Math.sin(t * 0.8 + sp.ph) * (0.06 + hype * 0.2), 0);
      Q.setFromEuler(eu);
      P.set(sp.x, sp.y + bob + hype * Math.abs(Math.sin(t * 5 + sp.ph)) * 0.16, sp.z);
      M.compose(P, Q, S);
      this.crowdBodies.setMatrixAt(i, M);
      P.y += 0.34;
      M.compose(P, Q, S);
      this.crowdHeads.setMatrixAt(i, M);
    });
    this.crowdBodies.instanceMatrix.needsUpdate = true;
    this.crowdHeads.instanceMatrix.needsUpdate = true;
    // birds + clouds
    for (const b of this.birds) {
      b.a += b.spd * dt;
      b.s.position.set(Math.cos(b.a) * b.r, b.h + Math.sin(t + b.a) * 1.2, Math.sin(b.a) * b.r * 0.7 - 30);
    }
    for (const c of this.clouds) { c.s.position.x += c.spd * dt; if (c.s.position.x > 75) c.s.position.x = -75; }
    // string light twinkle
    if (this.bulbs) this.bulbs.material.color.setHSL(0.09, 0.8, 0.62 + Math.sin(t * 2.4) * 0.1);
    // spot flicker
    if (this.lights.spots) for (const sp of this.lights.spots) sp.intensity = 255 + Math.sin(t * 13) * 6;
  }
}
