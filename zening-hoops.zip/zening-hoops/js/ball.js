// ============ ZENING HOOPS — basketball physics, skins, rim/board/net collision ============
import * as THREE from 'three';
import { COURT as C, clamp } from './config.js';

function ballTexture(skinColor, glow) {
  const c = document.createElement('canvas'); c.width = 512; c.height = 256;
  const g = c.getContext('2d');
  g.fillStyle = skinColor; g.fillRect(0, 0, 512, 256);
  // subtle shading noise
  for (let i = 0; i < 500; i++) {
    g.fillStyle = 'rgba(0,0,0,0.05)';
    g.fillRect(Math.random() * 512, Math.random() * 256, 4, 4);
  }
  const line = glow && glow !== '#00000000' ? glow : '#3a1f0c';
  g.strokeStyle = line; g.lineWidth = 6; g.fillStyle = line;
  // equator
  g.beginPath(); g.moveTo(0, 128); g.lineTo(512, 128); g.stroke();
  // meridians
  for (const x of [128, 384]) { g.beginPath(); g.moveTo(x, 0); g.lineTo(x, 256); g.stroke(); }
  // curved seams
  g.beginPath(); g.arc(64, 128, 120, -Math.PI / 2, Math.PI / 2); g.stroke();
  g.beginPath(); g.arc(448, 128, 120, Math.PI / 2, -Math.PI / 2); g.stroke();
  if (skinColor === '#3a1f5a') { // galaxy stars
    for (let i = 0; i < 60; i++) {
      g.fillStyle = `rgba(255,255,255,${0.4 + Math.random() * 0.6})`;
      const s = Math.random() * 2.4;
      g.fillRect(Math.random() * 512, Math.random() * 256, s, s);
    }
  }
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

export class Ball {
  constructor(scene) {
    this.scene = scene;
    this.skinColor = '#d2691e';
    this.glow = '#00000000';
    this.mesh = new THREE.Mesh(new THREE.SphereGeometry(C.BALL_R, 20, 16),
      new THREE.MeshStandardMaterial({ map: ballTexture(this.skinColor, this.glow), roughness: 0.68, metalness: 0.06, emissive: new THREE.Color(this.glow === '#00000000' ? '#000000' : this.glow), emissiveIntensity: 0.0 }));
    this.mesh.castShadow = true;
    scene.add(this.mesh);
    this.vel = new THREE.Vector3();
    this.state = 'loose';
    this.owner = null;
    this.holdTarget = new THREE.Vector3(0, 1, 0);
    this.dribblePhase = 0;
    this.lastBounceY = 0;
    this.trailOn = false;
    this.trailColor = '#35e06a';
    this.trailAcc = 0;
    this.prevY = 0;
    this.scoreCooldown = 0;
    this.shooter = null;
    this.launchPos = new THREE.Vector3();
    this.rimHit = false;
    this.boardHit = false;
    this.forcedHoop = null;
    this.passTarget = null;
    this.spinAxis = new THREE.Vector3(1, 0, 0);
    this.spinRate = 0;
    this.prevPos = new THREE.Vector3();
    this.hooks = {};
  }
  setSkin(color, glow) {
    this.skinColor = color; this.glow = glow;
    this.mesh.material.map.dispose();
    this.mesh.material.map = ballTexture(color, glow);
    const hasGlow = glow && glow !== '#00000000';
    this.mesh.material.emissive.set(hasGlow ? glow : '#000000');
    this.mesh.material.emissiveIntensity = hasGlow ? 0.35 : 0;
  }
  setTrail(on, color) { this.trailOn = on; this.trailColor = color || '#35e06a'; }
  reset(pos) {
    this.mesh.position.copy(pos);
    this.vel.set(0, 0, 0);
    this.state = 'loose';
    this.owner = null;
    this.forcedHoop = null;
    this.scoreCooldown = 0.3;
  }
  launch(vel, shooter, hoop, forced = false) {
    this.vel.copy(vel);
    this.state = 'shot';
    this.owner = null;
    this.shooter = shooter;
    this.launchPos.copy(this.mesh.position);
    this.rimHit = false; this.boardHit = false;
    this.forcedHoop = forced ? hoop : null;
    this.scoreCooldown = 0.18;
  }
  pass(vel, target) {
    this.vel.copy(vel);
    this.state = 'pass';
    this.owner = null;
    this.passTarget = target;
    this.scoreCooldown = 0.25;
  }
  steal(vel) { this.state = 'loose'; this.owner = null; this.vel.copy(vel); this.scoreCooldown = 0.3; }
  hold(actor, targetPos) { this.state = 'held'; this.owner = actor; this.holdTarget.copy(targetPos); }

  update(dt, world, actors, vfx, sfx, t) {
    const p = this.mesh.position;
    this.scoreCooldown = Math.max(0, this.scoreCooldown - dt);

    if (this.state === 'held') {
      p.lerp(this.holdTarget, Math.min(1, dt * 26));
      return;
    }
    if (this.state === 'dribble') {
      const a = this.owner;
      if (!a) { this.state = 'loose'; return; }
      this.dribblePhase += dt * a.dribbleRate;
      const bounce = Math.abs(Math.sin(this.dribblePhase * Math.PI));
      const hand = a.stickman.handPos(a.dribbleHand);
      const tx = hand.x + a.dribbleSide.x * 0.34, tz = hand.z + a.dribbleSide.z * 0.34;
      p.x += (tx - p.x) * Math.min(1, dt * 14);
      p.z += (tz - p.z) * Math.min(1, dt * 14);
      p.y = C.BALL_R + bounce * Math.max(0.55, 0.8 - a.speed * 0.02);
      if (this.dribblePhase % 1 > 0.97) sfx.bounce(0.55);
      return;
    }

    // ----- free flight -----
    this.prevPos.copy(p);
    this.prevY = p.y;
    this.vel.y -= C.G * dt;
    this.vel.multiplyScalar(1 - 0.012 * dt);
    p.addScaledVector(this.vel, dt);

    // ground
    if (p.y < C.BALL_R) {
      p.y = C.BALL_R;
      if (this.vel.y < -0.4) {
        const power = clamp(-this.vel.y / 9, 0.15, 1);
        this.vel.y *= -0.62; this.vel.x *= 0.985; this.vel.z *= 0.985;
        if (this.vel.y < 0.6) this.vel.y = 0;
        sfx.bounce(power);
        if (this.hooks.onBounce) this.hooks.onBounce(power);
      } else {
        this.vel.y = 0;
        this.vel.x *= (1 - 1.4 * dt); this.vel.z *= (1 - 1.4 * dt);
        if (this.state !== 'shot' && this.vel.lengthSq() < 0.4) { this.state = 'loose'; }
      }
    }

    // hoops: rim, board, net, scoring
    for (const h of world.hoops) {
      const c = h.rimCenter;
      // backboard plane
      const bx = h.boardX;
      const within = Math.abs(p.z) < C.BOARD_W / 2 + 0.02 && p.y > C.BOARD_BOT - 0.05 && p.y < C.BOARD_BOT + C.BOARD_H + 0.05;
      const crossed = h.facing === 1 ? (p.x > bx - C.BALL_R) : (p.x < bx + C.BALL_R);
      if (within && crossed && Math.abs(p.x - bx) < 0.25 && Math.sign(this.vel.x) === h.facing) {
        p.x = bx - h.facing * (C.BALL_R + 0.01);
        this.vel.x *= -0.68; this.vel.y *= 0.9; this.vel.z *= 0.95;
        this.boardHit = true;
        sfx.board();
        if (this.hooks.onBoard) this.hooks.onBoard();
      }
      // rim torus
      const dx = p.x - c.x, dz = p.z - c.z;
      const rXZ = Math.hypot(dx, dz);
      if (Math.abs(p.y - c.y) < C.BALL_R + 0.08 && rXZ > 0.01) {
        const q = new THREE.Vector3(c.x + (dx / rXZ) * C.RIM_R, c.y, c.z + (dz / rXZ) * C.RIM_R);
        const d = p.distanceTo(q);
        if (d < C.BALL_R + 0.022) {
          const n = p.clone().sub(q).normalize();
          const vn = this.vel.dot(n);
          if (vn < 0) {
            this.vel.addScaledVector(n, -1.62 * vn);
            this.vel.multiplyScalar(0.72);
            this.vel.x += (Math.random() - 0.5) * 0.8;
            this.vel.z += (Math.random() - 0.5) * 0.8;
          }
          p.copy(q).addScaledVector(n, C.BALL_R + 0.025);
          this.rimHit = true;
          sfx.rim();
          if (this.hooks.onRim) this.hooks.onRim(h);
        }
      }
      // net drag
      h.net.collideBall(this);

      // forced score (dunks) — swept segment so a fast slam can't tunnel
      // through the cylinder between frames
      if (this.forcedHoop === h) {
        const seg = p.clone().sub(this.prevPos);
        const denom = Math.max(0.0001, seg.lengthSq());
        const tt = clamp(c.clone().sub(this.prevPos).dot(seg) / denom, 0, 1);
        const closest = this.prevPos.clone().addScaledVector(seg, tt);
        if (closest.distanceTo(c) < 0.5) {
          this.forcedHoop = null;
          this._doScore2(h);
          break;
        }
      }
      // clean score detection
      if (this.scoreCooldown <= 0 && this.prevY > c.y + 0.01 && p.y <= c.y && rXZ < C.RIM_R - 0.045 && this.vel.y < -0.5) {
        this._doScore2(h);
        break;
      }
    }

    // spin visual
    this.mesh.rotateOnWorldAxis(this.spinAxis, this.spinRate * dt);
    this.spinRate *= (1 - 0.4 * dt);

    // trail
    if (this.trailOn && (this.state === 'shot' || this.state === 'pass' || this.state === 'dunk' || this.vel.length() > 6)) {
      this.trailAcc += dt;
      if (this.trailAcc > 0.022) {
        this.trailAcc = 0;
        let col = this.trailColor;
        if (this.trailColor === '#ff5ad2') { // rainbow cycle
          col = `hsl(${(t * 240) % 360}, 90%, 60%)`;
        }
        vfx.trail(p.clone(), col, 0.26, 0.42);
      }
    }

    // pass arrival
    if (this.state === 'pass' && this.passTarget) {
      if (p.distanceTo(this.passTarget.stickman.root.position) < 0.55 || (this.vel.length() < 2 && p.y < 1.2)) {
        this.state = 'loose';
        this.passTarget = null;
      }
    }
    if (this.state === 'shot' && this.vel.length() < 1.5 && p.y < C.BALL_R + 0.05) this.state = 'loose';
  }
  _doScore2(h) {
    // funnel through net center for clean visuals
    const c = h.rimCenter;
    this.mesh.position.x = this.mesh.position.x * 0.5 + c.x * 0.5;
    this.mesh.position.z = this.mesh.position.z * 0.5 + c.z * 0.5;
    this.vel.y = Math.min(this.vel.y, -3.2);
    this.vel.x *= 0.35; this.vel.z *= 0.35;
    const swish = !this.rimHit && !this.boardHit;
    if (this.hooks.onScore) this.hooks.onScore(h, this.shooter, swish);
    this.scoreCooldown = 0.8;
    this.state = 'shot';
  }
  pointValue(hoop) {
    const lp = this.launchPos;
    if (!lp) return 2;
    const d = Math.hypot(lp.x - hoop.rimCenter.x, lp.z - hoop.rimCenter.z);
    return d > C.THREE_D + 0.05 ? 3 : 2;
  }
}
