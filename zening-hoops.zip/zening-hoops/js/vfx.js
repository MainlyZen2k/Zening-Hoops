// ============ ZENING HOOPS — VFX: particles, trails, rings, popups, shake ============
import * as THREE from 'three';

const MAX_P = 1400;
const MAX_TRAIL = 260;

class VFX {
  constructor() { this.scene = null; this.parts = []; this.trailSprites = []; this.rings = []; this.shakeMag = 0; }
  init(scene) {
    this.scene = scene;
    // ---- particle system (per-particle size + alpha via custom shader) ----
    const geo = new THREE.BufferGeometry();
    this.pPos = new Float32Array(MAX_P * 3);
    this.pCol = new Float32Array(MAX_P * 3);
    this.pSize = new Float32Array(MAX_P);
    this.pAlpha = new Float32Array(MAX_P);
    geo.setAttribute('position', new THREE.BufferAttribute(this.pPos, 3));
    geo.setAttribute('aColor', new THREE.BufferAttribute(this.pCol, 3));
    geo.setAttribute('aSize', new THREE.BufferAttribute(this.pSize, 1));
    geo.setAttribute('aAlpha', new THREE.BufferAttribute(this.pAlpha, 1));
    const mat = new THREE.ShaderMaterial({
      transparent: true, depthWrite: false, blending: THREE.AdditiveBlending,
      vertexShader: `
        attribute vec3 aColor; attribute float aSize; attribute float aAlpha;
        varying vec3 vColor; varying float vAlpha;
        void main(){ vColor=aColor; vAlpha=aAlpha;
          vec4 mv = modelViewMatrix * vec4(position,1.0);
          gl_PointSize = aSize * (220.0 / max(1.0,-mv.z));
          gl_Position = projectionMatrix * mv; }`,
      fragmentShader: `
        varying vec3 vColor; varying float vAlpha;
        void main(){ vec2 uv = gl_PointCoord - 0.5;
          float d = length(uv); float a = smoothstep(0.5, 0.08, d) * vAlpha;
          gl_FragColor = vec4(vColor, a); }`
    });
    this.points = new THREE.Points(geo, mat);
    this.points.frustumCulled = false;
    scene.add(this.points);

    // ---- trail sprite pool ----
    const tex = this._softTex();
    for (let i = 0; i < MAX_TRAIL; i++) {
      const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false }));
      s.visible = false; scene.add(s); this.trailSprites.push({ s, life: 0, max: 1, size: 1 });
    }
    // ---- ring pool ----
    const ringGeo = new THREE.RingGeometry(0.42, 0.5, 40);
    for (let i = 0; i < 6; i++) {
      const m = new THREE.Mesh(ringGeo, new THREE.MeshBasicMaterial({ color: 0x35e06a, transparent: true, blending: THREE.AdditiveBlending, side: THREE.DoubleSide, depthWrite: false }));
      m.rotation.x = -Math.PI / 2; m.visible = false; scene.add(m);
      this.rings.push({ m, life: 0, max: 1 });
    }
  }
  _softTex() {
    const c = document.createElement('canvas'); c.width = c.height = 64;
    const g = c.getContext('2d');
    const grad = g.createRadialGradient(32, 32, 2, 32, 32, 30);
    grad.addColorStop(0, 'rgba(255,255,255,1)'); grad.addColorStop(0.4, 'rgba(255,255,255,.55)'); grad.addColorStop(1, 'rgba(255,255,255,0)');
    g.fillStyle = grad; g.fillRect(0, 0, 64, 64);
    return new THREE.CanvasTexture(c);
  }
  // ---------- particles ----------
  burst(pos, color, n = 20, o = {}) {
    const speed = o.speed || 3, up = o.up ?? 2.5, size = o.size || 0.16, life = o.life || 0.6, grav = o.gravity ?? -6;
    const col = new THREE.Color(color);
    for (let i = 0; i < n; i++) {
      if (this.parts.length >= MAX_P) this.parts.shift();
      const a = Math.random() * Math.PI * 2, r = Math.random();
      const v = new THREE.Vector3(Math.cos(a) * r * speed, (0.4 + Math.random() * 0.9) * up, Math.sin(a) * r * speed);
      this.parts.push({ p: pos.clone(), v, life, max: life, col, size: size * (0.6 + Math.random() * 0.8), grav, drag: o.drag ?? 1.5 });
    }
  }
  // ---------- trail ----------
  trail(pos, color, size = 0.22, life = 0.5) {
    for (const t of this.trailSprites) {
      if (t.life <= 0) {
        t.life = life; t.max = life; t.size = size;
        t.s.position.copy(pos); t.s.material.color.set(color);
        t.s.material.opacity = 0.9; t.s.scale.setScalar(size); t.s.visible = true;
        return;
      }
    }
  }
  ring(pos, color = 0x35e06a, big = false) {
    for (const r of this.rings) {
      if (r.life <= 0) {
        r.life = r.max = big ? 0.8 : 0.55; r.big = big;
        r.m.position.copy(pos); r.m.material.color.set(color); r.m.material.opacity = 0.9;
        r.m.scale.setScalar(big ? 1.6 : 1); r.m.visible = true; return;
      }
    }
  }
  popup(text, color = '#35e06a', sub = '', yOff = 0, size = 34) {
    const layer = document.getElementById('popups');
    const el = document.createElement('div');
    el.className = 'popup'; el.textContent = text;
    el.style.cssText = `left:${50 + (Math.random() * 10 - 5)}%;top:${34 + yOff}%;color:${color};font-size:${size}px`;
    if (sub) { el.innerHTML = `${text}<div style="font-size:${size * 0.42}px;letter-spacing:.3em;color:#f3e2c3;text-align:center">${sub}</div>`; }
    layer.appendChild(el);
    setTimeout(() => el.remove(), 1200);
  }
  shake(mag) { this.shakeMag = Math.min(1.2, this.shakeMag + mag); }
  flash(color = 'rgba(53,224,106,.28)') {
    const f = document.getElementById('flash');
    f.style.background = color; f.style.opacity = '1';
    setTimeout(() => { f.style.opacity = '0'; }, 70);
  }
  update(dt) {
    // particles
    let n = 0;
    for (let i = this.parts.length - 1; i >= 0; i--) {
      const p = this.parts[i];
      p.life -= dt;
      if (p.life <= 0) { this.parts.splice(i, 1); continue; }
      p.v.y += p.grav * dt;
      p.v.multiplyScalar(Math.max(0, 1 - p.drag * dt));
      p.p.addScaledVector(p.v, dt);
    }
    for (const p of this.parts) {
      this.pPos[n * 3] = p.p.x; this.pPos[n * 3 + 1] = p.p.y; this.pPos[n * 3 + 2] = p.p.z;
      this.pCol[n * 3] = p.col.r; this.pCol[n * 3 + 1] = p.col.g; this.pCol[n * 3 + 2] = p.col.b;
      this.pSize[n] = p.size; this.pAlpha[n] = Math.min(1, p.life / p.max * 1.6);
      n++;
    }
    this.points.geometry.setDrawRange(0, n);
    this.points.geometry.attributes.position.needsUpdate = true;
    this.points.geometry.attributes.aColor.needsUpdate = true;
    this.points.geometry.attributes.aSize.needsUpdate = true;
    this.points.geometry.attributes.aAlpha.needsUpdate = true;
    // trails
    for (const t of this.trailSprites) {
      if (t.life <= 0) { t.s.visible = false; continue; }
      t.life -= dt;
      const k = Math.max(0, t.life / t.max);
      t.s.material.opacity = k * 0.85;
      t.s.scale.setScalar(t.size * (0.5 + k * 0.9));
    }
    // rings
    for (const r of this.rings) {
      if (r.life <= 0) { r.m.visible = false; continue; }
      r.life -= dt;
      const k = 1 - r.life / r.max;
      r.m.scale.setScalar((r.big ? 1.6 : 1) + k * (r.big ? 7 : 3.4));
      r.m.material.opacity = (1 - k) * 0.9;
    }
    if (this.shakeMag > 0) this.shakeMag = Math.max(0, this.shakeMag - dt * 2.4);
  }
}
export const VFXer = new VFX();
