// ============ ZENING HOOPS — 3D stickman v2 + procedural animation ============
// Look modeled on the reference stickman base mesh: one clean body color,
// big round head with a drawn face, chunky rounded capsule limbs.
import * as THREE from 'three';
import { lerp, clamp } from './config.js';

function limb(r, len, mat) {
  const geo = new THREE.CapsuleGeometry(r, Math.max(0.01, len - r * 2), 4, 10);
  const m = new THREE.Mesh(geo, mat);
  m.geometry.translate(0, -len / 2, 0); // pivot at top
  m.castShadow = true;
  return m;
}

function faceTexture(bodyColor) {
  const c = document.createElement('canvas'); c.width = 512; c.height = 256;
  const g = c.getContext('2d');
  const col = new THREE.Color(bodyColor);
  const css = '#' + col.getHexString();
  // base skin = body color, slightly lighter face
  const lighter = col.clone().lerp(new THREE.Color('#ffffff'), 0.16);
  g.fillStyle = '#' + lighter.getHexString();
  g.fillRect(0, 0, 512, 256);
  // face sits around u=0.25 (+z front), v=0.45
  const fx = 128;
  const ink = '#231508';
  // eyes — big friendly ovals
  g.fillStyle = ink;
  const eyeY = 112, eyeDX = 46, eyeRX = 11.5, eyeRY = 17;
  for (const s of [-1, 1]) {
    g.save();
    g.translate(fx + s * eyeDX, eyeY);
    g.scale(eyeRX / 12, eyeRY / 12);
    g.beginPath(); g.arc(0, 0, 12, 0, Math.PI * 2); g.fill();
    g.restore();
  }
  // eye glints
  g.fillStyle = 'rgba(255,255,255,.9)';
  for (const s of [-1, 1]) g.fillRect(fx + s * eyeDX - 4, eyeY - 11, 7, 8);
  // mouth — easy open smile
  g.strokeStyle = ink; g.lineWidth = 9; g.lineCap = 'round';
  g.beginPath();
  g.arc(fx, 128, 34, 0.42, Math.PI - 0.42);
  g.stroke();
  // subtle cheek blush
  g.fillStyle = 'rgba(210,90,60,.22)';
  for (const s of [-1, 1]) {
    g.beginPath();
    g.ellipse(fx + s * (eyeDX + 30), 138, 15, 9, 0, 0, Math.PI * 2);
    g.fill();
  }
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

export class Stickman {
  constructor(opts = {}) {
    this.jersey = opts.jersey || '#e05038';
    this.band = opts.band || '#f3e2c3';
    this.number = opts.number ?? 7;
    this.auraColor = opts.auraColor || null;
    this.state = 'idle';
    this.actionT = 0;
    this.actionDur = 1;
    this.runPhase = 0;
    this.faceYaw = 0;
    this.breath = Math.random() * Math.PI * 2;
    this._build();
  }

  _build() {
    const jer = new THREE.Color(this.jersey);
    const bandC = new THREE.Color(this.band);
    this.matBody = new THREE.MeshStandardMaterial({ color: jer, roughness: 0.6, metalness: 0.05 });
    this.matHead = new THREE.MeshStandardMaterial({ color: 0xffffff, map: faceTexture(jer), roughness: 0.55, metalness: 0.02 });
    this.matBand = new THREE.MeshStandardMaterial({ color: bandC, roughness: 0.7 });
    this.matShoe = new THREE.MeshStandardMaterial({ color: 0x201409, roughness: 0.85 });
    this.matInk = new THREE.MeshStandardMaterial({ color: 0x201409, roughness: 0.8 });

    this.root = new THREE.Group();
    // pelvis
    this.pelvis = new THREE.Group();
    this.pelvis.position.y = 1.02;
    this.root.add(this.pelvis);
    const hipMesh = limb(0.118, 0.34, this.matBody);
    hipMesh.rotation.z = Math.PI / 2; // horizontal hips
    hipMesh.position.y = -0.03;
    this.pelvis.add(hipMesh);
    // torso (pivot at pelvis top)
    this.torso = new THREE.Group();
    this.torso.position.y = 0.05;
    this.pelvis.add(this.torso);
    const spine = limb(0.15, 0.56, this.matBody);
    spine.rotation.x = Math.PI; // grows upward
    this.torso.add(spine);
    this.torsoMesh = spine;
    // chest badge (jersey number)
    const nc = document.createElement('canvas'); nc.width = nc.height = 64;
    this._numCanvas = nc;
    const ntex = new THREE.CanvasTexture(nc);
    this.numSprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: ntex, transparent: true, depthWrite: false, opacity: 0.9 }));
    this.numSprite.scale.setScalar(0.22);
    this.numSprite.position.set(0, 0.26, 0.16);
    this.torso.add(this.numSprite);
    this._drawNumber();
    // head — big round reference-style head with a face
    this.head = new THREE.Group();
    this.head.position.y = 0.6;
    this.torso.add(this.head);
    const skull = new THREE.Mesh(new THREE.SphereGeometry(0.185, 24, 18), this.matHead);
    skull.position.y = 0.16; skull.castShadow = true;
    this.head.add(skull);
    // headband (optional accent, sits on the forehead)
    this.bandMesh = new THREE.Mesh(new THREE.TorusGeometry(0.152, 0.021, 8, 24), this.matBand);
    this.bandMesh.rotation.x = Math.PI / 2 + 0.1;
    this.bandMesh.position.y = 0.225;
    this.head.add(this.bandMesh);
    // arms
    this.armL = this._makeArm(-1); this.armR = this._makeArm(1);
    // legs
    this.legL = this._makeLeg(-1); this.legR = this._makeLeg(1);
    // aura
    this.aura = null;
    this.setAura(this.auraColor);
  }

  _makeArm(side) {
    const shoulder = new THREE.Group();
    shoulder.position.set(side * 0.21, 0.48, 0);
    this.torso.add(shoulder);
    const upper = limb(0.062, 0.34, this.matBody);
    shoulder.add(upper);
    const elbow = new THREE.Group();
    elbow.position.y = -0.34;
    shoulder.add(elbow);
    const fore = limb(0.055, 0.3, this.matBody);
    elbow.add(fore);
    const hand = new THREE.Mesh(new THREE.SphereGeometry(0.062, 10, 8), this.matBody);
    hand.position.y = -0.31;
    hand.castShadow = true;
    elbow.add(hand);
    return { shoulder, elbow, hand };
  }
  _makeLeg(side) {
    const hip = new THREE.Group();
    hip.position.set(side * 0.115, -0.09, 0);
    this.pelvis.add(hip);
    const thigh = limb(0.088, 0.44, this.matBody);
    hip.add(thigh);
    const knee = new THREE.Group();
    knee.position.y = -0.44;
    hip.add(knee);
    const shin = limb(0.072, 0.4, this.matBody);
    knee.add(shin);
    const ankle = new THREE.Group();
    ankle.position.y = -0.4;
    knee.add(ankle);
    // rounded sneaker
    const shoe = new THREE.Mesh(new THREE.CapsuleGeometry(0.055, 0.1, 4, 8), this.matShoe);
    shoe.rotation.x = Math.PI / 2;
    shoe.position.set(0, -0.04, 0.055);
    shoe.castShadow = true;
    ankle.add(shoe);
    return { hip, knee, ankle };
  }

  _drawNumber() {
    const g = this._numCanvas.getContext('2d');
    g.clearRect(0, 0, 64, 64);
    g.fillStyle = 'rgba(243,226,195,0.95)';
    g.font = '900 44px Arial Black, Arial';
    g.textAlign = 'center'; g.textBaseline = 'middle';
    g.fillText(String(this.number), 32, 34);
    this.numSprite.material.map.needsUpdate = true;
  }

  setColors(jersey, band) {
    this.jersey = jersey; this.band = band;
    this.matBody.color.set(jersey);
    if (this.matHead.map) this.matHead.map.dispose();
    this.matHead.map = faceTexture(jersey);
    this.matBand.color.set(band);
  }
  setNumber(n) { this.number = n; this._drawNumber(); }
  setAura(color) {
    this.auraColor = color;
    if (this.aura) { this.root.remove(this.aura); this.aura = null; }
    if (!color) return;
    const c = document.createElement('canvas'); c.width = c.height = 128;
    const g = c.getContext('2d');
    const grad = g.createRadialGradient(64, 64, 8, 64, 64, 62);
    grad.addColorStop(0, 'rgba(255,255,255,.9)'); grad.addColorStop(0.4, color + 'AA'); grad.addColorStop(1, color + '00');
    g.fillStyle = grad; g.beginPath(); g.arc(64, 64, 62, 0, Math.PI * 2); g.fill();
    const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: new THREE.CanvasTexture(c), transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, opacity: 0.5 }));
    s.scale.set(1.15, 0.5, 1); s.position.y = 0.16;
    this.root.add(s);
    this.aura = s;
  }

  setState(state, dur = 1) {
    this.state = state;
    this.actionT = 0;
    this.actionDur = Math.max(0.01, dur);
  }

  handPos(side) {
    const arm = side < 0 ? this.armL : this.armR;
    const v = new THREE.Vector3();
    arm.hand.getWorldPosition(v);
    return v;
  }

  // ctx = { speed, sprint, hasBall, dribblePhase, dribbleHand, faceYaw, dt }
  update(dt, ctx = {}) {
    const s = this.state;
    this.actionT = Math.min(1, this.actionT + dt / this.actionDur);
    const t = this.actionT;
    const spd = ctx.speed || 0;
    this.runPhase += dt * (2.4 + spd * 2.6);
    this.breath += dt * 1.7;
    // facing
    if (ctx.faceYaw !== undefined) {
      let d = ctx.faceYaw - this.root.rotation.y;
      while (d > Math.PI) d -= Math.PI * 2;
      while (d < -Math.PI) d += Math.PI * 2;
      this.root.rotation.y += d * Math.min(1, dt * 10);
    }

    // ---- default targets ----
    let P = { px: 0, py: 0, pitch: 0, roll: 0, yaw: 0 };          // pelvis
    let T = { pitch: 0.06, yaw: 0, roll: 0 };                     // torso
    let Hd = { pitch: 0, yaw: 0 };
    let aL = { sp: 0, sr: 0.14, el: -0.3 };                        // shoulder pitch/roll, elbow bend
    let aR = { sp: 0, sr: -0.14, el: -0.3 };
    let lL = { hp: 0, hr: 0.07, kn: -0.1 };
    let lR = { hp: 0, hr: -0.07, kn: -0.1 };

    const runAmp = clamp(spd / 6.2, 0, 1);
    const ph = this.runPhase;

    switch (s) {
      case 'idle': {
        P.py = Math.sin(this.breath) * 0.014;
        T.pitch = 0.05 + Math.sin(this.breath * 0.8) * 0.02;
        aL.sr = 0.16; aR.sr = -0.16;
        aL.sp = Math.sin(this.breath * 0.8) * 0.05; aR.sp = -Math.sin(this.breath * 0.8) * 0.05;
        aL.el = -0.35; aR.el = -0.35;
        break;
      }
      case 'run': case 'defense': {
        const def = s === 'defense';
        const amp = def ? 0.42 : 0.72 * runAmp + 0.06;
        const baseCrouch = def ? 0.24 : clamp(spd * 0.03, 0.04, 0.22);
        P.py = -baseCrouch + Math.abs(Math.sin(ph)) * (def ? 0.015 : 0.06) * (0.4 + runAmp);
        P.pitch = baseCrouch * 0.9;
        const swing = Math.sin(ph) * amp;
        lL.hp = swing + (def ? 0.4 : 0.08); lR.hp = -swing + (def ? -0.4 : 0.08);
        lL.hr = def ? 0.3 : 0.07; lR.hr = def ? -0.3 : -0.07;
        lL.kn = -Math.max(0.18, (1 - Math.sin(ph)) * 0.95) * (0.5 + runAmp * 0.8);
        lR.kn = -Math.max(0.18, (1 + Math.sin(ph)) * 0.95) * (0.5 + runAmp * 0.8);
        if (def) {
          // low athletic guard: wide base, both palms out, hands stay live
          aL.sp = -0.5 + Math.sin(ph * 2) * 0.06; aR.sp = -0.5 - Math.sin(ph * 2) * 0.06;
          aL.sr = 0.75; aR.sr = -0.75; aL.el = -0.8; aR.el = -0.8;
          T.yaw = Math.sin(ph) * 0.07;
          T.roll = 0.06;
        } else {
          // full sprint: big counter-swinging arms, forward lean into speed
          aL.sp = -swing * 1.05; aR.sp = swing * 1.05;
          aL.sr = 0.18; aR.sr = -0.18;
          aL.el = -0.85 - runAmp * 0.35; aR.el = -0.85 - runAmp * 0.35;
          T.yaw = Math.sin(ph) * 0.1 * runAmp;
          T.pitch = baseCrouch * 1.1 + runAmp * 0.15;
        }
        break;
      }
      case 'dribble': {
        const dp = ctx.dribblePhase || 0;
        P.py = -0.16 - Math.abs(Math.sin(dp * Math.PI)) * 0.03;
        P.pitch = 0.24; T.pitch = 0.2; T.yaw = ctx.dribbleHand < 0 ? -0.2 : 0.2;
        const pump = Math.sin(dp * Math.PI * 2);
        const arm = ctx.dribbleHand < 0 ? aL : aR;
        arm.sp = -0.55 + pump * 0.34; arm.el = -0.45 - pump * 0.4;
        const other = ctx.dribbleHand < 0 ? aR : aL;
        other.sp = -0.3 - pump * 0.07; other.sr = (ctx.dribbleHand < 0 ? -1 : 1) * 0.48; other.el = -1.15;
        lL.hp = 0.2; lR.hp = -0.2; lL.hr = 0.26; lR.hr = -0.26;
        lL.kn = -0.42; lR.kn = -0.42;
        // add run cycle on top if moving
        if (spd > 1.5) {
          const sw = Math.sin(ph) * 0.45 * clamp(spd / 5, 0, 1);
          lL.hp += sw; lR.hp -= sw;
          lL.kn -= Math.max(0, sw) * 1.1; lR.kn -= Math.max(0, -sw) * 1.1;
        }
        break;
      }
      case 'pass': {
        // chest pass: snap both arms out and hold the follow-through
        const push = clamp(t / 0.4, 0, 1);
        const out2 = Math.sin(clamp(t, 0, 1) * Math.PI * 0.5);
        aL.sp = -1.5 * out2; aR.sp = -1.5 * out2;
        aL.sr = 0.1; aR.sr = -0.1;
        aL.el = lerp(-1.3, -0.06, out2); aR.el = aL.el;
        P.pitch = 0.14 * (1 - out2);
        lL.hp = 0.16; lR.hp = -0.16; lL.kn = -0.3; lR.kn = -0.3;
        break;
      }
      case 'jumpshot': {
        // t: 0 gather -> 0.4 rise -> 0.62 release -> 1 follow
        const gather = clamp(t / 0.38, 0, 1);
        const rise = clamp((t - 0.38) / 0.24, 0, 1);
        const follow = clamp((t - 0.62) / 0.38, 0, 1);
        P.py = -0.22 * gather;
        lL.kn = -0.9 * gather * (1 - rise) - 0.16 * (1 - gather);
        lR.kn = lL.kn;
        lL.hp = 0.32 * gather * (1 - rise) + 0.05; lR.hp = lL.hp;
        lL.hr = 0.12; lR.hr = -0.12;
        const raise = clamp((t - 0.25) / 0.37, 0, 1);
        const sp = lerp(-0.5, -2.95, raise);
        aR.sp = sp; aR.sr = lerp(-0.14, -0.2, raise);
        // guide hand rides the ball, then drops away in the follow-through
        aL.sp = sp - follow * 1.15;
        aL.sr = lerp(0.14, 0.28, raise) + follow * 0.14;
        aL.el = lerp(-0.5, -0.28, raise) - follow * 0.6;
        // shooting elbow extends into the wrist flick
        aR.el = -0.48 + follow * 0.4;
        T.pitch = lerp(0.14, -0.07, raise) - follow * 0.05;
        T.yaw = (1 - raise) * 0.24;
        P.yaw = (1 - raise) * 0.3;
        if (follow > 0) { aR.sp = -2.95 - follow * 0.32; }
        Hd.pitch = -0.18 * raise; // eyes on the rim
        break;
      }
      case 'layup': {
        const rise = clamp(t / 0.45, 0, 1);
        lL.kn = -0.95 * (1 - rise) - 0.42; lR.kn = -0.95 * (1 - rise) - 0.8;
        lL.hp = 0.42 * (1 - rise) + 0.1; lR.hp = 0.58 * (1 - rise) - 0.16;
        aR.sp = lerp(0, -3.1, rise); aR.el = -0.28;
        aL.sp = lerp(0, -0.75, rise); aL.el = -0.95;
        T.pitch = 0.12 * (1 - rise);
        break;
      }
      case 'dunk': {
        const wind = clamp(t / 0.35, 0, 1);
        const slam = clamp((t - 0.35) / 0.3, 0, 1);
        aR.sp = lerp(0.5, -3.15, wind) - slam * 0.3;
        aL.sp = lerp(0.4, -2.65, wind) - slam * 0.15;
        aR.el = -0.75 * (1 - wind) - 0.08 + slam * 0.15; aL.el = -0.65 * (1 - wind) - 0.16 + slam * 0.1;
        T.pitch = 0.25 * (1 - wind) - 0.15 * slam;
        P.pitch = 0.1 * (1 - wind) - 0.06 * slam;
        // knees tuck and legs kick back into the slam
        lL.kn = -0.75 * (1 - wind) - slam * 1.2; lR.kn = -1.05 * (1 - wind) - 0.3 - slam * 0.9;
        lL.hp = 0.38 + slam * 0.32; lR.hp = -0.38 + slam * 0.78;
        break;
      }
      case 'cross': {
        const k = Math.sin(t * Math.PI);
        P.yaw = (ctx.crossDir || 1) * k * 0.7;
        T.yaw = (ctx.crossDir || 1) * k * 0.5;
        P.roll = (ctx.crossDir || 1) * k * -0.1;
        P.py = -0.22 + k * 0.04;
        P.pitch = 0.26;
        aL.sp = -0.42 + k * 0.55; aR.sp = -0.42 - k * 0.55;
        aL.el = -1.15; aR.el = -1.15;
        lL.hp = 0.32 + k * 0.28; lR.hp = -0.32 - k * 0.1;
        lL.kn = -0.55; lR.kn = -0.46;
        lL.hr = 0.28; lR.hr = -0.28;
        break;
      }
      case 'stepback': {
        const k = Math.sin(clamp(t, 0, 1) * Math.PI);
        P.py = -0.26; P.pitch = -0.18 * k + 0.08;
        T.pitch = -0.1 * k;
        lL.hp = 0.52 * k + 0.1; lR.hp = -0.2;
        lL.kn = -0.32 - k * 0.44; lR.kn = -0.58;
        aL.sp = -0.32; aR.sp = -0.32; aL.el = -0.95; aR.el = -0.95;
        break;
      }
      case 'steal': {
        const k = Math.sin(clamp(t, 0, 1) * Math.PI);
        P.pitch = 0.34; P.py = -0.26;
        aR.sp = -0.95 - k * 0.75; aR.el = -0.3;
        aL.sp = -0.3; aL.sr = 0.55;
        T.yaw = k * 0.5;
        lL.hp = 0.32; lR.hp = -0.38; lL.kn = -0.55; lR.kn = -0.48;
        break;
      }
      case 'block': {
        const rise = clamp(t / 0.5, 0, 1);
        aL.sp = lerp(-0.4, -3.05, rise); aR.sp = lerp(-0.4, -3.05, rise);
        aL.el = -0.12; aR.el = -0.12;
        aL.sr = 0.2; aR.sr = -0.2;
        lL.kn = -0.85 * (1 - rise) - 0.1; lR.kn = -0.85 * (1 - rise) - 0.1;
        T.pitch = -0.08 * rise;
        break;
      }
      case 'fake': {
        const k = Math.sin(clamp(t, 0, 1) * Math.PI * 2) * 0.5;
        aL.sp = -1.45 - k; aR.sp = -1.45 - k;
        aL.el = -1.2; aR.el = -1.2;
        P.py = -0.28; P.pitch = 0.12;
        lL.kn = -0.65; lR.kn = -0.65;
        break;
      }
      case 'stumble': {
        const k = Math.sin(t * Math.PI * 3);
        const wob = (1 - t);
        P.py = -0.32 - wob * 0.15;
        P.pitch = 0.38 * wob + k * 0.14 * wob;
        P.roll = k * 0.3 * wob;
        T.pitch = 0.3 * wob;
        aL.sp = -0.6 + k * 0.85 * wob; aR.sp = -0.6 - k * 0.85 * wob;
        aL.sr = 0.65 + k * 0.4; aR.sr = -0.65 - k * 0.4;
        lL.hp = 0.42 + k * 0.3; lR.hp = -0.1 - k * 0.3;
        lL.kn = -0.75; lR.kn = -0.3;
        break;
      }
      case 'cheer': {
        const k = Math.abs(Math.sin(t * Math.PI * 2));
        aL.sp = -2.95; aR.sp = -2.95; aL.sr = 0.4; aR.sr = -0.4;
        aL.el = -0.15; aR.el = -0.15;
        P.py = -0.05 + k * 0.16;
        lL.kn = -0.32 * k; lR.kn = -0.32 * k;
        break;
      }
      case 'sulk': {
        P.py = -0.28; T.pitch = 0.42;
        aL.sp = -0.1; aR.sp = -0.1; aL.el = -1.45; aR.el = -1.45;
        Hd.pitch = 0.42;
        break;
      }
    }

    // eyes track the rock / the rim
    if (ctx.headYaw) Hd.yaw = clamp(Hd.yaw + ctx.headYaw * 0.65, -0.85, 0.85);

    // ----- apply with smoothing -----
    const k = Math.min(1, dt * 14);
    const ap = (obj, grp, map) => {
      for (const key in obj) {
        const cur = grp.rotation[map[key]];
        grp.rotation[map[key]] = lerp(cur, obj[key], k);
      }
    };
    this.pelvis.position.x = lerp(this.pelvis.position.x, P.px, k);
    this.pelvis.position.y = lerp(this.pelvis.position.y, 1.02 + P.py, k);
    ap(P, this.pelvis, { pitch: 'x', yaw: 'y', roll: 'z' });
    ap(T, this.torso, { pitch: 'x', yaw: 'y', roll: 'z' });
    ap(Hd, this.head, { pitch: 'x', yaw: 'y' });
    ap(aL, this.armL.shoulder, { sp: 'x', sr: 'z' });
    ap(aR, this.armR.shoulder, { sp: 'x', sr: 'z' });
    this.armL.elbow.rotation.x = lerp(this.armL.elbow.rotation.x, aL.el, k);
    this.armR.elbow.rotation.x = lerp(this.armR.elbow.rotation.x, aR.el, k);
    ap(lL, this.legL.hip, { hp: 'x', hr: 'z' });
    ap(lR, this.legR.hip, { hp: 'x', hr: 'z' });
    this.legL.knee.rotation.x = lerp(this.legL.knee.rotation.x, lL.kn, k);
    this.legR.knee.rotation.x = lerp(this.legR.knee.rotation.x, lR.kn, k);
    // aura pulse
    if (this.aura) this.aura.material.opacity = 0.38 + Math.sin(this.breath * 2) * 0.12;
  }
}
