// ============ ZENING HOOPS — 3D stickman + procedural animation ============
import * as THREE from 'three';
import { lerp, clamp } from './config.js';

function limb(r, len, mat) {
  const geo = new THREE.CapsuleGeometry(r, len - r * 2, 4, 8);
  const m = new THREE.Mesh(geo, mat);
  m.geometry.translate(0, -len / 2, 0); // pivot at top
  m.castShadow = true;
  return m;
}

export class Stickman {
  constructor(opts = {}) {
    this.jersey = opts.jersey || '#e05038';
    this.band = opts.band || '#f3e2c3';
    this.number = opts.number ?? 7;
    this.auraColor = opts.auraColor || null;
    this.state = 'idle';
    this.actionT = 0;
    this.actionDur = 1;
    this.runPhase = 0;
    this.faceYaw = 0;
    this.breath = Math.random() * Math.PI * 2;
    this._build();
  }

  _build() {
    const jer = new THREE.Color(this.jersey);
    const darker = jer.clone().multiplyScalar(0.72);
    const bandC = new THREE.Color(this.band);
    this.matBody = new THREE.MeshStandardMaterial({ color: jer, roughness: 0.62, metalness: 0.08 });
    this.matHead = new THREE.MeshStandardMaterial({ color: darker, roughness: 0.55, metalness: 0.08 });
    this.matBand = new THREE.MeshStandardMaterial({ color: bandC, roughness: 0.7 });
    this.matShoe = new THREE.MeshStandardMaterial({ color: 0x1a120b, roughness: 0.8 });

    this.root = new THREE.Group();
    // pelvis
    this.pelvis = new THREE.Group();
    this.pelvis.position.y = 1.0;
    this.root.add(this.pelvis);
    const hipMesh = limb(0.105, 0.24, this.matBody);
    hipMesh.rotation.z = Math.PI / 2; // horizontal hips
    hipMesh.position.y = -0.02;
    this.pelvis.add(hipMesh);
    // torso (pivot at pelvis top)
    this.torso = new THREE.Group();
    this.torso.position.y = 0.06;
    this.pelvis.add(this.torso);
    const spine = limb(0.11, 0.52, this.matBody);
    spine.rotation.x = Math.PI; // grows upward
    spine.position.y = 0.0;
    this.torso.add(spine);
    this.torsoMesh = spine;
    // head
    this.head = new THREE.Group();
    this.head.position.y = 0.62;
    this.torso.add(this.head);
    const skull = new THREE.Mesh(new THREE.SphereGeometry(0.135, 12, 10), this.matHead);
    skull.position.y = 0.12; skull.castShadow = true;
    this.head.add(skull);
    this.bandMesh = new THREE.Mesh(new THREE.TorusGeometry(0.128, 0.032, 8, 16), this.matBand);
    this.bandMesh.rotation.x = Math.PI / 2 + 0.12;
    this.bandMesh.position.y = 0.17;
    this.head.add(this.bandMesh);
    // number sprite
    const nc = document.createElement('canvas'); nc.width = nc.height = 64;
    this._numCanvas = nc;
    const ntex = new THREE.CanvasTexture(nc);
    this.numSprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: ntex, transparent: true, depthWrite: false }));
    this.numSprite.scale.setScalar(0.19);
    this.numSprite.position.set(0, 0.3, 0.13);
    this.torso.add(this.numSprite);
    this._drawNumber();
    // arms
    this.armL = this._makeArm(-1); this.armR = this._makeArm(1);
    // legs
    this.legL = this._makeLeg(-1); this.legR = this._makeLeg(1);
    // aura
    this.aura = null;
    this.setAura(this.auraColor);
    // face slightly forward
    this.root.rotation.y = 0;
  }

  _makeArm(side) {
    const shoulder = new THREE.Group();
    shoulder.position.set(side * 0.2, 0.47, 0);
    this.torso.add(shoulder);
    const upper = limb(0.048, 0.3, this.matBody);
    shoulder.add(upper);
    const elbow = new THREE.Group();
    elbow.position.y = -0.3;
    shoulder.add(elbow);
    const fore = limb(0.042, 0.28, this.matBody);
    elbow.add(fore);
    const hand = new THREE.Mesh(new THREE.SphereGeometry(0.055, 8, 6), this.matBody);
    hand.position.y = -0.3;
    elbow.add(hand);
    return { shoulder, elbow, hand };
  }
  _makeLeg(side) {
    const hip = new THREE.Group();
    hip.position.set(side * 0.105, -0.08, 0);
    this.pelvis.add(hip);
    const thigh = limb(0.07, 0.44, this.matBody);
    hip.add(thigh);
    const knee = new THREE.Group();
    knee.position.y = -0.44;
    hip.add(knee);
    const shin = limb(0.055, 0.42, this.matBody);
    knee.add(shin);
    const foot = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.06, 0.21), this.matShoe);
    foot.position.set(0, -0.44, 0.05);
    foot.castShadow = true;
    knee.add(foot);
    return { hip, knee };
  }

  _drawNumber() {
    const g = this._numCanvas.getContext('2d');
    g.clearRect(0, 0, 64, 64);
    g.fillStyle = 'rgba(243,226,195,0.95)';
    g.font = '900 44px Arial Black, Arial';
    g.textAlign = 'center'; g.textBaseline = 'middle';
    g.fillText(String(this.number), 32, 34);
    this.numSprite.material.map.needsUpdate = true;
  }

  setColors(jersey, band) {
    this.jersey = jersey; this.band = band;
    this.matBody.color.set(jersey);
    this.matHead.color.set(jersey).multiplyScalar(0.72);
    this.matBand.color.set(band);
  }
  setNumber(n) { this.number = n; this._drawNumber(); }
  setAura(color) {
    this.auraColor = color;
    if (this.aura) { this.root.remove(this.aura); this.aura = null; }
    if (!color) return;
    const c = document.createElement('canvas'); c.width = c.height = 128;
    const g = c.getContext('2d');
    const grad = g.createRadialGradient(64, 64, 8, 64, 64, 62);
    grad.addColorStop(0, 'rgba(255,255,255,.9)'); grad.addColorStop(0.4, color + 'AA'); grad.addColorStop(1, color + '00');
    g.fillStyle = grad; g.beginPath(); g.arc(64, 64, 62, 0, Math.PI * 2); g.fill();
    const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: new THREE.CanvasTexture(c), transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, opacity: 0.5 }));
    s.scale.set(1.15, 0.5, 1); s.position.y = 0.16;
    this.root.add(s);
    this.aura = s;
  }

  setState(state, dur = 1) {
    this.state = state;
    this.actionT = 0;
    this.actionDur = Math.max(0.01, dur);
  }

  handPos(side) {
    const arm = side < 0 ? this.armL : this.armR;
    const v = new THREE.Vector3();
    arm.hand.getWorldPosition(v);
    return v;
  }

  // ctx = { speed, sprint, hasBall, dribblePhase, dribbleHand, faceYaw, dt }
  update(dt, ctx = {}) {
    const s = this.state;
    this.actionT = Math.min(1, this.actionT + dt / this.actionDur);
    const t = this.actionT;
    const spd = ctx.speed || 0;
    this.runPhase += dt * (2.4 + spd * 2.6);
    this.breath += dt * 1.7;
    // facing
    if (ctx.faceYaw !== undefined) {
      let d = ctx.faceYaw - this.root.rotation.y;
      while (d > Math.PI) d -= Math.PI * 2;
      while (d < -Math.PI) d += Math.PI * 2;
      this.root.rotation.y += d * Math.min(1, dt * 10);
    }

    // ---- default targets ----
    let P = { px: 0, py: 0, pitch: 0, roll: 0, yaw: 0 };          // pelvis
    let T = { pitch: 0.06, yaw: 0, roll: 0 };                     // torso
    let Hd = { pitch: 0, yaw: 0 };
    let aL = { sp: 0, sr: 0.12, el: -0.25 };                       // shoulder pitch/roll, elbow bend
    let aR = { sp: 0, sr: -0.12, el: -0.25 };
    let lL = { hp: 0, hr: 0.06, kn: -0.08 };
    let lR = { hp: 0, hr: -0.06, kn: -0.08 };

    const runAmp = clamp(spd / 6.2, 0, 1);
    const ph = this.runPhase;

    switch (s) {
      case 'idle': {
        P.py = Math.sin(this.breath) * 0.012;
        T.pitch = 0.06 + Math.sin(this.breath * 0.8) * 0.02;
        aL.sr = 0.14; aR.sr = -0.14;
        aL.sp = Math.sin(this.breath * 0.8) * 0.04; aR.sp = -Math.sin(this.breath * 0.8) * 0.04;
        break;
      }
      case 'run': case 'defense': {
        const def = s === 'defense';
        const amp = def ? 0.5 : 0.66 * runAmp + 0.06;
        const baseCrouch = def ? 0.22 : clamp(spd * 0.028, 0.04, 0.2);
        P.py = -baseCrouch + Math.abs(Math.sin(ph)) * (def ? 0.02 : 0.05) * (0.4 + runAmp);
        P.pitch = baseCrouch * 0.9;
        const swing = Math.sin(ph) * amp;
        lL.hp = swing + (def ? 0.34 : 0.06); lR.hp = -swing + (def ? -0.06 : 0.06);
        lL.hr = def ? 0.24 : 0.06; lR.hr = def ? -0.24 : -0.06;
        lL.kn = -Math.max(0.15, (1 - Math.sin(ph)) * 0.9) * (0.5 + runAmp * 0.8);
        lR.kn = -Math.max(0.15, (1 + Math.sin(ph)) * 0.9) * (0.5 + runAmp * 0.8);
        if (def) {
          // low athletic guard: arms wide but angled down, hands stay live
          aL.sp = -0.55 + Math.sin(ph * 2) * 0.05; aR.sp = -0.55 - Math.sin(ph * 2) * 0.05;
          aL.sr = 0.62; aR.sr = -0.62; aL.el = -0.65; aR.el = -0.65;
          T.yaw = Math.sin(ph) * 0.06;
        } else {
          // full sprint: big counter-swinging arms, forward lean into speed
          aL.sp = -swing * 0.95; aR.sp = swing * 0.95;
          aL.sr = 0.16; aR.sr = -0.16;
          aL.el = -0.72 - runAmp * 0.4; aR.el = -0.72 - runAmp * 0.4;
          T.yaw = Math.sin(ph) * 0.09 * runAmp;
          T.pitch = baseCrouch * 1.1 + runAmp * 0.13;
        }
        break;
      }
      case 'dribble': {
        const dp = ctx.dribblePhase || 0;
        P.py = -0.14 - Math.abs(Math.sin(dp * Math.PI)) * 0.03;
        P.pitch = 0.22; T.pitch = 0.2; T.yaw = ctx.dribbleHand < 0 ? -0.18 : 0.18;
        const pump = Math.sin(dp * Math.PI * 2);
        const arm = ctx.dribbleHand < 0 ? aL : aR;
        arm.sp = -0.55 + pump * 0.28; arm.el = -0.5 - pump * 0.35;
        const other = ctx.dribbleHand < 0 ? aR : aL;
        other.sp = -0.35 - pump * 0.07; other.sr = (ctx.dribbleHand < 0 ? -1 : 1) * 0.4; other.el = -1.1;
        lL.hp = 0.18; lR.hp = -0.18; lL.hr = 0.22; lR.hr = -0.22;
        lL.kn = -0.38; lR.kn = -0.38;
        // add run cycle on top if moving
        if (spd > 1.5) {
          lL.hp += Math.sin(ph) * 0.4; lR.hp -= Math.sin(ph) * 0.4;
          lL.kn -= Math.max(0, Math.sin(ph)) * 0.5; lR.kn -= Math.max(0, -Math.sin(ph)) * 0.5;
        }
        break;
      }
      case 'jumpshot': {
        // t: 0 gather -> 0.4 rise -> 0.62 release -> 1 follow
        const gather = clamp(t / 0.38, 0, 1);
        const rise = clamp((t - 0.38) / 0.24, 0, 1);
        const follow = clamp((t - 0.62) / 0.38, 0, 1);
        P.py = -0.22 * gather + 0.0; // jump handled by actor position
        lL.kn = -0.85 * gather * (1 - rise) - 0.15 * (1 - gather);
        lR.kn = lL.kn;
        lL.hp = 0.3 * gather * (1 - rise) + 0.04; lR.hp = 0.3 * gather * (1 - rise) + 0.04;
        lL.hr = 0.1; lR.hr = -0.1;
        const raise = clamp((t - 0.25) / 0.37, 0, 1);
        const sp = lerp(-0.5, -2.9, raise);
        aR.sp = sp; aR.sr = lerp(-0.12, -0.2, raise);
        // guide hand rides the ball, then drops away in the follow-through
        aL.sp = sp - follow * 1.1;
        aL.sr = lerp(0.12, 0.26, raise) + follow * 0.12;
        aL.el = lerp(-0.5, -0.3, raise) - follow * 0.55;
        // shooting elbow extends into the wrist flick
        aR.el = lerp(-0.5, -0.5, raise) + follow * 0.34;
        T.pitch = lerp(0.14, -0.06, raise) - follow * 0.04;
        T.yaw = (1 - raise) * 0.22;
        P.yaw = (1 - raise) * 0.3;
        if (follow > 0) { aR.sp = -2.9 - follow * 0.3; }
        Hd.pitch = -0.16 * raise; // eyes on the rim
        break;
      }
      case 'layup': {
        const rise = clamp(t / 0.45, 0, 1);
        lL.kn = -0.9 * (1 - rise) - 0.4; lR.kn = -0.9 * (1 - rise) - 0.75;
        lL.hp = 0.4 * (1 - rise) + 0.1; lR.hp = 0.55 * (1 - rise) - 0.15;
        aR.sp = lerp(0, -3.05, rise); aR.el = -0.3;
        aL.sp = lerp(0, -0.7, rise); aL.el = -0.9;
        T.pitch = 0.12 * (1 - rise);
        break;
      }
      case 'dunk': {
        const wind = clamp(t / 0.35, 0, 1);
        const slam = clamp((t - 0.35) / 0.3, 0, 1);
        aR.sp = lerp(0.5, -3.1, wind) - slam * 0.3;
        aL.sp = lerp(0.4, -2.6, wind) - slam * 0.15;
        aR.el = -0.7 * (1 - wind) - 0.1 + slam * 0.15; aL.el = -0.6 * (1 - wind) - 0.18 + slam * 0.1;
        T.pitch = 0.25 * (1 - wind) - 0.14 * slam;
        P.pitch = 0.1 * (1 - wind) - 0.06 * slam;
        // knees tuck and legs kick back into the slam
        lL.kn = -0.7 * (1 - wind) - slam * 1.15; lR.kn = -1.0 * (1 - wind) - 0.3 - slam * 0.85;
        lL.hp = 0.35 + slam * 0.3; lR.hp = -0.35 + slam * 0.75;
        break;
      }
      case 'cross': {
        const k = Math.sin(t * Math.PI);
        P.yaw = (ctx.crossDir || 1) * k * 0.7;
        T.yaw = (ctx.crossDir || 1) * k * 0.5;
        P.py = -0.2 + k * 0.04;
        P.pitch = 0.24;
        aL.sp = -0.4 + k * 0.5; aR.sp = -0.4 - k * 0.5;
        aL.el = -1.1; aR.el = -1.1;
        lL.hp = 0.3 + k * 0.25; lR.hp = -0.3 - k * 0.1;
        lL.kn = -0.5; lR.kn = -0.42;
        lL.hr = 0.24; lR.hr = -0.24;
        break;
      }
      case 'stepback': {
        const k = Math.sin(clamp(t, 0, 1) * Math.PI);
        P.py = -0.24; P.pitch = -0.18 * k + 0.08;
        T.pitch = -0.1 * k;
        lL.hp = 0.5 * k + 0.1; lR.hp = -0.2;
        lL.kn = -0.3 - k * 0.4; lR.kn = -0.55;
        aL.sp = -0.3; aR.sp = -0.3; aL.el = -0.9; aR.el = -0.9;
        break;
      }
      case 'steal': {
        const k = Math.sin(clamp(t, 0, 1) * Math.PI);
        P.pitch = 0.32; P.py = -0.24;
        aR.sp = -0.9 - k * 0.7; aR.el = -0.35;
        aL.sp = -0.3; aL.sr = 0.5;
        T.yaw = k * 0.45;
        lL.hp = 0.3; lR.hp = -0.35; lL.kn = -0.5; lR.kn = -0.45;
        break;
      }
      case 'block': {
        const rise = clamp(t / 0.5, 0, 1);
        aL.sp = lerp(-0.4, -3.0, rise); aR.sp = lerp(-0.4, -3.0, rise);
        aL.el = -0.15; aR.el = -0.15;
        lL.kn = -0.8 * (1 - rise) - 0.1; lR.kn = -0.8 * (1 - rise) - 0.1;
        T.pitch = -0.08 * rise;
        break;
      }
      case 'fake': {
        const k = Math.sin(clamp(t, 0, 1) * Math.PI * 2) * 0.5;
        aL.sp = -1.4 - k; aR.sp = -1.4 - k;
        aL.el = -1.2; aR.el = -1.2;
        P.py = -0.26; P.pitch = 0.12;
        lL.kn = -0.6; lR.kn = -0.6;
        break;
      }
      case 'stumble': {
        const k = Math.sin(t * Math.PI * 3);
        const wob = (1 - t);
        P.py = -0.3 - wob * 0.15;
        P.pitch = 0.35 * wob + k * 0.14 * wob;
        P.roll = k * 0.3 * wob;
        T.pitch = 0.3 * wob;
        aL.sp = -0.6 + k * 0.8 * wob; aR.sp = -0.6 - k * 0.8 * wob;
        aL.sr = 0.6 + k * 0.4; aR.sr = -0.6 - k * 0.4;
        lL.hp = 0.4 + k * 0.3; lR.hp = -0.1 - k * 0.3;
        lL.kn = -0.7; lR.kn = -0.3;
        break;
      }
      case 'cheer': {
        const k = Math.abs(Math.sin(t * Math.PI * 2));
        aL.sp = -2.9; aR.sp = -2.9; aL.sr = 0.35; aR.sr = -0.35;
        aL.el = -0.2; aR.el = -0.2;
        P.py = -0.05 + k * 0.14;
        lL.kn = -0.3 * k; lR.kn = -0.3 * k;
        break;
      }
      case 'sulk': {
        P.py = -0.26; T.pitch = 0.4;
        aL.sp = -0.1; aR.sp = -0.1; aL.el = -1.4; aR.el = -1.4;
        Hd.pitch = 0.4;
        break;
      }
    }

    // eyes track the rock / the rim
    if (ctx.headYaw) Hd.yaw = clamp(Hd.yaw + ctx.headYaw * 0.65, -0.85, 0.85);

    // ----- apply with smoothing -----
    const k = Math.min(1, dt * 14);
    const ap = (obj, grp, map) => {
      for (const key in obj) {
        const cur = grp.rotation[map[key]];
        grp.rotation[map[key]] = lerp(cur, obj[key], k);
      }
    };
    this.pelvis.position.x = lerp(this.pelvis.position.x, P.px, k);
    this.pelvis.position.y = lerp(this.pelvis.position.y, 1.0 + P.py, k);
    ap(P, this.pelvis, { pitch: 'x', yaw: 'y', roll: 'z' });
    ap(T, this.torso, { pitch: 'x', yaw: 'y', roll: 'z' });
    ap(Hd, this.head, { pitch: 'x', yaw: 'y' });
    ap(aL, this.armL.shoulder, { sp: 'x', sr: 'z' });
    ap(aR, this.armR.shoulder, { sp: 'x', sr: 'z' });
    this.armL.elbow.rotation.x = lerp(this.armL.elbow.rotation.x, aL.el, k);
    this.armR.elbow.rotation.x = lerp(this.armR.elbow.rotation.x, aR.el, k);
    ap(lL, this.legL.hip, { hp: 'x', hr: 'z' });
    ap(lR, this.legR.hip, { hp: 'x', hr: 'z' });
    this.legL.knee.rotation.x = lerp(this.legL.knee.rotation.x, lL.kn, k);
    this.legR.knee.rotation.x = lerp(this.legR.knee.rotation.x, lR.kn, k);
    // aura pulse
    if (this.aura) this.aura.material.opacity = 0.38 + Math.sin(this.breath * 2) * 0.12;
  }
}
