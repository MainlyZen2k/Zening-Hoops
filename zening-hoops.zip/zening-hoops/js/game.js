// ============ ZENING HOOPS — match orchestration: rules, scoring, camera, HUD ============
import * as THREE from 'three';
import { COURT as C, clamp, lerp, rand, dist2d, SAVE, DIFFICULTY, MODES, CATALOG } from './config.js';
import { Actor } from './actor.js';
import { AIController } from './ai.js';

const TRAIL_COLORS = { none: null, green: '#35e06a', fire: '#ff7b2e', ice: '#8ad8ff', rainbow: '#ff5ad2' };

export class Game {
  constructor(app) {
    this.app = app;
    this.world = app.world;
    this.vfx = app.vfx;
    this.sfx = app.sfx;
    this.controls = app.controls;
    this.actors = [];
    this.ais = [];
    this.score = [0, 0];
    this.mode = 'blacktop';
    this.phase = 'idle';
    this.paused = false;
    this.shotClock = null;
    this.gameClock = 0;
    this.possession = 0;
    this.hype = 0;
    this.pendingInbound = null;
    this.pendingDunk = null;
    this.earned = { coins: 0, greens: 0, ankles: 0, steals: 0, blocks: 0, dunks: 0, points: 0 };
    this.camPos = new THREE.Vector3(0, 7.8, 14.5);
    this.camLook = new THREE.Vector3(0, 1.6, 0);
    this._hudT = 0;
  }

  diff() { return DIFFICULTY[SAVE.data.settings.difficulty]; }

  start(modeKey) {
    this.cleanup();
    this.mode = modeKey;
    const m = MODES[modeKey];
    this.modeCfg = m;
    this.score = [0, 0];
    this.phase = 'tip';
    this.tipT = 1.3;
    this.shotClock = m.target ? 14 : null;
    this.gameClock = m.clock || 0;
    this.possession = 0;
    this.pendingInbound = null;
    this.pendingDunk = null;
    this.earned = { coins: 0, greens: 0, ankles: 0, steals: 0, blocks: 0, dunks: 0, points: 0 };

    const mk = (team, isHuman, opts) => {
      const a = new Actor(team, isHuman, opts);
      a.attackHoop = this.world.hoops[team === 0 ? 1 : 0];
      this.world.scene.add(a.stickman.root);
      return a;
    };
    const equip = SAVE.data.equip;
    const human = mk(0, true, { jersey: equip.jersey, band: equip.band, number: equip.number, auraColor: CATALOG.auras.find(x => x.id === equip.aura)?.glow === '#00000000' ? null : CATALOG.auras.find(x => x.id === equip.aura)?.color });
    this.actors = [human];
    const nPlayers = m.players;
    if (nPlayers >= 2) {
      const ai1 = mk(1, false, { jersey: '#3ba7e0', band: '#f3e2c3', number: 23 });
      this.actors.push(ai1);
      this.ais.push(new AIController(ai1, this, this.diff()));
    }
    if (nPlayers >= 4) {
      const mate = mk(0, false, { jersey: equip.jersey, band: equip.band, number: (equip.number + 4) % 100 });
      const ai2 = mk(1, false, { jersey: '#3ba7e0', band: '#1a120b', number: 8 });
      this.actors.push(mate, ai2);
      this.ais.push(new AIController(mate, this, this.diff()), new AIController(ai2, this, this.diff()));
    }
    this.human = human;

    // starting positions
    const spots = [
      [-3, -1.5], [8, 1.5], [-6, 2.2], [9, -2.2]
    ];
    this.actors.forEach((a, i) => {
      a.pos.set(spots[i][0] * (a.team === 0 ? 1 : 1), 0, spots[i][1]);
      a.stickman.root.position.set(a.pos.x, 0, a.pos.z);
    });

    // ball
    const ball = this.app.ball;
    ball.hooks.onScore = (hoop, shooter, swish) => this.onScore(hoop, shooter, swish);
    ball.hooks.onRim = () => this.onRim();
    ball.setTrail(SAVE.data.equip.trail !== 'none', TRAIL_COLORS[SAVE.data.equip.trail] || '#35e06a');
    if (nPlayers >= 2) {
      ball.reset(new THREE.Vector3(-3, 1.0, -1.5));
      this.catchBall(this.human, true);
    } else {
      ball.reset(new THREE.Vector3(-3, 1.0, -1.5));
      this.catchBall(this.human, true);
    }

    // UI
    this.controls.setPassLabel(nPlayers >= 4 ? 'PASS' : 'FAKE');
    this.controls.setStealLabel('STEAL');
    document.getElementById('hud-target').textContent = m.target ? `FIRST TO ${m.target}` : 'FREE PLAY';
    document.getElementById('hud-mode').textContent = m.name;
    document.getElementById('hud').classList.remove('hidden');
    document.getElementById('controls').classList.remove('hidden');
    this.world.setScore(this.score[0], this.score[1], m.name);
    this.sfx.whistle();
    this.sfx.crowd(0.4);
  }

  cleanup() {
    for (const a of this.actors) this.world.scene.remove(a.stickman.root);
    this.actors = [];
    this.ais = [];
    const ball = this.app.ball;
    ball.hooks.onScore = null;
    ball.hooks.onRim = null;
    ball.setTrail(false, '#35e06a');
    ball.reset(new THREE.Vector3(0, C.BALL_R, 0));
  }

  catchBall(actor, silent = false) {
    const ball = this.app.ball;
    const prev = this.possession;
    ball.owner = actor;
    actor.hasBall = true;
    ball.state = 'dribble';
    ball.forcedHoop = null;
    this.possession = actor.team;
    this.shotClock = this.modeCfg?.target ? 14 : null;
    if (!silent && this.phase === 'live' && actor.team !== prev) {
      this.vfx.popup(actor.team === 0 ? 'YOUR BALL' : 'CPU BALL', actor.team === 0 ? '#e9b44c' : '#c9b08c', '', 10, 24);
    }
  }

  // ---------------- events from ball/actor ----------------
  onScore(hoop, shooter, swish) {
    if (this.phase !== 'live' && this.phase !== 'tip') return;
    const ball = this.app.ball;
    const pts = ball.pointValue(hoop);
    const team = shooter.team;
    this.score[team] += pts;
    this.hype = 1;
    const dunk = this.pendingDunk === shooter;
    this.pendingDunk = null;

    const wasGreen = shooter.lastShot && shooter.lastShot.green && shooter.lastShot.hoop === hoop;
    if (team === 0) {
      let c = wasGreen ? 5 : pts === 3 ? 3 : 2;
      if (dunk) c += 3;
      this.earned.coins += c;
      this.earned.points += pts;
      if (wasGreen) this.earned.greens++;
      if (dunk) this.earned.dunks++;
      SAVE.stat('points', pts);
      if (wasGreen) {
        this.vfx.popup('GREEN!', '#35e06a', shooter.isHuman ? 'perfect release' : '', 0, 44);
        this.vfx.shake(0.3);
      } else if (dunk) {
        this.vfx.popup(shooter.isHuman ? 'THROWDOWN!' : '', '#ff8c3b', 'slammed it home', 0, 40);
      } else if (swish) {
        this.vfx.popup(shooter.isHuman ? 'SPLASH!' : 'SWISH', '#e9b44c', pts === 3 ? 'from deep' : '', 0, 34);
        this.sfx.swish();
      } else if (shooter.isHuman) {
        this.vfx.popup('BUCKETS', '#e9b44c', '', 0, 30);
      }
    } else {
      if (swish) this.sfx.swish();
      this.vfx.popup('CPU SCORES', '#c9b08c', '', 8, 24);
    }
    if (swish) {
      this.vfx.burst(hoop.rimCenter.clone().add(new THREE.Vector3(0, -0.2, 0)), '#f3e2c3', 14, { speed: 1.6, size: 0.1, life: 0.4, gravity: -3 });
    }
    this.vfx.ring(hoop.rimCenter.clone().add(new THREE.Vector3(0, 0.1, 0)), wasGreen ? 0x35e06a : 0xff8c3b);
    this.sfx.crowd(team === 0 ? 0.9 : 0.4);
    this.world.setScore(this.score[0], this.score[1], this.modeCfg.name);
    this._updateScoreHUD();

    // check win
    if (this.modeCfg.target && this.score[team] >= this.modeCfg.target) {
      this.end(team === 0);
      return;
    }
    // inbound to the team that got scored on
    this.pendingInbound = { team: 1 - team, t: 0.85 };
    this.shotClock = this.modeCfg?.target ? 14 : null;
  }

  onRim() {
    if (this.shotClock !== null && this.phase === 'live') this.shotClock = Math.max(this.shotClock, 14);
  }
  onShotReleased(actor, green, q) {
    if (actor.isHuman && green) SAVE.stat('greens');
  }
  onDunk(actor) {
    this.pendingDunk = actor;
    if (actor.isHuman) SAVE.stat('dunks');
    this.vfx.ring(actor.pos.clone().setY(0.05), 0xff8c3b, true);
  }
  onAnkles(actor) {
    if (actor.isHuman) {
      this.earned.ankles++;
      this.earned.coins += 4;
      SAVE.stat('ankles');
      this.hype = 1;
      this.sfx.crowd(1);
    }
  }
  onSteal(actor) {
    if (actor.isHuman) {
      this.earned.steals++;
      this.earned.coins += 2;
      SAVE.stat('steals');
    }
  }
  onBlock(actor) {
    if (actor.isHuman) {
      this.earned.blocks++;
      this.earned.coins += 3;
      SAVE.stat('blocks');
    }
  }
  defenderReact(actor) { return actor.isHuman ? 0.3 : this.diff().react; }
  equippedTrail() { return SAVE.data.equip.trail; }

  // ---------------- inbound / OOB ----------------
  _doInbound(team) {
    const ball = this.app.ball;
    const members = this.actors.filter(a => a.team === team);
    const defendHoop = this.world.hoops[team === 0 ? 0 : 1];
    const spotX = Math.sign(defendHoop.rimCenter.x) * (C.HALF_L - 1.6);
    // inbounder = closest member to that baseline
    let ib = members[0];
    for (const m of members) if (Math.abs(m.pos.x - spotX) < Math.abs(ib.pos.x - spotX)) ib = m;
    ib.pos.set(spotX, 0, rand(-1.5, 1.5));
    ib.vel.set(0, 0, 0);
    ball.reset(new THREE.Vector3(ib.pos.x, 1.1, ib.pos.z));
    this.catchBall(ib, true);
    this.vfx.popup(team === 0 ? 'YOUR BALL' : 'CPU BALL', team === 0 ? '#e9b44c' : '#c9b08c', '', 10, 24);
  }

  _checkOOB() {
    const ball = this.app.ball;
    if (ball.owner) return;
    const p = ball.mesh.position;
    if (Math.abs(p.x) > C.HALF_L + 1.8 || Math.abs(p.z) > C.HALF_W + 1.4) {
      // to the team that didn't touch last
      const lastTeam = ball.shooter ? ball.shooter.team : 1 - this.possession;
      this.pendingInbound = { team: 1 - lastTeam, t: 0.35 };
      this.vfx.popup('OUT OF BOUNDS', '#c9b08c', '', 8, 22);
      this.sfx.whistle();
      ball.reset(new THREE.Vector3(clamp(p.x, -C.HALF_L, C.HALF_L), 2, clamp(p.z, -C.HALF_W, C.HALF_W)));
    }
  }

  // ---------------- main update ----------------
  update(dt, t) {
    const ball = this.app.ball;
    const live = this.phase === 'live' && !this.paused;

    // tip countdown
    if (this.phase === 'tip' && !this.paused) {
      this.tipT -= dt;
      if (this.tipT <= 0) {
        this.phase = 'live';
        this.sfx.whistle();
      }
    }

    // brains
    const intents = this.controls.sample();
    if (live) {
      if (this.human) {
        const I = this.human.intents;
        if (this.modeCfg.players >= 4) {
          // 2v2: pass button passes; 1v1: pass button = pump fake
          I.pass = intents.pass;
          if (intents.pass && !this.human.hasBall) { I.flick = 'up'; I.pass = false; }
        } else {
          I.pass = false;
          if (intents.pass) I.flick = 'up';
        }
        I.move = intents.move;
        I.flick = intents.flick || I.flick;
        I.shootDown = intents.shootDown;
        I.shootUp = intents.shootUp;
        I.steal = intents.steal;
      }
      for (const ai of this.ais) ai.update(dt, this._ctx());
    }
    const ctx = this._ctx();
    for (const a of this.actors) a.update(dt, ctx);
    ball.update(dt, this.world, this.actors, this.vfx, this.sfx, t);

    if (live) {
      // pending inbound
      if (this.pendingInbound) {
        this.pendingInbound.t -= dt;
        if (this.pendingInbound.t <= 0) {
          this._doInbound(this.pendingInbound.team);
          this.pendingInbound = null;
        }
      }
      // shot clock
      if (this.shotClock !== null) {
        this.shotClock -= dt;
        if (this.shotClock <= 0) {
          this.sfx.whistle();
          this.vfx.popup('SHOT CLOCK!', '#e05038', 'turnover', 8, 28);
          this.pendingInbound = { team: 1 - this.possession, t: 0.4 };
          this.shotClock = 14;
        }
      }
      // game clock
      if (this.gameClock > 0) {
        this.gameClock -= dt;
        if (this.gameClock <= 0) {
          this.gameClock = 0;
          this.sfx.buzzer();
          this.end(this.score[0] >= this.score[1]);
        }
      }
      this._checkOOB();
    }

    // hype decay / crowd ambience
    this.hype = Math.max(0, this.hype - dt * 0.4);
    this._crowdT = (this._crowdT || 0) + dt;
    if (this._crowdT > 2.5) {
      this._crowdT = 0;
      if (this.phase === 'live') this.sfx.crowd(0.1 + this.hype * 0.35);
    }
    this.world.crowdHype = this.hype;

    // camera
    this._camera(dt);

    // HUD (throttled)
    this._hudT += dt;
    if (this._hudT > 0.08) { this._hudT = 0; this._updateHUD(); }
  }

  _ctx() {
    return { world: this.world, ball: this.app.ball, actors: this.actors, game: this, vfx: this.vfx, sfx: this.sfx };
  }

  _camera(dt) {
    const ball = this.app.ball;
    const p = ball.mesh.position;
    // 2K-style broadcast camera: high sideline telephoto tracking the ball,
    // leaning toward the attacking rim and drifting onto the hoop when a shot is up
    const rim = this.human ? this.human.attackHoop.rimCenter : new THREE.Vector3(C.RIM_X, C.RIM_H, 0);
    const distRim = Math.min(Math.abs(p.x - C.RIM_X), Math.abs(p.x + C.RIM_X));
    const zoom = clamp(1 - (distRim - 3.5) / 6.5, 0, 1); // 0 midcourt -> 1 at rim
    const lead = clamp((p.x - this.camPos.x) * 0.22, -1.8, 1.8);
    const fx = clamp(p.x * 0.82 + lead + Math.sign(rim.x) * 1.4, -12.5, 12.5);
    const fz = clamp(p.z * 0.32, -2.4, 2.4);
    const want = new THREE.Vector3(
      fx,
      7.1 - zoom * 0.9 + this.vfx.shakeMag * 0.3,
      12.9 - zoom * 1.4 + fz * 0.5
    );
    this.camPos.lerp(want, Math.min(1, dt * 4.2));
    // goal view: while the ball is in the air the gaze eases onto the rim
    const air = ball.state === 'shot' ? clamp(1 - Math.abs(p.x - rim.x) / 14, 0.25, 1) : 0;
    const look = new THREE.Vector3(
      lerp(fx * 0.92, rim.x, air * 0.55),
      lerp(1.6, 2.5, air * 0.5),
      lerp(fz, rim.z * 0.5, air * 0.55)
    );
    this.camLook.lerp(look, Math.min(1, dt * 5.0));
    const shake = this.vfx.shakeMag;
    const cam = this.world.camera;
    cam.position.set(
      this.camPos.x + (Math.random() - 0.5) * shake * 0.5,
      this.camPos.y + (Math.random() - 0.5) * shake * 0.4,
      this.camPos.z + (Math.random() - 0.5) * shake * 0.3
    );
    cam.lookAt(this.camLook);
    // telephoto punch-in as the play attacks the rim
    const targetFov = 47 - zoom * 4;
    if (Math.abs(cam.fov - targetFov) > 0.01) {
      cam.fov += (targetFov - cam.fov) * Math.min(1, dt * 3.5);
      cam.updateProjectionMatrix();
    }
  }

  // ---------------- HUD ----------------
  _updateScoreHUD() {
    document.querySelector('.team-you').textContent = `YOU ${this.score[0]}`;
    document.querySelector('.team-ai').textContent = `${this.score[1]} CPU`;
  }
  _updateHUD() {
    this._updateScoreHUD();
    const clockEl = document.getElementById('hud-clock');
    if (this.modeCfg?.clock) {
      const m = Math.floor(this.gameClock / 60), s = Math.floor(this.gameClock % 60);
      clockEl.textContent = `${m}:${String(s).padStart(2, '0')}`;
      clockEl.style.display = '';
    } else clockEl.style.display = 'none';
    const scEl = document.getElementById('hud-shotclock');
    if (this.shotClock !== null && this.phase === 'live') {
      scEl.textContent = Math.max(0, Math.ceil(this.shotClock));
      scEl.classList.toggle('low', this.shotClock < 5);
      scEl.style.display = '';
    } else scEl.style.display = 'none';
    const stam = document.getElementById('stam-fill');
    if (this.human) stam.style.width = this.human.stamina + '%';
    const poss = document.getElementById('hud-possession');
    poss.textContent = this.phase === 'live' ? (this.possession === 0 ? 'YOUR BALL' : 'CPU BALL') : '';

    // shot meter
    const meter = document.getElementById('meter');
    const h = this.human;
    if (h && h.shot && !h.shot.released) {
      meter.classList.add('show');
      const s = h.shot;
      const fill = document.getElementById('meter-fill');
      fill.style.height = clamp(s.meterT / s.dur * 100, 0, 100) + '%';
      const gEl = document.getElementById('meter-green');
      gEl.style.bottom = clamp((s.greenT - s.greenHalf) / s.dur * 100, 0, 96) + '%';
      gEl.style.height = clamp((s.greenHalf * 2) / s.dur * 100, 3, 40) + '%';
      fill.classList.remove('perfect');
    } else if (h && h.shot && h.shot.released) {
      meter.classList.add('show');
      const fill = document.getElementById('meter-fill');
      if (h.lastShot && h.lastShot.green) fill.classList.add('perfect');
      this._meterHideT = (this._meterHideT || 0) + 0.08;
      if (this._meterHideT > 0.5) { meter.classList.remove('show'); this._meterHideT = 0; }
    } else {
      meter.classList.remove('show');
    }
  }

  // ---------------- end ----------------
  end(win) {
    if (this.phase === 'over') return;
    this.phase = 'over';
    this.paused = false;
    this.sfx.buzzer();
    this.sfx.crowd(win ? 1 : 0.3);
    for (const a of this.actors) a.celebrate(a.team === 0 ? win : !win);
    if (this.modeCfg.target) {
      const winBonus = win ? 50 : 10;
      const total = this.earned.coins + winBonus;
      SAVE.addCoins(total);
      SAVE.stat('games');
      if (win) SAVE.stat('wins');
      this.app.showResult({ win, score: [...this.score], earned: this.earned, total, mode: this.modeCfg.name });
    }
    document.getElementById('hud').classList.add('hidden');
    document.getElementById('controls').classList.add('hidden');
  }

  quitToMenu() {
    this.phase = 'idle';
    this.cleanup();
    this.world.camera.fov = 50;
    this.world.camera.updateProjectionMatrix();
    document.getElementById('hud').classList.add('hidden');
    document.getElementById('controls').classList.add('hidden');
    document.getElementById('meter').classList.remove('show');
    this.app.toMenu();
  }
}
