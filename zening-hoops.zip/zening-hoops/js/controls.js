// ============ ZENING HOOPS — touch controls: joystick, flicks, buttons, keyboard ============
import { clamp } from './config.js';

export class Controls {
  constructor() {
    this.move = { x: 0, z: 0, mag: 0, sprint: false };
    this.flicks = [];          // 'left'|'right'|'up'|'down'
    this.shootDown = false;
    this.shootUp = false;
    this.pass = false;
    this.steal = false;
    this._stickId = null;
    this._stickOrigin = null;
    this._swipeId = null;
    this._swipeStart = null;
    this._keys = {};
    this._bind();
  }
  _bind() {
    const stickZone = document.getElementById('stick-zone');
    const base = document.getElementById('stick-base');
    const knob = document.getElementById('stick-knob');
    const swipe = document.getElementById('swipe-zone');
    const R = 52;

    const setKnob = (dx, dy) => { knob.style.transform = `translate(calc(-50% + ${dx}px), calc(-50% + ${dy}px))`; };

    stickZone.addEventListener('pointerdown', e => {
      if (this._stickId !== null) return;
      this._stickId = e.pointerId;
      this._stickOrigin = { x: e.clientX, y: e.clientY };
      base.style.display = 'block';
      base.style.left = (e.clientX - 60) + 'px';
      base.style.top = (e.clientY - 60) + 'px';
      setKnob(0, 0);
      try { stickZone.setPointerCapture(e.pointerId); } catch (err) { /* synthetic pointer */ }
    });
    stickZone.addEventListener('pointermove', e => {
      if (e.pointerId !== this._stickId || !this._stickOrigin) return;
      let dx = e.clientX - this._stickOrigin.x, dy = e.clientY - this._stickOrigin.y;
      const d = Math.hypot(dx, dy);
      if (d > R) { dx = dx / d * R; dy = dy / d * R; }
      this._stickVec = { x: dx / R, y: dy / R };
      setKnob(dx, dy);
    });
    const stickEnd = e => {
      if (e.pointerId !== this._stickId) return;
      this._stickId = null; this._stickVec = null; this._stickOrigin = null;
      base.style.display = 'none';
      setKnob(0, 0);
    };
    stickZone.addEventListener('pointerup', stickEnd);
    stickZone.addEventListener('pointercancel', stickEnd);

    // swipe zone
    swipe.addEventListener('pointerdown', e => {
      if (this._swipeId !== null) return;
      this._swipeId = e.pointerId;
      this._swipeStart = { x: e.clientX, y: e.clientY, t: performance.now() };
      try { swipe.setPointerCapture(e.pointerId); } catch (err) { /* synthetic pointer */ }
    });
    swipe.addEventListener('pointerup', e => {
      if (e.pointerId !== this._swipeId) return;
      this._swipeId = null;
      if (!this._swipeStart) return;
      const dx = e.clientX - this._swipeStart.x, dy = e.clientY - this._swipeStart.y;
      const dt = performance.now() - this._swipeStart.t;
      this._swipeStart = null;
      const d = Math.hypot(dx, dy);
      if (d < 26 || dt > 420) return;
      if (Math.abs(dx) > Math.abs(dy)) this.flicks.push(dx > 0 ? 'right' : 'left');
      else this.flicks.push(dy > 0 ? 'down' : 'up');
    });
    swipe.addEventListener('pointercancel', () => { this._swipeId = null; this._swipeStart = null; });

    // buttons
    const bindBtn = (id, down, up) => {
      const el = document.getElementById(id);
      el.addEventListener('pointerdown', e => { e.preventDefault(); try { el.setPointerCapture(e.pointerId); } catch (err) { /* synthetic or stale pointer */ } down(); });
      const end = e => { e.preventDefault(); if (up) up(); };
      el.addEventListener('pointerup', end);
      el.addEventListener('pointercancel', end);
    };
    bindBtn('btn-shoot', () => { this.shootDown = true; }, () => { this.shootUp = true; });
    bindBtn('btn-pass', () => { this.pass = true; });
    bindBtn('btn-steal', () => { this.steal = true; });

    // keyboard
    addEventListener('keydown', e => {
      if (this._keys[e.code]) return;
      this._keys[e.code] = true;
      if (e.code === 'Space' || e.code === 'KeyJ') this.shootDown = true;
      if (e.code === 'KeyK') this.pass = true;
      if (e.code === 'KeyL' || e.code === 'KeyE') this.steal = true;
      if (e.code === 'KeyZ') this.flicks.push('down');
      if (e.code === 'KeyX') this.flicks.push(Math.random() < 0.5 ? 'left' : 'right');
      if (e.code === 'KeyC') this.flicks.push('up');
    });
    addEventListener('keyup', e => {
      this._keys[e.code] = false;
      if (e.code === 'Space' || e.code === 'KeyJ') this.shootUp = true;
    });
  }
  setPassLabel(text) { document.getElementById('btn-pass').textContent = text; }
  setStealLabel(text) { document.getElementById('btn-steal').textContent = text; }
  // per-frame sample + consume events
  sample() {
    // joystick
    let mx = 0, mz = 0;
    if (this._stickVec) { mx = this._stickVec.x; mz = -this._stickVec.y; }
    const K = this._keys;
    if (K['KeyW'] || K['ArrowUp']) mz += 1;
    if (K['KeyS'] || K['ArrowDown']) mz -= 1;
    if (K['KeyA'] || K['ArrowLeft']) mx -= 1;
    if (K['KeyD'] || K['ArrowRight']) mx += 1;
    let mag = Math.min(1, Math.hypot(mx, mz));
    const sprint = mag > 0.93 || K['ShiftLeft'] || K['ShiftRight'];
    this.move = { x: mag > 0 ? mx / Math.max(mag, 0.0001) * mag : 0, z: mag > 0 ? mz / Math.max(mag, 0.0001) * mag : 0, mag, sprint };
    const out = {
      move: this.move,
      flick: this.flicks.shift() || null,
      shootDown: this.shootDown, shootUp: this.shootUp,
      pass: this.pass, steal: this.steal
    };
    this.shootDown = false; this.shootUp = false; this.pass = false; this.steal = false;
    // a same-frame down+up (fast tap) would swallow the release —
    // hold shootUp for the next frame so the meter reads a real tap
    if (out.shootDown && out.shootUp) {
      this._pendingShootUp = true;
      out.shootUp = false;
    } else if (this._pendingShootUp && !out.shootDown) {
      out.shootUp = true;
      this._pendingShootUp = false;
    }
    return out;
  }
  releaseAll() {
    this.flicks.length = 0;
    this.shootDown = false; this.shootUp = false; this.pass = false; this.steal = false;
    this._stickVec = null; this._stickId = null;
    document.getElementById('stick-base').style.display = 'none';
    for (const k in this._keys) this._keys[k] = false;
  }
}
