// ============ ZENING HOOPS — touch controls: joystick, flicks, buttons, keyboard ============
// Built for real phones: pointer AND touch event layers, window-level tracking
// (no reliance on setPointerCapture), so the stick works no matter what the
// WebView does with capture, hit-testing or multi-touch.
import { clamp } from './config.js';

export class Controls {
  constructor() {
    this.move = { x: 0, z: 0, mag: 0, sprint: false };
    this.flicks = [];          // 'left'|'right'|'up'|'down'
    this.shootDown = false;
    this.shootUp = false;
    this.pass = false;
    this.steal = false;
    // stick state: map of active pointers -> {ox, oy, vx, vy}
    this._stickers = new Map();
    this._keys = {};
    this._baseRect = null;
    this._bind();
  }

  _bind() {
    const zone = document.getElementById('stick-zone');
    const base = document.getElementById('stick-base');
    const knob = document.getElementById('stick-knob');
    const home = document.getElementById('stick-home');
    const swipe = document.getElementById('swipe-zone');
    const R = 52;

    // keep the base inside the zone (base is positioned relative to the zone)
    const setBasePos = (clientX, clientY) => {
      if (!this._baseRect) this._baseRect = zone.getBoundingClientRect();
      const r = this._baseRect;
      const x = clamp(clientX - r.left - 60, -20, r.width - 100);
      const y = clamp(clientY - r.top - 60, -20, r.height - 100);
      base.style.left = x + 'px';
      base.style.top = y + 'px';
    };
    const setKnob = (dx, dy) => { knob.style.transform = `translate(calc(-50% + ${dx}px), calc(-50% + ${dy}px))`; };
    const showBase = (cx, cy) => { this._baseRect = zone.getBoundingClientRect(); base.style.display = 'block'; setBasePos(cx, cy); setKnob(0, 0); if (home) home.style.opacity = '0'; };
    const hideBase = () => { base.style.display = 'none'; setKnob(0, 0); this._baseRect = null; if (home) home.style.opacity = ''; };

    // ---- shared stick logic ----
    const stickDown = (id, cx, cy) => {
      if (this._stickers.size >= 2) return;      // one stick, tolerate a stray ghost pointer
      this._stickers.set(id, { ox: cx, oy: cy, vx: 0, vy: 0 });
      showBase(cx, cy);
    };
    const stickMove = (id, cx, cy) => {
      const s = this._stickers.get(id);
      if (!s) return;
      let dx = cx - s.ox, dy = cy - s.oy;
      const d = Math.hypot(dx, dy);
      if (d > R) { dx = dx / d * R; dy = dy / d * R; }
      s.vx = dx / R; s.vy = dy / R;
      setKnob(dx, dy);
    };
    const stickEnd = (id) => {
      if (!this._stickers.delete(id)) return;
      if (this._stickers.size === 0) hideBase();
    };
    const stickVec = () => {
      // use the newest active pointer on the stick
      let last = null;
      for (const s of this._stickers.values()) last = s;
      return last ? { x: last.vx, y: last.vy } : null;
    };

    // ---- POINTER EVENTS (mouse + modern WebView) ----
    zone.addEventListener('pointerdown', e => {
      if (e.pointerType === 'mouse' && e.button !== 0) return;
      stickDown(e.pointerId, e.clientX, e.clientY);
      try { zone.setPointerCapture(e.pointerId); } catch (err) { /* handled by window listeners below */ }
      e.preventDefault();
    }, { passive: false });
    zone.addEventListener('pointermove', e => stickMove(e.pointerId, e.clientX, e.clientY));
    zone.addEventListener('pointerup', e => stickEnd(e.pointerId));
    zone.addEventListener('pointercancel', e => stickEnd(e.pointerId));
    // window-level safety net: catches moves/ups even when capture silently fails
    // or the WebView retargets events to another element (the classic
    // "thumbstick dead on my phone" WebView bug)
    window.addEventListener('pointermove', e => stickMove(e.pointerId, e.clientX, e.clientY));
    window.addEventListener('pointerup', e => stickEnd(e.pointerId));
    window.addEventListener('pointercancel', e => stickEnd(e.pointerId));

    // ---- TOUCH EVENTS fallback (older WebViews with flaky pointer events) ----
    let touched = false;
    const tPos = t => ({ id: 't' + t.identifier, x: t.clientX, y: t.clientY });
    zone.addEventListener('touchstart', e => {
      touched = true;
      for (const t of e.changedTouches) { const p = tPos(t); stickDown(p.id, p.x, p.y); }
      e.preventDefault();
    }, { passive: false });
    zone.addEventListener('touchmove', e => {
      for (const t of e.changedTouches) { const p = tPos(t); stickMove(p.id, p.x, p.y); }
      e.preventDefault();
    }, { passive: false });
    const touchEnd = e => {
      for (const t of e.changedTouches) stickEnd(tPos(t).id);
      if (e.cancelable) e.preventDefault();
    };
    zone.addEventListener('touchend', touchEnd, { passive: false });
    zone.addEventListener('touchcancel', touchEnd, { passive: false });

    // ---- SWIPE ZONE (dribble moves on offense; quick lunge on defense) ----
    const swipeDown = (id, cx, cy) => {
      this._swipes = this._swipes || new Map();
      if (this._swipes.size >= 2) return;
      this._swipes.set(id, { x: cx, y: cy, t: performance.now() });
      try { swipe.setPointerCapture(id); } catch (err) { /* window net catches it */ }
    };
    const swipeUp = (id, cx, cy) => {
      this._swipes = this._swipes || new Map();
      const s = this._swipes.get(id);
      if (!s) return;
      this._swipes.delete(id);
      const dx = cx - s.x, dy = cy - s.y;
      const dt = performance.now() - s.t;
      const d = Math.hypot(dx, dy);
      if (d < 26 || dt > 480) return;
      if (Math.abs(dx) > Math.abs(dy)) this.flicks.push(dx > 0 ? 'right' : 'left');
      else this.flicks.push(dy > 0 ? 'down' : 'up');
    };
    swipe.addEventListener('pointerdown', e => { swipeDown(e.pointerId, e.clientX, e.clientY); e.preventDefault(); }, { passive: false });
    swipe.addEventListener('pointerup', e => swipeUp(e.pointerId, e.clientX, e.clientY));
    swipe.addEventListener('pointercancel', e => { if (this._swipes) this._swipes.delete(e.pointerId); });
    window.addEventListener('pointerup', e => swipeUp(e.pointerId, e.clientX, e.clientY));
    window.addEventListener('pointercancel', e => { if (this._swipes) this._swipes.delete(e.pointerId); });
    swipe.addEventListener('touchstart', e => {
      for (const t of e.changedTouches) swipeDown('t' + t.identifier, t.clientX, t.clientY);
      e.preventDefault();
    }, { passive: false });
    swipe.addEventListener('touchend', e => {
      for (const t of e.changedTouches) swipeUp('t' + t.identifier, t.clientX, t.clientY);
      if (e.cancelable) e.preventDefault();
    }, { passive: false });
    swipe.addEventListener('touchcancel', e => { for (const t of e.changedTouches) if (this._swipes) this._swipes.delete('t' + t.identifier); }, { passive: false });

    // ---- BUTTONS ----
    const bindBtn = (id, down, up) => {
      const el = document.getElementById(id);
      if (!el) return;
      el.addEventListener('pointerdown', e => {
        e.preventDefault();
        try { el.setPointerCapture(e.pointerId); } catch (err) { /* fine */ }
        down();
      }, { passive: false });
      const end = e => { e.preventDefault(); if (up) up(); };
      el.addEventListener('pointerup', end);
      el.addEventListener('pointercancel', end);
      // touch fallback for stubborn WebViews (idempotent: flags reset every frame)
      el.addEventListener('touchstart', e => { down(); e.preventDefault(); }, { passive: false });
      el.addEventListener('touchend', e => { if (up) up(); e.preventDefault(); }, { passive: false });
      // mouse fallback for desktop testing
      el.addEventListener('click', e => { if (e.detail === 0) down(); });
    };
    bindBtn('btn-shoot', () => { this.shootDown = true; }, () => { this.shootUp = true; });
    bindBtn('btn-pass', () => { this.pass = true; });
    bindBtn('btn-steal', () => { this.steal = true; });

    // ---- keyboard (dev / desktop) ----
    addEventListener('keydown', e => {
      if (this._keys[e.code]) return;
      this._keys[e.code] = true;
      if (e.code === 'Space' || e.code === 'KeyJ') this.shootDown = true;
      if (e.code === 'KeyK') this.pass = true;
      if (e.code === 'KeyL' || e.code === 'KeyE') this.steal = true;
      if (e.code === 'KeyZ') this.flicks.push('down');
      if (e.code === 'KeyX') this.flicks.push(Math.random() < 0.5 ? 'left' : 'right');
      if (e.code === 'KeyC') this.flicks.push('up');
    });
    addEventListener('keyup', e => {
      this._keys[e.code] = false;
      if (e.code === 'Space' || e.code === 'KeyJ') this.shootUp = true;
    });

    // long-press menus / text selection kill switches while playing
    const noMenu = e => { if (this._stickers.size) e.preventDefault(); };
    zone.addEventListener('contextmenu', e => e.preventDefault());
    swipe.addEventListener('contextmenu', e => e.preventDefault());
    document.addEventListener('contextmenu', e => {
      if (document.getElementById('controls') && !document.getElementById('controls').classList.contains('hidden')) e.preventDefault();
    });
    document.addEventListener('gesturestart', e => e.preventDefault());
  }

  setPassLabel(text) { const el = document.getElementById('btn-pass'); if (el) el.textContent = text; }
  setStealLabel(text) { const el = document.getElementById('btn-steal'); if (el) el.textContent = text; }

  // per-frame sample + consume events
  sample() {
    // joystick (read newest active stick pointer)
    let mx = 0, mz = 0;
    let last = null;
    for (const s of this._stickers.values()) last = s;
    if (last) { mx = last.vx; mz = -last.vy; }
    const K = this._keys;
    if (K['KeyW'] || K['ArrowUp']) mz += 1;
    if (K['KeyS'] || K['ArrowDown']) mz -= 1;
    if (K['KeyA'] || K['ArrowLeft']) mx -= 1;
    if (K['KeyD'] || K['ArrowRight']) mx += 1;
    let mag = Math.min(1, Math.hypot(mx, mz));
    if (mag > 1) { mx /= mag; mz /= mag; mag = 1; }
    const sprint = mag > 0.93 || K['ShiftLeft'] || K['ShiftRight'];
    this.move = { x: mx, z: mz, mag, sprint };
    const out = {
      move: this.move,
      flick: this.flicks.shift() || null,
      shootDown: this.shootDown, shootUp: this.shootUp,
      pass: this.pass, steal: this.steal
    };
    this.shootDown = false; this.shootUp = false; this.pass = false; this.steal = false;
    // a same-frame down+up (fast tap) would swallow the release —
    // hold shootUp for the next frame so the meter reads a real tap
    if (out.shootDown && out.shootUp) {
      this._pendingShootUp = true;
      out.shootUp = false;
    } else if (this._pendingShootUp && !out.shootDown) {
      out.shootUp = true;
      this._pendingShootUp = false;
    }
    return out;
  }

  releaseAll() {
    this.flicks.length = 0;
    this.shootDown = false; this.shootUp = false; this.pass = false; this.steal = false;
    this._stickers.clear();
    if (this._swipes) this._swipes.clear();
    for (const k in this._keys) this._keys[k] = false;
    const base = document.getElementById('stick-base');
    if (base) base.style.display = 'none';
    this._baseRect = null;
  }
}
