// ============ ZENING HOOPS — AI brain: offense, defense, teammates ============
import { clamp, rand, dist2d } from './config.js';

export class AIController {
  constructor(actor, game, diff) {
    this.actor = actor;
    this.game = game;
    this.diff = diff;
    this.decideT = rand(0.3, 0.8);
    this.pendingRelease = false;
    this.releaseT = 0;
    this.moveTarget = null;
    this.rollT = rand(0.6, 1.4);
    this.contestRolled = false;
    this.stealRollT = rand(1.2, 3);
    this.holdT = 0;
  }
  // defense hoop = the one my team defends
  defendHoop() { return this.game.world.hoops[this.actor.team === 0 ? 0 : 1]; }

  update(dt, ctx) {
    const a = this.actor;
    const { ball, actors, game } = ctx;
    const I = a.intents;
    I.move.x = 0; I.move.z = 0; I.move.mag = 0; I.move.sprint = false;
    I.flick = null; I.shootDown = false; I.shootUp = false; I.pass = false; I.steal = false;

    // ---- scheduled shot release (same meter system as human) ----
    if (a.shot && !a.shot.released) {
      if (this.pendingRelease && !this.releaseScheduled) {
        this.releaseScheduled = true;
        const targetQ = clamp(this.diff.shotQ + rand(-0.16, 0.14), 0.25, 0.985);
        this.releaseT = a.shot.greenT + (1 - targetQ) * a.shot.greenHalf * 2.8 * (Math.random() < 0.5 ? -1 : 1);
      }
      if (this.releaseScheduled && a.shot.meterT >= this.releaseT) {
        I.shootUp = true;
        this.pendingRelease = false;
        this.releaseScheduled = false;
      }
      return; // locked in shooting motion
    }

    if (a.mode !== 'free') return;

    const owner = ball.owner;
    const myTeamHasBall = owner && owner.team === a.team;

    // loose ball chase
    if (!owner && ['loose', 'pass'].includes(ball.state)) {
      const chasers = actors.filter(x => x.team === a.team)
        .sort((p, q) => p.pos.distanceTo(ball.mesh.position) - q.pos.distanceTo(ball.mesh.position));
      if (chasers[0] === a) this._seek(ball.mesh.position, I, 1, true);
      return;
    }

    if (myTeamHasBall) {
      if (owner === a) this._offense(dt, ctx, I);
      else this._spotUp(dt, ctx, I, owner);
    } else if (owner) {
      this._defense(dt, ctx, I, owner);
    } else {
      this._hold(dt, ctx, I);
    }
  }

  _seek(target, I, mag = 1, sprint = false) {
    const a = this.actor;
    const dx = target.x - a.pos.x, dz = target.z - a.pos.z;
    const d = Math.hypot(dx, dz);
    if (d < 0.25) return;
    I.move.x = dx / d; I.move.z = dz / d; I.move.mag = mag; I.move.sprint = sprint && d > 2.4;
  }

  // ---------------- offense with the ball ----------------
  _offense(dt, ctx, I) {
    const a = this.actor;
    const { game } = ctx;
    const d = a.rimDist();
    const { d: defD } = a.nearestOpp(ctx.actors);
    this.decideT -= dt;
    this.rollT -= dt;

    // bring the ball up
    if (d > 9.5) {
      this._seek(a.rim(), I, 1, true);
      if (this.rollT <= 0 && Math.random() < this.diff.moveFreq * 0.6) {
        I.flick = Math.random() < 0.5 ? 'left' : 'right';
        this.rollT = rand(0.5, 1.1);
      }
      return;
    }

    // shot clock pressure
    const urgent = game.shotClock !== null && game.shotClock < 3.6;

    if (this.decideT <= 0 || urgent) {
      this.decideT = urgent ? 0.15 : rand(0.45, 0.95);
      const r = Math.random();
      if (urgent || (defD > 1.65 && d < 9 && r < 0.5 + this.diff.shotQ * 0.3)) {
        // shoot
        I.shootDown = true;
        this.pendingRelease = true;
        this.releaseScheduled = false;
        return;
      }
      if (defD > 2.3 && r < 0.78) {
        // drive
        this._driveMode = true;
      } else if (r < 0.9) {
        // a move
        const moves = ['left', 'right', 'down'];
        I.flick = moves[(Math.random() * moves.length) | 0];
      } else {
        I.flick = 'up'; // pump fake
      }
    }

    if (this._driveMode) {
      this._seek(a.rim(), I, 1, true);
      if (d < 3.5) {
        I.shootDown = true;
        this.pendingRelease = true;
        this.releaseScheduled = false;
        this._driveMode = false;
      }
      // abandon drive if defender recovered
      if (defD < 1.1 && Math.random() < 0.02) this._driveMode = false;
    } else {
      // probe around the arc
      const rim = a.rim();
      const tt = performance.now() * 0.001;
      const ang = Math.atan2(a.pos.z - rim.z, a.pos.x - rim.x) + Math.sin(tt * 1.3) * 0.5;
      const wantD = clamp(6.4 + Math.sin(tt * 0.6) * 2, 5, 8.5);
      const t = { x: rim.x + Math.cos(ang) * wantD, z: rim.z + Math.sin(ang) * wantD };
      this._seek(t, I, 0.75, false);
    }
  }

  // ---------------- teammate without ball ----------------
  _spotUp(dt, ctx, I, owner) {
    const a = this.actor;
    const rim = a.rim();
    const spots = [
      { x: rim.x - Math.sign(rim.x) * 8.2, z: 6.4 },
      { x: rim.x - Math.sign(rim.x) * 8.2, z: -6.4 },
      { x: rim.x - Math.sign(rim.x) * 10.5, z: 0.8 },
      { x: rim.x - Math.sign(rim.x) * 6.0, z: 4.2 }
    ];
    // pick best spot: far from defenders, spread from ball handler
    let best = spots[0], bestScore = -1e9;
    for (const s of spots) {
      let score = 0;
      for (const o of a.opponents(ctx.actors)) score += Math.min(4, dist2d(s.x, s.z, o.pos.x, o.pos.z));
      score += dist2d(s.x, s.z, owner.pos.x, owner.pos.z) * 0.6;
      if (Math.abs(s.x - a.pos.x) < 3 && Math.abs(s.z - a.pos.z) < 3) score += 6; // stay put if close
      if (score > bestScore) { bestScore = score; best = s; }
    }
    this._seek(best, I, 0.85, false);
  }

  // ---------------- defense ----------------
  _defense(dt, ctx, I, handler) {
    const a = this.actor;
    const { game } = ctx;
    const hoop = this.defendHoop();
    // my matchup: the handler if I'm closest to him, otherwise the other opponent
    const opps = a.opponents(ctx.actors);
    let man = handler;
    const others = opps.filter(o => o !== handler);
    if (others.length) {
      const dHandler = dist2d(a.pos.x, a.pos.z, handler.pos.x, handler.pos.z);
      const dOther = dist2d(a.pos.x, a.pos.z, others[0].pos.x, others[0].pos.z);
      if (dOther + 1.5 < dHandler && !others[0].hasBall) man = others[0];
    }
    const hx = hoop.rimCenter.x, hz = hoop.rimCenter.z;
    const dx = hx - man.pos.x, dz = hz - man.pos.z;
    const dl = Math.hypot(dx, dz) || 1;
    const guard = { x: man.pos.x + (dx / dl) * 1.15, z: man.pos.z + (dz / dl) * 1.15 };
    const gd = dist2d(a.pos.x, a.pos.z, guard.x, guard.z);
    this._seek(guard, I, 1, gd > 3.2);
    if (gd < 0.5) { I.move.mag = 0; }

    // pump-fake bait: jump at the fake
    if (man.mode === 'fake' && gd < 1.7 && Math.random() < 0.09 + (1 - this.diff.react) * 0.1) {
      I.steal = true; // triggers block jump — bites on the fake
      return;
    }
    // contest shots (roll once per shot attempt)
    const shooting = ['jumpshot', 'layup', 'dunk'].includes(man.mode) || (man.shot && !man.shot.released);
    if (shooting) {
      if (!this.contestRolled) {
        this.contestRolled = true;
        if (gd < 1.9 && Math.random() < this.diff.contest) {
          I.steal = true;
          return;
        }
      }
    } else this.contestRolled = false;

    // occasional reach
    this.stealRollT -= dt;
    if (this.stealRollT <= 0) {
      this.stealRollT = rand(1.4, 3.4) / this.diff.steal;
      if (gd < 1.5 && Math.random() < this.diff.steal * 0.85) I.steal = true;
    }
  }

  _hold(dt, ctx, I) {
    // nothing loose, no owner: drift to a neutral spot
    const a = this.actor;
    const hoop = this.defendHoop();
    this._seek({ x: hoop.rimCenter.x * 0.25, z: 0 }, I, 0.6, false);
  }
}
