// ============ ZENING HOOPS — bootstrap, game loop, state machine ============
import * as THREE from 'three';
import { SAVE } from './config.js';
import { SFX } from './audio.js';
import { VFXer } from './vfx.js';
import { World } from './world.js';
import { Ball } from './ball.js';
import { Controls } from './controls.js';
import { Game } from './game.js';
import { MenuUI } from './menu.js';
import { Stickman } from './stickman.js';

const $ = id => document.getElementById(id);

class App {
  constructor() {
    this.state = 'loading';
    this.t = 0;
    this.last = performance.now();
    this.orbitA = 0;
    window.__zh = this; // debug handle
  }

  init() {
    SAVE.load();
    const q = SAVE.data.settings.quality;

    let world;
    try {
      world = new World();
      world.init($('c3d'), q);
    } catch (e) {
      console.error('WebGL init failed', e);
      $('glfail').classList.remove('hidden');
      $('loading').classList.add('hidden');
      return;
    }
    this.world = world;
    world.resize();
    this.sfx = SFX;
    this.vfx = VFXer;

    VFXer.init(world.scene);
    this.ball = new Ball(world.scene);
    const eq = SAVE.data.equip;
    const ballItem = ['classic', 'neon', 'gold', 'galaxy'].find(b => b === eq.ball) || 'classic';
    const ballColor = { classic: '#d2691e', neon: '#1f3a1a', gold: '#e9b44c', galaxy: '#3a1f5a' }[ballItem];
    const ballGlow = { classic: '#00000000', neon: '#35e06a', gold: '#ffcf7d', galaxy: '#b06aff' }[ballItem];
    this.ball.setSkin(ballColor, ballGlow);

    this.controls = new Controls();
    this.game = new Game(this);
    this.menu = new MenuUI(this);
    this.menu.init();

    // preview stickman on the menu court
    this.preview = null;
    this.refreshPreview();

    // events
    addEventListener('resize', () => {
      world.resize();
      this.menu.resizeLeaves();
    });
    document.addEventListener('visibilitychange', () => {
      if (document.hidden && this.state === 'game' && this.game.phase === 'live') {
        this.game.paused = true;
        this.menu.pause();
      }
    });
    addEventListener('pointerdown', () => SFX.ensure(), { once: false });
    // orientation guard (touch devices)
    const checkRot = () => {
      const portrait = matchMedia('(orientation: portrait)').matches;
      const touch = matchMedia('(pointer: coarse)').matches;
      $('rotate').classList.toggle('hidden', !(portrait && touch));
    };
    checkRot();
    addEventListener('resize', checkRot);

    // fake short load sequence, then menu
    let p = 0;
    const fill = $('load-fill');
    const tick = setInterval(() => {
      p += 8 + Math.random() * 22;
      fill.style.width = Math.min(100, p) + '%';
      if (p >= 100) {
        clearInterval(tick);
        setTimeout(() => {
          $('loading').classList.add('hidden');
          this.state = 'menu';
          this.menu.showMenu();
        }, 250);
      }
    }, 90);

    requestAnimationFrame(() => this.loop());
  }

  refreshPreview() {
    const eq = SAVE.data.equip;
    if (this.preview) this.world.scene.remove(this.preview.root);
    const auraItem = { none: null, gold: '#e9b44c', green: '#35e06a' }[eq.aura] || null;
    this.preview = new Stickman({
      jersey: eq.jersey, band: eq.band, number: eq.number, auraColor: auraItem
    });
    this.preview.root.position.set(-2.5, 0, 0);
    this.preview.faceYaw = Math.PI * 0.5;
    this.preview.root.rotation.y = Math.PI * 0.5;
    this.world.scene.add(this.preview.root);
    // preview ball skin on menu
    const ballColor = { classic: '#d2691e', neon: '#1f3a1a', gold: '#e9b44c', galaxy: '#3a1f5a' }[eq.ball] || '#d2691e';
    const ballGlow = { classic: '#00000000', neon: '#35e06a', gold: '#ffcf7d', galaxy: '#b06aff' }[eq.ball] || '#00000000';
    this.ball.setSkin(ballColor, ballGlow);
    const trail = { none: null, green: '#35e06a', fire: '#ff7b2e', ice: '#8ad8ff', rainbow: '#ff5ad2' }[eq.trail];
    this.ball.setTrail(false, trail || '#35e06a');
    this.ball.reset(new THREE.Vector3(-2.2, 0.12, 0.5));
  }

  startGame(mode) {
    SFX.ensure();
    // landscape game: go fullscreen + lock orientation on touch devices (best effort;
    // the Android build also enforces sensorLandscape in the manifest)
    if (matchMedia('(pointer: coarse)').matches) {
      try {
        if (!document.fullscreenElement && document.documentElement.requestFullscreen) {
          const p = document.documentElement.requestFullscreen();
          if (p && p.catch) p.catch(() => {});
        }
      } catch (e) { /* unsupported */ }
      try {
        if (screen.orientation && screen.orientation.lock) {
          const p = screen.orientation.lock('landscape');
          if (p && p.catch) p.catch(() => {});
        }
      } catch (e) { /* unsupported */ }
    }
    this.menu.hideMenu();
    document.querySelectorAll('.panel').forEach(p => p.classList.add('hidden'));
    $('result').classList.add('hidden');
    $('tutorial').classList.add('hidden');
    if (this.preview) { this.world.scene.remove(this.preview.root); this.preview = null; }
    this.state = 'game';
    this.game.start(mode);
  }

  toMenu() {
    this.state = 'menu';
    this.controls.releaseAll();
    this.refreshPreview();
    this.menu.showMenu();
  }

  showResult(d) {
    this.menu.showResult(d);
  }

  loop() {
    requestAnimationFrame(() => this.loop());
    const now = performance.now();
    let dt = (now - this.last) / 1000;
    this.last = now;
    if (dt > 1 / 20) dt = 1 / 20; // clamp hitches
    if (dt <= 0) return;
    this.t += dt;

    this.world.update(dt, this.t);
    VFXer.update(dt);

    if (this.state === 'menu') {
      // slow cinematic orbit around the court
      this.orbitA += dt * 0.07;
      const r = 15.5;
      const cam = this.world.camera;
      cam.position.set(Math.cos(this.orbitA) * r, 5.6 + Math.sin(this.t * 0.3) * 0.5, Math.sin(this.orbitA) * r);
      cam.lookAt(0, 1.4, 0);
      if (this.preview) {
        this.preview.update(dt, { speed: 0 });
        this.preview.root.rotation.y += dt * 0.25; // slow turntable
        this.preview.faceYaw = this.preview.root.rotation.y;
      }
    } else if (this.state === 'game') {
      this.game.update(dt, this.t);
    }

    this.world.renderer.render(this.world.scene, this.world.camera);
  }
}

const app = new App();
window.addEventListener('DOMContentLoaded', () => app.init());
