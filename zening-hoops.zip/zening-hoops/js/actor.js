// ============ ZENING HOOPS — Actor: movement, shooting meter, moves, defense ============
import * as THREE from 'three';
import { COURT as C, clamp, lerp, rand, dist2d } from './config.js';
import { Stickman } from './stickman.js';

const G = C.G;
const RIGHT = new THREE.Vector3();

export class Actor {
  constructor(team, isHuman, opts = {}) {
    this.team = team;
    this.isHuman = isHuman;
    this.stickman = new Stickman(opts);
    this.pos = new THREE.Vector3();
    this.vel = new THREE.Vector3();
    this.faceYaw = 0;
    this.speed = 0;
    this.stamina = 100;
    this.jumpY = 0;
    this.jumpVy = 0;
    this.hasBall = false;
    this.mode = 'free';
    this.actionT = 0;
    this.actionDur = 0;
    this.shot = null;
    this.lastShot = null;
    this.dribbleHand = 1;
    this.dribbleSide = new THREE.Vector3(1, 0, 0);
    this.dribbleRate = 1.4;
    this.moveLock = 0;
    this.cooldown = { flick: 0, steal: 0 };
    this.attackHoop = null;   // set by game
    this.blockCheck = null;
    this.cheerT = 0;
    this.intents = { move: { x: 0, z: 0, mag: 0, sprint: false }, flick: null, shootDown: false, shootUp: false, pass: false, steal: false };
  }

  rightVec() { return new THREE.Vector3(Math.cos(this.faceYaw), 0, -Math.sin(this.faceYaw)); }
  fwdVec() { return new THREE.Vector3(Math.sin(this.faceYaw), 0, Math.cos(this.faceYaw)); }
  rim() { return this.attackHoop.rimCenter; }
  rimDist() { return dist2d(this.pos.x, this.pos.z, this.rim().x, this.rim().z); }

  opponents(actors) { return actors.filter(a => a.team !== this.team); }
  nearestOpp(actors) {
    let best = null, bd = 1e9;
    for (const a of this.opponents(actors)) {
      const d = dist2d(this.pos.x, this.pos.z, a.pos.x, a.pos.z);
      if (d < bd) { bd = d; best = a; }
    }
    return { a: best, d: bd };
  }
  teammates(actors) { return actors.filter(a => a.team === this.team && a !== this); }

  stumble(dur, ctx) {
    this.mode = 'stumble';
    this.actionT = 0;
    this.actionDur = dur;
    this.stickman.setState('stumble', dur);
    this.vel.multiplyScalar(0.3);
    if (ctx) {
      ctx.vfx.burst(this.pos.clone().setY(0.25), '#8ad8ff', 16, { speed: 2.2, size: 0.12, life: 0.4 });
    }
  }

  // ---------------- update ----------------
  update(dt, ctx) {
    const { world, ball, actors, game, vfx, sfx, intents } = ctx;
    this.actionT += dt;
    this.cooldown.flick = Math.max(0, this.cooldown.flick - dt);
    this.cooldown.steal = Math.max(0, this.cooldown.steal - dt);
    this.moveLock = Math.max(0, this.moveLock - dt);
    const inM = intents || this.intents;

    switch (this.mode) {
      case 'free': this._free(dt, inM, ctx); break;
      case 'jumpshot': this._jumpshot(dt, inM, ctx); break;
      case 'layup': this._layup(dt, inM, ctx); break;
      case 'dunk': this._dunk(dt, ctx); break;
      case 'cross': case 'stepback': case 'fake': case 'steal': case 'block':
        if (this.mode === 'block' && this._checkBlock(ctx)) break;
        if (this.actionT > this.actionDur) this._toFree();
        break;
      case 'stumble':
        if (this.actionT > this.actionDur) this._toFree();
        break;
      case 'cheer': case 'sulk':
        if (this.actionT > this.actionDur) this._toFree();
        break;
    }

    // ---- physics: horizontal ----
    const acc = 24;
    if (this.moveLock <= 0 && ['free'].includes(this.mode)) {
      const ms = this._maxSpeed();
      const want = new THREE.Vector3(inM.move.x, 0, inM.move.z).multiplyScalar(ms * (inM.move.mag || 0));
      this.vel.x = lerp(this.vel.x, want.x, Math.min(1, acc * dt / 6));
      this.vel.z = lerp(this.vel.z, want.z, Math.min(1, acc * dt / 6));
    } else if (!['dunk', 'layup'].includes(this.mode) && this.moveLock > 0) {
      this.vel.multiplyScalar(Math.max(0, 1 - 6 * dt));
    }
    this.pos.addScaledVector(this.vel, dt);
    this.pos.x = clamp(this.pos.x, -C.HALF_L - 0.4, C.HALF_L + 0.4);
    this.pos.z = clamp(this.pos.z, -C.HALF_W - 0.4, C.HALF_W + 0.4);
    this.speed = Math.hypot(this.vel.x, this.vel.z);

    // actor separation
    for (const a of actors) {
      if (a === this) continue;
      const dx = this.pos.x - a.pos.x, dz = this.pos.z - a.pos.z;
      const d = Math.hypot(dx, dz);
      if (d < 0.62 && d > 0.001) {
        const push = (0.62 - d) / d * 0.5;
        this.pos.x += dx * push; this.pos.z += dz * push;
      }
    }

    // ---- jump physics ----
    if (this.jumpY > 0 || this.jumpVy > 0) {
      this.jumpY += this.jumpVy * dt;
      this.jumpVy -= G * dt;
      if (this.jumpY <= 0) {
        if (this.jumpVy < -3.5) sfx.squeak();
        this.jumpY = 0; this.jumpVy = 0;
      }
    }

    // ---- stamina ----
    const sprinting = inM.move.sprint && this.speed > 4.4 && this.mode === 'free';
    if (sprinting) this.stamina = Math.max(0, this.stamina - 13 * dt);
    else this.stamina = Math.min(100, this.stamina + (this.speed < 1 ? 11 : 7) * dt);

    // ---- facing ----
    this._face(dt, ball, actors);

    // ---- ball attachment ----
    if (this.hasBall) {
      if (['jumpshot', 'layup', 'dunk', 'fake'].includes(this.mode) && ball.owner === this && !this.shot?.released) {
        // two-hand gather for jumpers and dunks, guide hand for layups
        let hand;
        if (this.mode === 'layup' || this.mode === 'fake') hand = this.stickman.handPos(1);
        else hand = this.stickman.handPos(1).lerp(this.stickman.handPos(-1), 0.5);
        ball.hold(this, hand);
      } else if (ball.owner === this) {
        ball.state = 'dribble';
      }
      this.dribbleRate = clamp(1.05 + this.speed * 0.14, 1.1, 2.3);
      this.dribbleSide.copy(this.rightVec()).multiplyScalar(this.dribbleHand);
    }

    // ---- stickman ----
    const sm = this.stickman;
    let smState = 'idle';
    if (['free'].includes(this.mode)) {
      if (this.hasBall) smState = 'dribble';
      else if (this.speed > 0.6) smState = this._nearestOppDist(actors) < 2.6 ? 'defense' : 'run';
      else smState = this._nearestOppDist(actors) < 2.6 ? 'defense' : 'idle';
    }
    if (sm.state !== smState && smState === 'idle' && sm.state === 'idle') { /* keep */ }
    const autoStates = ['free'];
    if (autoStates.includes(this.mode)) {
      if (sm.state !== smState && smState !== 'idle' && sm.state !== 'idle') {
        // switch between run/defense/dribble seamlessly
        sm.state = smState; sm.actionT = 0;
      } else if (sm.state !== smState && ['idle', 'run', 'defense', 'dribble'].includes(sm.state) && ['idle', 'run', 'defense', 'dribble'].includes(smState)) {
        sm.state = smState;
      }
    }
    // eyes track the rock on defense
    let headYaw = 0;
    if (this.mode === 'free' && !this.hasBall) {
      const bp = ball.mesh.position;
      let hd = Math.atan2(bp.x - this.pos.x, bp.z - this.pos.z) - this.faceYaw;
      while (hd > Math.PI) hd -= Math.PI * 2;
      while (hd < -Math.PI) hd += Math.PI * 2;
      headYaw = clamp(hd, -1.1, 1.1);
    }
    sm.update(dt, {
      speed: this.speed,
      faceYaw: this.faceYaw,
      dribblePhase: this.hasBall ? ball.dribblePhase : 0,
      dribbleHand: this.dribbleHand,
      crossDir: this._crossDir || 1,
      headYaw
    });
    sm.root.position.set(this.pos.x, this.jumpY, this.pos.z);
  }

  _maxSpeed() {
    const base = this.hasBall ? 5.9 : 6.5;
    const stamFactor = 0.7 + 0.3 * (this.stamina / 100);
    return base * stamFactor;
  }
  _nearestOppDist(actors) { return this.nearestOpp(actors).d; }

  _face(dt, ball, actors) {
    let target = this.faceYaw;
    const mv = Math.hypot(this.vel.x, this.vel.z);
    if (['jumpshot', 'layup', 'dunk', 'fake'].includes(this.mode)) {
      target = Math.atan2(this.rim().x - this.pos.x, this.rim().z - this.pos.z);
    } else if (this.hasBall) {
      if (mv > 1.2) target = Math.atan2(this.vel.x, this.vel.z);
      else target = Math.atan2(this.rim().x - this.pos.x, this.rim().z - this.pos.z);
    } else {
      const opp = this.nearestOpp(actors).a;
      if (opp && opp.hasBall) target = Math.atan2(opp.pos.x - this.pos.x, opp.pos.z - this.pos.z);
      else if (mv > 1.2) target = Math.atan2(this.vel.x, this.vel.z);
    }
    let d = target - this.faceYaw;
    while (d > Math.PI) d -= Math.PI * 2;
    while (d < -Math.PI) d += Math.PI * 2;
    this.faceYaw += d * Math.min(1, dt * 11);
  }

  _toFree() {
    this.mode = 'free';
    this.shot = null;
    this.stickman.setState(this.hasBall ? 'dribble' : (this.speed > 0.6 ? 'run' : 'idle'), 0.4);
    this.blockCheck = null;
  }

  // ---------------- free mode: read intents ----------------
  _free(dt, inM, ctx) {
    const { ball, actors, game, vfx, sfx } = ctx;

    // SHOOT pressed
    if (inM.shootDown && this.hasBall) this._startShot(ctx);
    // flick moves
    if (inM.flick && this.hasBall && this.cooldown.flick <= 0) this._doMove(inM.flick, ctx);
    // pass
    if (inM.pass && this.hasBall) this._doPass(ctx);
    // pump fake via pass button in 1v1 handled by game mapping to flick 'up'
    // defense: steal / block
    if (inM.steal && !this.hasBall && this.cooldown.steal <= 0) this._doSteal(ctx);

    // steal catch: pick up loose ball
    if (!this.hasBall && ball.owner === null && ['loose', 'pass'].includes(ball.state)) {
      const d = this.pos.distanceTo(ball.mesh.position);
      if (d < 0.62 && ball.mesh.position.y < 1.9) game.catchBall(this);
    }
  }

  // ---------------- shooting ----------------
  _startShot(ctx) {
    const { vfx } = ctx;
    const d = this.rimDist();
    const rimDir = new THREE.Vector3(this.rim().x - this.pos.x, 0, this.rim().z - this.pos.z).normalize();
    const towardRim = this.vel.clone().normalize().dot(rimDir);
    if (d < 2.5 && this.speed > 3.1 && towardRim > 0.45 && this.stamina > 10) {
      this._startDunk(ctx);
      return;
    }
    const type = d < 3.9 ? 'layup' : 'jump';
    const dur = type === 'layup' ? 0.52 : clamp(0.78 + d * 0.007, 0.8, 1.0);
    const { a: opp, d: oppD } = this.nearestOpp(ctx.actors);
    let contest = 1;
    if (opp && oppD < 2.6) contest *= 1 - clamp((2.6 - oppD) / 2.6, 0, 1) * 0.52;
    if (opp && opp.jumpY > 0.1) contest *= 0.72;
    const distFactor = 1 - clamp(d, 0, 24) / 22 * 0.45;
    const offDribble = this.speed > 3.4 ? 0.84 : 1;
    const fatigue = 0.82 + 0.18 * (this.stamina / 100);
    const greenHalf = clamp(0.064 * distFactor * (0.55 + 0.45 * clamp(oppD / 2.6, 0, 1)) * contest * offDribble * fatigue, 0.02, 0.085);
    const greenT = dur * 0.6;
    this.mode = type === 'layup' ? 'layup' : 'jumpshot';
    this.actionT = 0;
    this.shot = { type, meterT: 0, dur, greenT, greenHalf, released: false, oppD, d, makeRollDone: false };
    this.moveLock = 99;
    this.stickman.setState(type === 'layup' ? 'layup' : 'jumpshot', dur * 1.55);
    if (type === 'layup') {
      this._layupDrive = rimDir.clone();
      this.jumpVy = 4.0;
    }
    ctx.sfx.squeak();
  }

  _jumpshot(dt, inM, ctx) {
    const s = this.shot;
    s.meterT += dt;
    // gather jump
    if (!s.jumped && s.meterT > s.greenT - 0.13) {
      s.jumped = true;
      this.jumpVy = 4.35;
    }
    // auto-release if way late
    if (s.meterT > s.greenT + s.greenHalf * 4) this._release(ctx, true);
    else if (inM.shootUp && !s.released) this._release(ctx, false);
    if (this.actionT > s.dur + 0.6 && s.released) this._toFree();
  }

  _release(ctx, forced) {
    const { ball, world, vfx, sfx } = ctx;
    const s = this.shot;
    if (s.released || this.mode !== 'jumpshot') return;
    s.released = true;
    const q = forced ? 0 : clamp(1 - Math.abs(s.meterT - s.greenT) / s.greenHalf, 0, 1);
    const green = q >= 0.8;
    const hoop = this.attackHoop;
    const d = s.d;
    const open = clamp(s.oppD / 2.6, 0, 1);
    let makeP = clamp(0.16 + 0.9 * q - d * 0.014 + open * 0.2, 0.04, 0.94);
    if (green) makeP = 1;
    const make = Math.random() < makeP;
    const rp = this.stickman.handPos(1);
    const target = hoop.rimCenter.clone().add(new THREE.Vector3(0, 0.26, 0));
    if (green) {
      // dead center
    } else {
      const errDir = new THREE.Vector3(rand(-1, 1), 0, rand(-1, 1)).normalize();
      const errMag = make ? (1 - q) * rand(0.08, 0.3) : rand(0.3, 0.52);
      target.addScaledVector(errDir, errMag);
      if (!make) target.y += rand(-0.05, 0.1);
    }
    // steeper arc so the ball drops through the cylinder instead of
    // carrying flat into the back rim (real shots enter ~50-60 deg)
    const tf = clamp(1.0 + d * 0.105, 1.25, 2.0);
    const vel = new THREE.Vector3(
      ((target.x - rp.x) / tf) * 1.015,
      (target.y - rp.y + 0.5 * G * tf * tf) / tf,
      ((target.z - rp.z) / tf) * 1.015
    );
    ball.launch(vel, this, hoop, false);
    ball.spinAxis.copy(this.rightVec());
    ball.spinRate = -7.5;
    this.hasBall = false;
    this.lastShot = { green, q, d, hoop, shooter: this };
    if (green) {
      vfx.burst(rp, '#35e06a', 30, { speed: 3.4, size: 0.15, life: 0.7 });
      vfx.ring(rp.clone().add(new THREE.Vector3(0, 0.25, 0)), 0x35e06a);
      vfx.flash('rgba(53,224,106,.22)');
      sfx.green();
      const trailItem = ctx.game.equippedTrail();
      ball.setTrail(true, trailItem === 'none' ? '#35e06a' : trailColorOf(trailItem));
    }
    ctx.game.onShotReleased(this, green, q);
  }

  _layup(dt, inM, ctx) {
    const s = this.shot;
    s.meterT += dt;
    // drive to rim
    const drive = this._layupDrive;
    this.vel.x = drive.x * 4.2; this.vel.z = drive.z * 4.2;
    if (!s.jumped && this.rimDist() < 1.9) {
      s.jumped = true;
      this.jumpVy = 4.3;
      this.vel.multiplyScalar(0.4);
    }
    if (!s.released && s.jumped && s.meterT > s.greenT) this._layupRelease(ctx);
    if (s.meterT > s.greenT + s.greenHalf * 4) this._layupRelease(ctx);
    if (this.actionT > s.dur + 0.7 && s.released) this._toFree();
  }
  _layupRelease(ctx) {
    const { ball, vfx, sfx } = ctx;
    const s = this.shot;
    if (s.released) return;
    s.released = true;
    const q = clamp(1 - Math.abs(s.meterT - s.greenT) / s.greenHalf, 0, 1);
    const green = q >= 0.8;
    const hoop = this.attackHoop;
    let makeP = clamp(0.44 + 0.5 * q + clamp(s.oppD / 2.6, 0, 1) * 0.12, 0.12, 0.96);
    if (green) makeP = 1;
    const make = Math.random() < makeP;
    const rp = this.stickman.handPos(1);
    const target = hoop.rimCenter.clone().add(new THREE.Vector3(0, 0.18, 0));
    if (!green && !make) target.add(new THREE.Vector3(rand(-0.3, 0.3), rand(0, 0.12), rand(-0.3, 0.3)));
    if (!green && make) target.add(new THREE.Vector3(rand(-0.08, 0.08), 0, rand(-0.08, 0.08)));
    const tf = clamp(0.82 + s.d * 0.1, 0.9, 1.3);
    ball.launch(new THREE.Vector3(
      ((target.x - rp.x) / tf) * 1.015,
      (target.y - rp.y + 0.5 * G * tf * tf) / tf,
      ((target.z - rp.z) / tf) * 1.015
    ), this, hoop, false);
    this.hasBall = false;
    this.lastShot = { green, q, d: s.d, hoop, shooter: this };
    if (green) {
      vfx.burst(rp, '#35e06a', 26, { speed: 3, size: 0.14, life: 0.6 });
      sfx.green();
      ball.setTrail(true, trailColorOf(ctx.game.equippedTrail()) || '#35e06a');
    }
    ctx.game.onShotReleased(this, green, q);
  }

  _startDunk(ctx) {
    this.mode = 'dunk';
    this.actionT = 0;
    this.shot = { released: false, slammed: false, jumped: false };
    this.moveLock = 99;
    this.stickman.setState('dunk', 0.95);
    this._dunkDir = new THREE.Vector3(this.rim().x - this.pos.x, 0, this.rim().z - this.pos.z).normalize();
    ctx.sfx.swoosh();
  }
  _dunk(dt, ctx) {
    const { ball, vfx, sfx } = ctx;
    const d = this.rimDist();
    if (!this.shot.jumped) {
      this.vel.copy(this._dunkDir).multiplyScalar(5.6);
      if (d < 1.7) {
        this.shot.jumped = true;
        this.jumpVy = 5.0;
        this.vel.multiplyScalar(0.32);
      }
    }
    if (this.shot.jumped && !this.shot.slammed && this.jumpY > 0.72) {
      this.shot.slammed = true;
      const hoop = this.attackHoop;
      const bp = ball.mesh.position;
      const toRim = hoop.rimCenter.clone().sub(bp);
      ball.launch(toRim.multiplyScalar(4.5).add(new THREE.Vector3(0, -1.6, 0)), this, hoop, true);
      this.hasBall = false;
      vfx.shake(0.75);
      sfx.dunk();
      ctx.game.onDunk(this);
    }
    if (this.actionT > 1.05) this._toFree();
  }

  // ---------------- dribble moves ----------------
  _doMove(flick, ctx) {
    const { ball, actors, vfx, sfx, game } = ctx;
    this.cooldown.flick = 0.72;
    if (flick === 'left' || flick === 'right') {
      const dir = flick === 'right' ? 1 : -1;
      this._crossDir = dir;
      this.mode = 'cross';
      this.actionT = 0;
      this.actionDur = 0.34;
      this.stickman.setState('cross', 0.34);
      this.dribbleHand *= -1;
      const imp = this.rightVec().multiplyScalar(dir * 5.4);
      this.vel.add(imp);
      sfx.squeak();
      // ankle breaker check
      const { a: opp, d: oppD } = this.nearestOpp(actors);
      if (opp && oppD < 1.5) {
        const toOpp = opp.pos.clone().sub(this.pos).normalize();
        const facing = this.fwdVec().dot(toOpp) > 0.15;
        const react = game.defenderReact(opp);
        const chance = clamp(0.44 + (this.speed - 4) * 0.05 - react * 0.55, 0.12, 0.72) * (facing ? 1 : 0.5);
        if (Math.random() < chance) {
          opp.stumble(1.25, ctx);
          vfx.burst(opp.pos.clone().setY(0.2), '#35e06a', 22, { speed: 2.6, size: 0.13, life: 0.5 });
          vfx.ring(opp.pos.clone().setY(0.05), 0x35e06a);
          vfx.popup('ANKLES!', '#35e06a', 'broke his ankles', -6, 40);
          sfx.ankles();
          game.onAnkles(this);
        }
      }
    } else if (flick === 'down') {
      this.mode = 'stepback';
      this.actionT = 0;
      this.actionDur = 0.42;
      this.stickman.setState('stepback', 0.42);
      const away = new THREE.Vector3(this.pos.x - this.rim().x, 0, this.pos.z - this.rim().z).normalize();
      this.vel.addScaledVector(away, 5.6);
      sfx.squeak();
    } else if (flick === 'up') {
      this.mode = 'fake';
      this.actionT = 0;
      this.actionDur = 0.6;
      this.stickman.setState('fake', 0.6);
    }
  }

  _doPass(ctx) {
    const { ball } = ctx;
    const mates = this.teammates(ctx.actors);
    if (!mates.length) return;
    // nearest open teammate
    let best = mates[0];
    for (const m of mates) {
      const oppD = m.nearestOpp(ctx.actors).d;
      if (oppD > best.nearestOpp(ctx.actors).d) best = m;
    }
    const lead = best.pos.clone().addScaledVector(best.vel, 0.28).add(new THREE.Vector3(0, 1.25, 0));
    const from = this.stickman.handPos(1);
    const d = from.distanceTo(lead);
    const tf = clamp(d / 10, 0.28, 0.75);
    ball.pass(new THREE.Vector3(
      (lead.x - from.x) / tf,
      (lead.y - from.y + 0.5 * G * tf * tf) / tf,
      (lead.z - from.z) / tf
    ), best);
    this.hasBall = false;
    ctx.sfx.swoosh();
  }

  _doSteal(ctx) {
    const { ball, actors, vfx, sfx, game } = ctx;
    this.cooldown.steal = 1.15;
    const { a: opp } = this.nearestOpp(actors);
    const bp = ball.mesh.position;
    const myD = this.pos.distanceTo(bp);
    // BLOCK attempt if opponent is shooting nearby
    if (opp && (['jumpshot', 'layup'].includes(opp.mode) || (ball.state === 'shot' && ball.shooter === opp)) && myD < 2.1) {
      this.mode = 'block';
      this.actionT = 0;
      this.actionDur = 0.7;
      this.stickman.setState('block', 0.7);
      this.jumpVy = 4.8;
      this.blockCheck = { shooter: opp, t: 0.4 };
      sfx.squeak();
      return;
    }
    if (opp && opp.hasBall && myD < 1.7) {
      this.mode = 'steal';
      this.actionT = 0;
      this.actionDur = 0.4;
      this.stickman.setState('steal', 0.4);
      const behind = this.fwdVec().dot(opp.fwdVec()) > 0.4;
      const react = game.defenderReact(opp);
      let chance = 0.34 - react * 0.25 + (behind ? 0.12 : 0);
      if (['cross', 'stepback', 'dunk', 'layup'].includes(opp.mode)) chance -= 0.17;
      if (Math.random() < clamp(chance, 0.06, 0.6)) {
        const away = bp.clone().sub(opp.pos).normalize().multiplyScalar(3.2).add(new THREE.Vector3(0, 2.2, 0));
        ball.steal(away);
        opp.hasBall = false;
        vfx.popup('STRIP!', '#e9b44c', 'takeaway', -6, 34);
        sfx.swoosh();
        game.onSteal(this);
      } else {
        this.stumble(0.45, ctx);
      }
    } else {
      this.mode = 'steal';
      this.actionT = 0;
      this.actionDur = 0.36;
      this.stickman.setState('steal', 0.36);
    }
  }

  _checkBlock(ctx) {
    const { ball, vfx, sfx } = ctx;
    if (!this.blockCheck) return false;
    this.blockCheck.t -= 1 / 60;
    if (ball.state === 'shot' && ball.shooter === this.blockCheck.shooter) {
      const hand = this.stickman.handPos(1);
      if (hand.distanceTo(ball.mesh.position) < 0.62) {
        const away = ball.vel.clone().multiplyScalar(-0.3).add(new THREE.Vector3(rand(-2, 2), 1.5, rand(-2, 2)));
        ball.steal(away);
        vfx.popup('BLOCKED!', '#e05038', 'denied at the rim', -6, 38);
        vfx.shake(0.35);
        sfx.board();
        ctx.game.onBlock(this);
        this.blockCheck = null;
        return true;
      }
    }
    return false;
  }

  celebrate(win) {
    this.mode = win ? 'cheer' : 'sulk';
    this.actionT = 0;
    this.actionDur = 3.2;
    this.stickman.setState(win ? 'cheer' : 'sulk', 3.2);
  }
}

function trailColorOf(id) {
  return ({ none: null, green: '#35e06a', fire: '#ff7b2e', ice: '#8ad8ff', rainbow: '#ff5ad2' })[id] || '#35e06a';
}
